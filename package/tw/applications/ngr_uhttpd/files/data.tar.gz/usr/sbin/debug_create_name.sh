#!/bin/sh

p1=`uci get system.@system[0].model`
m1=`protest --software -r`
m2=${m1%|*}
p2=${m2##*!}
p3=`cat /etc/openwrt_release | grep DISTRIB_DESCRIPTION | sed s/DISTRIB_DESCRIPTION=\'// | sed s/\'// | sed s/r0-//g | sed s/-//g | sed s/://g | awk '{printf("%s_%s%s",$8,$5,$6)}'`
p4=`date "+%Y%m%d%H%M%S"`
echo "DEBUG_${p1}_${p2}_${p3}_${p4}"