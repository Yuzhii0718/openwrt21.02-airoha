{
	"list": [
		<% wireless_schedule_json() %>
	]
}
