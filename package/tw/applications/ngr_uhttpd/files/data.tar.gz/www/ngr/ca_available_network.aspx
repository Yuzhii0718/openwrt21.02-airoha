<% mobile_ca_wl_network("1") %>
