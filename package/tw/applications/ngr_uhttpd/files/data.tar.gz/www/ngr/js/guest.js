(function ($) {
    "use strict";


    $(function () {
        $.changeWEPShowHidden = function () {
            var secOptions = document.getElementById('secType'),
                sel = secOptions.value;
            //if (mode != '1'){
            if (false) {
                    $("#secType option[value='WEP']").remove();
                    if (sel == 'WEP')
                    sel = '0';
                $('#secType').val(sel);
            } else {
                secOptions.options[1].value = 'WPA2-PSK';
                secOptions.options[1].text = sec_wpa2_phrase;
                secOptions.options[2] = new Option(sec_wpas_phrase, 'WPA/WPA2');
                secOptions.options[3] = new Option(sec_wpa3_phrase, 'WPA3');
                secOptions.options[4] = new Option(sec_wpa2wpa3_phrase, 'WPA2/WPA3');
                $('#secType').val(sel);
            }
            $('#secType').trigger('change');
        };

        $.changeWEPShowHidden5g = function () {
            var secOptions = document.getElementById('secType5g'),
                sel = secOptions.value;
            //if ((sta_5g == "2" && mode5g != '1' && confMode =='2') || (confMode == '0' && mode5g != '1'))
            if (false) {
                $("#secType5g option[value='WEP']").remove();
            }
            else {
                secOptions.options[1].value = 'WPA2-PSK';
                secOptions.options[1].text = sec_wpa2_phrase;
                secOptions.options[2] = new Option(sec_wpas_phrase, 'WPA/WPA2');
                secOptions.options[3] = new Option(sec_wpa3_phrase, 'WPA3');
                secOptions.options[4] = new Option(sec_wpa2wpa3_phrase, 'WPA2/WPA3');
                $('#secType5g').val(sel);
            }
            $('#secType5g').trigger('change');
        };

        $.changeWEPShowHidden5g2 = function () {
            var secOptions = document.getElementById('secType5g2'),
                sel = secOptions.value;
            //if ((sta_5g =="1" && mode5g2 != '1'&& confMode =='2') || (confMode == '0' && mode5g2 != '1'))
            if (false)
                $("#secType5g2 option[value='WEP']").remove();
            else {
                secOptions.options[1].value = 'WPA2-PSK';
                secOptions.options[1].text = sec_wpa2_phrase;
                secOptions.options[2] = new Option(sec_wpas_phrase, 'WPA/WPA2');
                secOptions.options[3] = new Option(sec_wpa3_phrase, 'WPA3');
                secOptions.options[4] = new Option(sec_wpa2wpa3_phrase, 'WPA2/WPA3');
                $('#secType5g2').val(sel);
            }
            $('#secType5g2').trigger('change');
        };

        $.returnTop = function (id_flag) {
            var mao = $(id_flag);
            if (mao.length > 0) {
                var pos = mao.offset();
                $("body,html").animate({ scrollTop: pos.top }, 1000);
            }
        }

        if ($('#guestNetworkForm').length) {
            if (confMode != "2") {
                $('.column').addClass('ap');
                $('.column.third.wifi').css('display', 'block');
                // $('.column.second.wifi h3').html(network_5g1);
                $('.column.third.wifi h3').html(network_5g2);
            } else {
                $('.column').removeClass('ap');
                // if (sta_5g == "2") {
                //     $('.column.third.wifi').css('display', 'none');
                // } else {
                //     $('.column.second.wifi').css('display', 'none');
                // }
            }
            if (sta_5g == "2") {
                $('.column.third.wifi').css('display', 'none');

                if (fastlane_surfing == "1" && furfing_mode_type == "5G") {
                    $('.column.second.wifi').css('display', 'none');
                }
                else if (fastlane_surfing == "1" && furfing_mode_type == "2.4G") {
                    $('.column.first.wifi').css('display', 'none');
                }

            } else {
                $('.column.second.wifi').css('display', 'none');
            }

            $('#ssid').val(SSID);
            if (APEnable == '1')
                $('#enableAp').prop('checked', true);
            else
                $('#enableAp').prop('checked', false);

            if (broadcast == '1')
                $('#ssidBc').prop('checked', true);
            else
                $('#ssidBc').prop('checked', false);

            if (allowGuest == '1')
                $('#accessMyLocalGuest').prop('checked', true);
            else
                $('#accessMyLocalGuest').prop('checked', false);

            var securityOptionsWrap_obj;
            if (have_wireless_an == "1")
                securityOptionsWrap_obj = $('.securityOptionsWrap.first');
            else
                securityOptionsWrap_obj = $('.securityOptionsWrap');

            securityOptionsWrap_obj.show();
            $.changeWEPShowHidden();
            if (security == "2") {
                $('.wep.first').slideDown();
                $('.wpa.first').slideUp();
                $('#secType').val($.convertSecTypeToText(security));
                $('#wepAuth').val(authType);
                $('#wepEnc').val(encrLen);
                $('#wepEnc').trigger('change');
                if (keyNum == '1')
                    $('#wepKeyNo1').attr('checked', 'checked');
                else if (keyNum == '2')
                    $('#wepKeyNo2').attr('checked', 'checked');
                else if (keyNum == '3')
                    $('#wepKeyNo3').attr('checked', 'checked');
                else
                    $('#wepKeyNo4').attr('checked', 'checked');
                $('#key1').val(key1);
                $('#key2').val(key2);
                $('#key3').val(key3);
                $('#key4').val(key4);
            } else if (security == "6" || security == "7" || security == "10" || security == "11") {
                $('.wpa.first').slideDown();
                $('.wep.first').slideUp();
                $('#secType').val($.convertSecTypeToText(security));
                $('#passphrase').val(password);
                $('#verifyPwd').val(password);
                if (password.length >= $.MIN_PWD_CHARACTERS)
                    $('#verifyPwd').prop('disabled', false);
                else
                    $('#verifyPwd').prop('disabled', true);
            } else {
                $('.wep.first').slideUp();
                $('.wpa.first').slideUp();
                $('#secType').val('None');
            }

            $('#secType').trigger('change');

            $.checkPass();

            if (have_wireless_an == "1") {
                $('#ssid5g').val(SSID5g);
                if (APEnable5g == '1')
                    $('#enableAp5g').prop('checked', true);
                else
                    $('#enableAp5g').prop('checked', false);

                if (broadcast5g == '1')
                    $('#ssidBc5g').prop('checked', true);
                else
                    $('#ssidBc5g').prop('checked', false);

                if (allowGuest5g == '1')
                    $('#accessMyLocal5gGuest').prop('checked', true);
                else
                    $('#accessMyLocal5gGuest').prop('checked', false);

                $.changeWEPShowHidden5g();

                $('.securityOptionsWrap.second').show();
                if (security5g == "2") {
                    $('.wep.second').slideDown();
                    $('.wpa.second').slideUp();
                    $('#secType5g').val('WEP');
                    $('#wepAuth5g').val($.convertWEPAuthTypeToText(authType5g));
                    $('#wepEnc5g').val($.convertWEPAuthLength(encrLen5g));
                    $('#wepEnc5g').trigger('change');
                    if (keyNum5g == '1')
                        $('#wepKeyNo5g1').attr('checked', 'checked');
                    else if (keyNum5g == '2')
                        $('#wepKeyNo5g2').attr('checked', 'checked');
                    else if (keyNum5g == '3')
                        $('#wepKeyNo5g3').attr('checked', 'checked');
                    else
                        $('#wepKeyNo5g4').attr('checked', 'checked');
                    $('#key5g1').val(key5g1);
                    $('#key5g2').val(key5g2);
                    $('#key5g3').val(key5g3);
                    $('#key5g4').val(key5g4);
                } else if (security5g == "6" || security5g == "7" || security5g == "10" || security5g == "11") {
                    $('.wpa.second').slideDown();
                    $('.wep.second').slideUp();
                    $('#secType5g').val($.convertSecTypeToText(security5g));
                    $('#passphrase5g').val(password5g);
                    $('#verifyPwd5g').val(password5g);
                    if (password5g.length >= $.MIN_PWD_CHARACTERS)
                        $('#verifyPwd5g').prop('disabled', false);
                    else
                        $('#verifyPwd5g').prop('disabled', true);
                } else {
                    $('.wep.second').slideUp();
                    $('.wpa.second').slideUp();
                    $('#secType5g').val('None');
                }
                $('#secType5g').trigger('change');

                $.checkPass5g();
            }

            if (have_wireless_an2 == "1") {
                $('#ssid5g2').val(SSID5g2);
                if (APEnable5g2 == '1')
                    $('#enableAp5g2').prop('checked', true);
                else
                    $('#enableAp5g2').prop('checked', false);

                if (broadcast5g2 == '1')
                    $('#ssidBc5g2').prop('checked', true);
                else
                    $('#ssidBc5g2').prop('checked', false);

                if (allowGuest5g2 == '1')
                    $('#accessMyLocal5g2Guest').prop('checked', true);
                else
                    $('#accessMyLocal5g2Guest').prop('checked', false);

                $.changeWEPShowHidden5g2();

                $('.securityOptionsWrap.third').show();
                if (security5g2 == "2") {
                    $('.wep.third').slideDown();
                    $('.wpa.third').slideUp();
                    $('#secType5g2').val('WEP');
                    $('#wepAuth5g2').val($.convertWEPAuthTypeToText(authType5g2));
                    $('#wepEnc5g2').val($.convertWEPAuthLength(encrLen5g2));
                    $('#wepEnc5g2').trigger('change');
                    if (keyNum5g2 == '1')
                        $('#wepKeyNo5g12').attr('checked', 'checked');
                    else if (keyNum5g2 == '2')
                        $('#wepKeyNo5g22').attr('checked', 'checked');
                    else if (keyNum5g2 == '3')
                        $('#wepKeyNo5g32').attr('checked', 'checked');
                    else
                        $('#wepKeyNo5g42').attr('checked', 'checked');
                    $('#key5g12').val(key5g12);
                    $('#key5g22').val(key5g22);
                    $('#key5g32').val(key5g32);
                    $('#key5g42').val(key5g42);
                } else if (security5g2 == "3" || security5g2 == "4" || security5g2 == "5") {
                    $('.wpa.third').slideDown();
                    $('.wep.third').slideUp();
                    $('#secType5g2').val($.convertSecTypeToText(security5g2));
                    $('#passphrase5g2').val(password5g2);
                    $('#verifyPwd5g2').val(password5g2);
                    if (password5g2.length >= $.MIN_PWD_CHARACTERS)
                        $('#verifyPwd5g2').prop('disabled', false);
                    else
                        $('#verifyPwd5g2').prop('disabled', true);
                } else {
                    $('.wep.third').slideUp();
                    $('.wpa.third').slideUp();
                    $('#secType5g2').val('None');
                }
                $('#secType5g2').trigger('change');

                $.checkPass5g2();
            }

            $('#secType').change(function () {
                if ($('#secType').val() == 'WEP') {
                    $('.wep.first').slideDown();
                    $('.wpa.first').slideUp();
                } else if ($('#secType').val() == 'None') {
                    $('.wep.first').slideUp();
                    $('.wpa.first').slideUp();
                } else {
                    $('.wpa.first').slideDown();
                    $('.wep.first').slideUp();
                }
            });

            $('#secType5g').change(function () {
                if ($('#secType5g').val() == 'WEP') {
                    $('.wep.second').slideDown();
                    $('.wpa.second').slideUp();
                } else if ($('#secType5g').val() == 'None') {
                    $('.wep.second').slideUp();
                    $('.wpa.second').slideUp();
                } else {
                    $('.wpa.second').slideDown();
                    $('.wep.second').slideUp();
                }
            });

            $('#secType5g2').change(function () {
                if ($('#secType5g2').val() == 'WEP') {
                    $('.wep.third').slideDown();
                    $('.wpa.third').slideUp();
                } else if ($('#secType5g2').val() == 'None') {
                    $('.wep.third').slideUp();
                    $('.wpa.third').slideUp();
                } else {
                    $('.wpa.third').slideDown();
                    $('.wep.third').slideUp();
                }
            });

            $('.primary[id!=continueBt]').click(function () {
                $('.errorMsg').remove();
                if (!$.REG_SSID.test($('#ssid').val())) {
                    if ($('#ssid').val().length == 0) {
                        $.addErrMsgAfter('ssid', ssid_null, false, 'error_info_2');
                    } else {
                        $.addErrMsgAfter('ssid', ssid_invalid, false, 'error_info_2');
                    }
                    $.returnTop("#fixedtop");
                    return false;
                }

                if (sta_5g == "2") {
                    if (have_wireless_an && !$.REG_SSID.test($('#ssid5g').val())) {
                        if ($('#ssid5g').val().length == 0) {
                            $.addErrMsgAfter('ssid5g', ssid_null, false, 'error_info_5');
                        } else {
                            $.addErrMsgAfter('ssid5g', ssid_invalid, false, 'error_info_5');
                        }
                        $.returnTop("#fixedtop");
                        return false;
                    }
                } else {
                    if (have_wireless_an2 && !$.REG_SSID.test($('#ssid5g2').val())) {
                        if ($('#ssid5g2').val().length == 0) {
                            $.addErrMsgAfter('ssid5g2', ssid_null, false, 'error_info_5');
                        } else {
                            $.addErrMsgAfter('ssid5g2', ssid_invalid, false, 'error_info_5');
                        }
                        $.returnTop("#fixedtop");
                        return false;
                    }
                }

                if ($('#ssid').val()) {
                    if ($('#ssid').val() == SSID_wifi || $('#ssid').val() == SSID5g_wifi || (SSID5g2_wifi ? $('#ssid').val() == SSID5g2_wifi : false)) {
                        alert(ssid_dup);
                        $.returnTop("#fixedtop");
                        return false;
                    }
                }

                if ($('#ssid5g').val()) {
                    if ($('#ssid5g').val() == SSID_wifi || $('#ssid5g').val() == SSID5g_wifi || (SSID5g2_wifi ? $('#ssid5g').val() == SSID5g2_wifi : false)) {
                        alert(ssid_dup);
                        $.returnTop("#fixedtop");
                        return false;
                    }
                }

                if ($('#ssid5g2').val()) {
                    if ($('#ssid5g2').val() == SSID_wifi || $('#ssid5g2').val() == SSID5g_wifi || (SSID5g2_wifi ? $('#ssid5g2').val() == SSID5g2_wifi : false)) {
                        alert(ssid_dup);
                        $.returnTop("#fixedtop");
                        return false;
                    }
                }

                $.checkSecurity('secType', 'wepEnc', 'passphrase');

                $('#wifi2GHzSSID').val($.do_xss_ssid($('#ssid').val()));
                if ($('#ssidBc').prop('checked'))
                    $('#wifiSSIDBroadcast').val('1');
                else
                    $('#wifiSSIDBroadcast').val('0');
                if ($('#enableAp').prop('checked'))
                    $('#wifiAPMode').val('1');
                else
                    $('#wifiAPMode').val('0');
                if ($('#accessMyLocalGuest').prop('checked'))
                    $('#wifiAllowGuest').val('1');
                else
                    $('#wifiAllowGuest').val('0');

                if (sta_5g == "2" && confMode == "2") {
                    $('.securityOptionsWrap.third').slideDown();
                    //$.sameSecurity('5g', '2', '5g', '');
                    $('#ssid5g2').val($('#ssid5g').val());
                }

                if (sta_5g == "1" && confMode == "2") {
                    $('.securityOptionsWrap.second').slideDown();
                    $.sameSecurity('5g', '', '5g', '2');
                    $('#ssid5g').val($('#ssid5g2').val());
                }

                $.checkSecurity5g('secType5g', 'wepEnc5g', 'passphrase5g');
                $('#wifi5GHzSSID').val($.do_xss_ssid($('#ssid5g').val()));
                if ($('#ssidBc5g').prop('checked'))
                    $('#wifiSSIDBroadcast5g').val('1');
                else
                    $('#wifiSSIDBroadcast5g').val('0');
                if ($('#enableAp5g').prop('checked'))
                    $('#wifiAPMode5g').val('1');
                else
                    $('#wifiAPMode5g').val('0');

                if ($('#accessMyLocal5gGuest').prop('checked'))
                    $('#wifiAllowGuest5g').val('1');
                else
                    $('#wifiAllowGuest5g').val('0');
                $.checkSecurity5g2('secType5g2', 'wepEnc5g2', 'passphrase5g2');
                $('#wifi5GHzSSID2').val($.do_xss_ssid($('#ssid5g2').val()));

                if ($('#ssidBc5g2').prop('checked'))
                    $('#wifiSSIDBroadcast5g2').val('1');
                else
                    $('#wifiSSIDBroadcast5g2').val('0');

                if ($('#enableAp5g2').prop('checked'))
                    $('#wifiAPMode5g2').val('1');
                else
                    $('#wifiAPMode5g2').val('0');

                if ($('#accessMyLocal5g2Guest').prop('checked'))
                    $('#wifiAllowGuest5g2').val('1');
                else
                    $('#wifiAllowGuest5g2').val('0');

                if ($('#secType').val() == 'WEP') {
                    $('.first.wep').slideDown();
                    $('.first.wpa').slideUp();
                    $('#wifiSecOptions').val('2');
                    if ($('#wepAuth').val() == 'Shared Key')
                        $('#wifiWEPAuthType').val('1');
                    else
                        $('#wifiWEPAuthType').val('2');
                    if ($('#wepEnc').val() == '64')
                        $('#wifiWEPEncrStr').val('5');
                    else
                        $('#wifiWEPEncrStr').val('13');
                    $('#wifi2GHzKeyNum').val($('input:radio[name="wep_key_no"]:checked').val());
                    $('#wifiWEPKey1').val($('#key1').val());
                    $('#wifiWEPKey2').val($('#key2').val());
                    $('#wifiWEPKey3').val($('#key3').val());
                    $('#wifiWEPKey4').val($('#key4').val());
                } else if ($('#secType').val() == 'None') {//ap mode: "None"
                    $('.first.wep').slideUp();
                    $('.first.wpa').slideUp();
                    $('#wifiSecOptions').val('1');
                } else {
                    $('.first.wep').slideUp();
                    $('.first.wpa').slideDown();
                    if ($('#secType').val() == 'WPA2-PSK')
                        $('#wifiSecOptions').val('6');
                    else if ($('#secType').val() == 'WPA/WPA2')
                        $('#wifiSecOptions').val('7');
                    else if ($('#secType').val() == 'WPA2/WPA3')
                        $('#wifiSecOptions').val('11');
                    else
                        $('#wifiSecOptions').val('10');
                    if ($('#verifyPwd').val() != $('#passphrase').val() && $('#passphrase').val().length >= $.MIN_PWD_CHARACTERS) {
                        $('#verifyPwd').addClass('alert');
                        $.addErrMsgAfter('verifyPwd', error_not_same_pwd, false, 'errPwdSame');
                        $.returnTop("#ssid");
                        return false;
                    }
                    $('#wifi2GHzPassword').val($.do_xss_pass($('#passphrase').val()));
                }

            if ($('#secType5g').val() == 'WEP') {
                    $('#wifiSecOptions5g').val('2');
                if ($('#wepAuth5g').val() == 'Shared Key')
                        $('#wifiWEPAuthType5g').val('1');
                    else
                        $('#wifiWEPAuthType5g').val('2');
                if ($('#wepEnc5g').val() == '64')
                        $('#wifiWEPEncrStr5g').val('5');
                    else
                        $('#wifiWEPEncrStr5g').val('13');
                    $('#wifi5GHzKeyNum').val($('input:radio[name="wep_key_no_5g"]:checked').val());
                    $('#wifiWEPKey5g1').val($('#key5g1').val());
                    $('#wifiWEPKey5g2').val($('#key5g2').val());
                    $('#wifiWEPKey5g3').val($('#key5g3').val());
                    $('#wifiWEPKey5g4').val($('#key5g4').val());
                    $('.column.second ul strong:last', '#continue').html($.xss_format($('#key5g' + $('#wifi5GHzKeyNum').val()).val()));
                } else if ($('#secType5g').val() == 'None') {//ap mode: "None"
                    $('.second.wep').slideUp();
                    $('.second.wpa').slideUp();
                    $('#wifiSecOptions5g').val('1');
                } else {
                    if ($('#secType5g').val() == 'WPA2-PSK')
                        $('#wifiSecOptions5g').val('6');
                    else if ($('#secType5g').val() == 'WPA/WPA2')
                        $('#wifiSecOptions5g').val('7');
                    else if ($('#secType5g').val() == 'WPA2/WPA3')
                        $('#wifiSecOptions5g').val('11');
                    else
                        $('#wifiSecOptions5g').val('10');
                    if ($('#verifyPwd5g').val() != $('#passphrase5g').val() && $('#passphrase5g').val().length >= $.MIN_PWD_CHARACTERS) {
                        $('#verifyPwd5g').addClass('alert');
                        $.addErrMsgAfter('verifyPwd5g', error_not_same_pwd, false, 'errPwdSame');
                        $.returnTop("#ssid5g");
                        return false;
                    }
                    $('#wifi5GHzPassword').val($.do_xss_pass($('#passphrase5g').val()));
                    $('.column.second ul strong:last', '#continue').html($.xss_format($('#passphrase5g').val()));
                }

            if ($('#secType5g2').val() == 'WEP') {
                    $('#wifiSecOptions5g2').val('2');
                if ($('#wepAuth5g2').val() == 'Shared Key')
                        $('#wifiWEPAuthType5g2').val('1');
                    else
                        $('#wifiWEPAuthType5g2').val('2');
                if ($('#wepEnc5g2').val() == '64')
                        $('#wifiWEPEncrStr5g2').val('5');
                    else
                        $('#wifiWEPEncrStr5g2').val('13');
                    $('#wifi5GHzKeyNum2').val($('input:radio[name="wep_key_no_5g2"]:checked').val());
                    $('#wifiWEPKey5g12').val($('#key5g12').val());
                    $('#wifiWEPKey5g22').val($('#key5g22').val());
                    $('#wifiWEPKey5g32').val($('#key5g32').val());
                    $('#wifiWEPKey5g42').val($('#key5g42').val());
                    $('.column.third ul strong:last', '#continue').html($.xss_format($('#key5g' + $('#wifi5GHzKeyNum2').val() + "2").val()));
                } else if ($('#secType5g2').val() == 'None') {//ap mode: "None"
                    $('.third.wep').slideUp();
                    $('.third.wpa').slideUp();
                    $('#wifiSecOptions5g2').val('1');
                } else {
                    if ($('#secType5g2').val() == 'WPA2-PSK')
                        $('#wifiSecOptions5g2').val('6');
                    else if ($('#secType5g2').val() == 'WPA/WPA2')
                        $('#wifiSecOptions5g2').val('7');
                    else if ($('#secType5g2').val() == 'WPA2/WPA3')
                        $('#wifiSecOptions5g2').val('11');
                    else
                        $('#wifiSecOptions5g2').val('10');
                    if ($('#verifyPwd5g2').val() != $('#passphrase5g2').val() && $('#passphrase5g2').val().length >= $.MIN_PWD_CHARACTERS) {
                        $('#verifyPwd5g2').addClass('alert');
                        $.addErrMsgAfter('verifyPwd5g2', error_not_same_pwd, false, 'errPwdSame');
                        $.returnTop("#ssid5g2");
                        return false;
                    }
                    $('#wifi5GHzPassword2').val($.do_xss_pass($('#passphrase5g2').val()));
                    $('.column.third ul strong:last', '#continue').html($.xss_format($('#passphrase5g2').val()));
                }
                //$.submitApply();
                $.confirmSecOptions1();
            });

            $.confirmSecOptions1 = function() {
                if(($('#wifiAPMode').val() == '1' && $('#secType').val() == 'None') || 
                   ($('#wifiAPMode5g').val() == '1' && $('#secType5g').val() == 'None')) {
                    $.confirmBox(wps_warning3, null, function() {
                        $.submitApply();
                    }, null, null);
                } else {
                    $.submitApply();
                }
            }

            $.submitApply = function () {
                if ($('.errorMsg').length) {
                    return;
                }
                $.submit_wait('.main:first', $.PAGE_WAITING_DIV);
                $.returnTop("#fixedtop");
                $('input[name=submit_flag]', '#guestNetworkForm').val("guest_network");
                $.postForm('#guestNetworkForm', '', function (json) {
                    if (json.status == '1') {
                        var time = parseInt(json.wait) * 1000;
                        setTimeout(function () {
                            $(".running").remove();
                        }, time);
                    } else {
                        $(".running").remove();
                        $.alertBox(json.msg, '', function () { location.href = '/guestNetwork.htm'; });
                    }
                });
            }
            $('#cancelBt').click(function () {
                if ($.check_running())
                    return;
                document.location.reload();
            });
            $('#cancelBt1').click(function () {
                if ($.check_running())
                    return;
                document.location.reload();
            });
        }
    }); // end ready function

}(jQuery));
