/**
 * For password Settings page
 */
(function ($) {

        "use strict";

	var MIN_PWD_CHARACTERS = 8,
	timer = $.isChrome ? 1000 : 0;

	$(function () {
		/*******************************************************************************************
		 *
		 *       Password settings page
		 *
		 ******************************************************************************************/
		$.validatepassword = function(passwd) {
                        var disabled="img/checkbox-selected-gry.svg";
                        var enabled="img/checkbox-selected.svg";
                        var meet_complex=0, meet_len=0,no_same=0;
                        if(passwd == "" || passwd == "password"){
                        }
                        var re = new RegExp("[a-z]");
                        var len=re.test(passwd);
                        if(len){
                                $('#pwd_complex2').attr('src',enabled);
                                meet_complex++;
                        }else{
                                $('#pwd_complex2').attr('src',disabled);
                        }
                        re = new RegExp("[A-Z]");
                        len=re.test(passwd);
                        if(len)
                        {
                                $('#pwd_complex1').attr('src',enabled);
                                meet_complex++;
                        }else{
                                $('#pwd_complex1').attr('src',disabled);
                        }
                        re = new RegExp("[0-9]");
                        len=re.test(passwd);
                        if(len)
                        {
                                $('#pwd_complex3').attr('src',enabled);
                                meet_complex++;
                        }else{
                                $('#pwd_complex3').attr('src',disabled);
                        }
                        re = new RegExp("((?=[\x21-\x7e]+)[^A-Za-z0-9])");
                        len=re.test(passwd);
                        if(len)
                        {
                                $('#pwd_complex4').attr('src',enabled);
                                meet_complex++;
                        }else{
                                $('#pwd_complex4').attr('src',disabled);
                        }
                        if(meet_complex>2)
                                $('#pwd_complex').attr('src',enabled);
                        else
                                $('#pwd_complex').attr('src',disabled);
                        if(passwd.length>=6 && passwd.length<=32)
                        {
                                $('#pwd_len').attr('src',enabled);
                                meet_len=1;
                        }else{
                                $('#pwd_len').attr('src',disabled);
                        }
                        re = new RegExp("^.*(.)\\1{2}.*$");
                        len=re.test(passwd);
                        if(!len)
                        {
                                $('#pwd_identical').attr('src',enabled);
                                no_same=1;
                        }else{
                                $('#pwd_identical').attr('src',disabled);
                        }
                        if(meet_complex>2 && meet_len  && no_same){
                                $('#passwd_hint').css('display','none');
                                $('#pwd_warn').attr('src','img/check.jpg');
                                $('#pwd_sucess').attr('src',enabled);
                        }else{
                                $('#passwd_hint').css('display','block');
                                $('#pwd_warn').attr('src','img/warning_flag.jpg');
                                $('#pwd_sucess').attr('src',disabled);
                        }
                }

		if ($('.pwdSettings').length) {
			if(security_enhance_flag == "1"){
				var focus_trigger_flag1 = 0;
				var focus_trigger_flag2 = 0;
				//$('#answer1').attr('type', 'text');
				//$('#answer2').attr('type', 'text');
			}
			//init
			if ( $("#pwdOn").is(':checked') ) {
				$('.pwdSettingsOptions').slideDown();
				$('.recoveryPwd').slideDown();
				$('.recoveryPwdOptions').slideDown();
			} else {
				$('.pwdSettingsOptions').slideUp();
				$('.recoveryPwd').slideUp();
				$('.recoveryPwdOptions').slideUp();
			}

			// show/hide the password settings
			$("#pwdOn").on('change', function () {
				$('.pwdSettingsOptions').slideDown();
				$('.recoveryPwd').slideDown();
				$('.recoveryPwdOptions').slideDown();
			});

			$("#pwdOff").on('change', function () {
				$('.pwdSettingsOptions').slideUp();
				$('.recoveryPwd').slideUp();
				$('.recoveryPwdOptions').slideUp();
			});

			$('#newUserName').blur(function() {
				var str = $('#newUserName').val();
				$('#err_email').remove();
				if ( !$.REG_EMAIL.test(str) )
					$.addErrMsgAfter('newUserName', invalid_username, false, 'err_email');
			});

			$('#newUserName').keyup(function() {
				var str = $('#newUserName').val();
				if ( $.REG_EMAIL.test(str) ) {
					$('#err_email').remove();
				}
			});

			$('.primaryPwd').blur(function () {
				var pwd = $(this).val();
				$('#err_passformat').remove();
				if ( pwd == '' )
					$.addErrMsgAfter('newPwd', pwd_should +" 6-32 "+ characters, false, 'err_passformat');
				else
					$('.verifyPwd').prop('disabled', false);
			});

			$('.primaryPwd').keyup(function () {
				var pwd = $(this).val(),
				pwd2 = $('.verifyPwd').val();

				if(security_enhance_flag == "1"){
                                        var wait = 1000;
                                        var timeoutID = null;
                                        clearTimeout(timeoutID);
                                        timeoutID = setTimeout(function() { $.validatepassword(pwd);}, wait);
                                }

				if (pwd.length > 0 ) {
					$('#err_passformat').remove();
					$('.verifyPwd').prop('disabled', false);
				} else {
					$('.verifyPwd').prop('disabled', true);
				}
				if( pwd2 != '' && pwd != pwd2 ){
					if(!$('.verifyPwd').hasClass('alert'))
						$('.verifyPwd').addClass('alert')
					if(!$('#errPwdSame').length())
						$.addErrMsgAfter('newPwdVerify', error_not_same_pwd, false, 'errPwdSame');
				}else if(pwd == pwd2){
					$('.verifyPwd').removeClass('alert');
					$('#errPwdSame').remove();
				}
			});

			$('.primaryPwd').keydown(function () {
                                if(security_enhance_flag =="1")
                                {
                                        $('#pwd_warn').css('display','');
                                        $('#passwd_hint').css('display','none');
                                }
                        });

		/*	$('.primaryPwd').focus(function () {
				var pwd = $(this).val();
				$('.verifyPwd').val('').removeClass('alert');
				$('#errPwdSame').remove();
			});*/

			$('.verifyPwd').blur(function () {
				var pwd = $('.primaryPwd').val(),
				pwd2 = $(this).val();
				$('#errPwdSame').remove();
				if ( pwd != pwd2 ) {
					$('.verifyPwd').addClass('alert');
					$.addErrMsgAfter('newPwdVerify', error_not_same_pwd, false, 'errPwdSame');
				}else {
					$('.verifyPwd').removeClass('alert');
					$('#errPwdSame').remove();
				}
			});

			$('.verifyPwd').keyup(function () {
				var pwd = $('.primaryPwd').val(),
				pwd2 = $(this).val();
				if ( pwd == pwd2 ) {
					$('.verifyPwd').removeClass('alert');
					$('#errPwdSame').remove();
				}
			});

			$('#answer1').focus(function () {
				if(security_enhance_flag =="1" && focus_trigger_flag1 == "0")
				{
					//$('#answer1').attr('type', 'text');
					$('#answer1').val('');
					focus_trigger_flag1 = 1;
				}
			});

			$('#answer2').focus(function () {
                                if(security_enhance_flag == "1" && focus_trigger_flag2 == "0")
                                {
                                        //$('#answer2').attr('type', 'text');
                                        $('#answer2').val('');
                                        focus_trigger_flag2 = 1;
                                }
                        });

			setTimeout(function(){
				$('#newUserName').val("");
				$('#newPwd').val("");
				$('#newPwdVerify').val("");
				$('#newUserName').removeAttr("style");
			}, $.chromeTimer);

			$('#saveBt').click(function () {
				$('.errorMsg').remove();
				if(security_enhance_flag == "1"){
					$('#hid_answer1_change').val(focus_trigger_flag1);
					$('#hid_answer2_change').val(focus_trigger_flag2);
				}

				var onoff = 0;
				if ( $("#pwdOn").is(":checked") ) {
					onoff = 1;
					if ( !$.REG_EMAIL.test($('#newUserName').val()) ) {
						$.addErrMsgAfter('newUserName', invalid_username, false, 'err_email');
						$("body,html").animate({scrollTop:0}, 200);
						return false;
					}
					if ( !$.REG_PASSWORD.test($('#newPwd').val()) ) {
						$.addErrMsgAfter('newPwd', pwd_should +" 6-32 "+ characters, false, 'err_passformat');
						$("body,html").animate({scrollTop:0}, 200);
						return false;
					}
					if ( $('#newPwd').val() == "password"){
						$.addErrMsgAfter('newPwd', not_password, false, 'err_passformat');
						$("body,html").animate({scrollTop:0}, 200);
						return false;
					}
					if ($('#newPwd').val() != $('#newPwdVerify').val() && $('#newPwd').val() != '' ) {
						$('.verifyPwd').addClass('alert');
						$.addErrMsgAfter('newPwdVerify', error_not_same_pwd, false, 'errPwdSame');
						$("body,html").animate({scrollTop:0}, 200);
						return false;
					}

					if ($('#question1').val() == 0 ) {
						$.addErrMsgAfter('question1', error_no_question);
					}
					if(security_enhance_flag != "1" || focus_trigger_flag1 == "1")
					{
						if (!$.REG_ANSWER.test($('#answer1').val())) {
							$.addErrMsgAfter('answer1', invalid_answer, false, 'err_invalid_answer1');
						}
					}
					if ($('#answer1').val().length == 0 ) {
						$.addErrMsgAfter('answer1', error_no_answer, false, 'err_null_answer1');
					}

					if ($('#question2').val() == 0 ) {
						$.addErrMsgAfter('question2', error_no_question);
					}
					if(security_enhance_flag != "1" || focus_trigger_flag2 == "1")
					{
						if (!$.REG_ANSWER.test($('#answer2').val())) {
							$.addErrMsgAfter('answer2', invalid_answer, false, 'err_invalid_answer2');
						}
					}
					if ($('#answer2').val().length == 0 ) {
						$.addErrMsgAfter('answer2', error_no_answer, false, 'err_null_answer2');
					}
				}

					function postPwdForm(json) {
						if ( json.status == "1" ) {
							if( typeof(json.reset) != 'undefined') {
								$.removeCookie('session');
								location.href = json.url;
							} else {
								setTimeout("$('.running').remove();", parseInt(json.wait, 10) * 1000);
							}
						} else {
							$('.running').remove();
							$.alertBox(json.msg);
						}
					}
				var pwdAnswer1 = $('#answer1').val();
				var pwdAnswer2 = $('#answer2').val();
				if (0 == focus_trigger_flag1)
				{
					pwdAnswer1 = "";
				}
				if (0 == focus_trigger_flag2)
				{
					pwdAnswer2 = "";
				}

				if (!$('.errorMsg').length) {
					$.submit_wait('.main:first', $.PAGE_WAITING_DIV);
					$.ajax({
						url: $('#pwdSettingsForm').attr("action"),
						type: "POST",
						data: $.generatePostData($.param({
							"submit_flag": "passwd",
							"hid_answer1_change": focus_trigger_flag1,
							"hid_answer2_change": focus_trigger_flag2,
							"onoff": onoff,
							"new_username": $.base64.encode($('#newUserName').val()),
							"new_pwd": $.base64.encode($('#newPwd').val()),
							"verify_pwd": $.base64.encode($('#newPwdVerify').val()),
							"question1": $('#question1').val(),
							"answer1": pwdAnswer1,
							"question2": $('#question2').val(),
							"answer2":pwdAnswer2,
							"anticsrf": csrfToken
						})),
						dataType: 'json',
						contentType: "application/x-www-form-urlencoded; charset=utf-8",
						success: postPwdForm,
						error: function () {
							var json = { "status": "0", "msg": "400 Bad Request!" };
							$('.running').remove();
							$.alertBox(json.msg);
						}
					});
				}
			});

			$('#cancelBt').click(function () {
				document.location.reload();
			});
		} // end password settings page
		
	}); // end ready function
}(jQuery));
