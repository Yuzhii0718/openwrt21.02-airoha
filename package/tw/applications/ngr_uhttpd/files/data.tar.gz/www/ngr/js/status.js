/*
 For status page
*/
(function($) {
    $(function() {
        var t1;
        $.auto_check = function() {
            $.getData('auto_get_status.htm', function(json) {
                $('body').removeClass('updateInfo');
                if (json.wan_status == "1") {
                    if (json.status == 9999) {
                        // has new version
                        if (json.new_version != "" && $('#statusForm').length) {
                            if (json.popped_up != "1") {
                                $.confirmBox(have_new_fw, update, function() {
                                    $('body').append($.WAITING_DIV);
                                    $.postForm('#statusForm', '', function() {
                                        location.href = "/fwUpdate.htm?check=1" + $.ID_1;
                                    });
                                }, cancel_mark, function() {
                                    $.postForm('#statusForm', '', null);
                                });
                            }
                            $('a', '.updateInfo').attr("href", "/fwUpdate.htm?check=1" + $.ID_1);
                            $('.updateInfo').show();
                            $('h1:first', '#statusForm').hide();
                        }
                    } else if (json.status >= 10000) {
                        // do nothing 10000 > no internet, 10001 > no new version, 10002 > ctrl file fail
                    } else {
                        // not get result yet, check again
                        clearTimeout(t1);
                        t1 = setTimeout('$.auto_check();', 2 * 1000);
                    }
                }
            });
        };

        function on_off(mark) {
            if (mark == "on") return on_mark;
            else return off_mark;
        }

        function configured_or_not(mark) {
            if (mark == "configured") return configured;
            else return not_configured;
        }

        function mode_string(mark) {
            if (mark == "54") return wlan_mode_54;
            else if (mark == "192") return wlan_mode_192;
            else if (mark == "173") return wlan_mode_173;
            else if (mark == "400") return wlan_mode_400;
            else if (mark == "347") return wlan_mode_347;
            else if (mark == "866") return wlan_mode_866;
            else if (mark == "1733") return wlan_mode_1733;
            else if (mark == "270") return wlan_mode_270;
            else if (mark == "286") return wlan_mode_286;
            else if (mark == "450") return wlan_mode_450;
            else if (mark == "1300") return wlan_mode_1300;
            else if (mark == "542") return wlan_mode_542;
            else if (mark == "600") return wlan_mode_600;
            else if (mark == "1134") return wlan_mode_1134;
            else if (mark == "1200") return wlan_mode_1200;
            else if (mark == "2400") return wlan_mode_2400;
			else if (mark == "300") return wlan_mode_300;
			else if (mark == "150") return wlan_mode_150;
            else if (mark == "135") return wlan_mode_135;
            else if (mark == "216") return wlan_mode_216;
            else if (mark == "289") return wlan_mode_289;
            else if (mark == "867") return wlan_mode_867;
            else if (mark == "229") return wlan_mode_229;
            else if (mark == "460") return wlan_mode_460;
            else if (mark == "1440") return wlan_mode_1440;
            else if (mark == "2882") return wlan_mode_2882;
            else if (mark == "4323") return wlan_mode_4323;
            else if (mark == "2160") return wlan_mode_2160;
            else if (mark == "1032") return wlan_mode_1032;
            else if (mark == "516") return wlan_mode_516;
            else if (mark == "344") return wlan_mode_344;
            else if (mark == "688") return wlan_mode_688;
            else if (mark == "288") return wlan_mode_288;
            else if (mark == "1300") return wlan_mode_1300;
            else if (mark == "2340") return wlan_mode_2340;
            else return wlan_mode_54;
        }
        function region_switch(mark) {
            var coun_map = [
                coun_af, coun_as, coun_au, coun_ca,
                coun_eu ,coun_is, coun_jp, coun_ko,
                coun_mx ,coun_sa, coun_us, china, 
                india   ,malaysia, null, null, 
                EXT_STR0554, EXT_STR0522,EXT_STR0560,coun_ru,
                singapore, EXT_STR0544, null, null, null, EXT_STR0432
            ];
            return coun_map[mark] || coun_eu;
            if (mark == "Africa") //wl_country=='0"
                return coun_af;
            else if (mark == "Asia") //1
                return coun_as;
            else if (mark == "Australia") //2
                return coun_au;
            else if (mark == "Canada") //3
                return coun_ca;
            else if (mark == "China") //11
                return china;
            else if (mark == "Europe") //4
                return coun_eu;
            else if (mark == "India") //12
                return india;
            else if (mark == "Israel") //5
                return coun_is;
            else if (mark == "Japan") //6
                return coun_jp;
            else if (mark == "Korea") //7
                return coun_ko;
            else if (mark == "Malaysia") //13
                return malaysia;
            else if (mark == "Mexico") //8
                return coun_mx;
            else if (mark == "Turkey") //16
                return EXT_STR0554;
            else if (mark == "Saudi Arabia") //17
                return EXT_STR0522;
            else if (mark == "United Arab Emirates") //18
                return EXT_STR0560;
            else if (mark == "Russia") //19
                return coun_ru;
            else if (mark == "Singapore") //20
                return singapore;
            else if (mark == "South America") //9
                return coun_sa;
            else if (mark == "Taiwan, Province of China") //21
                return EXT_STR0544;
            else if (mark == "United States") //10
                return coun_us;
            else if (mark == "Hong Kong") //25
                return EXT_STR0432;
            else return coun_eu;
        }
        /*******************************************************************************************
         *
         * init  page
         *
         *******************************************************************************************/
        if ($('#statusForm').length) {
            $.getData("refresh_status.aspx", function(json) {
                link_status = json.wifi0.sta_info.connection_status
                link_status_5g = json.wifi1.sta_info.connection_status
                refreshStatusPage();
                if (connectType == "0")
                {
                    $("#slider .main.clearfix h1").attr("class","accesspoint " + json.uplinkstate.stateClass)
                }
                else
                {
                    $("#slider .main.clearfix h1").attr("class","extender " + json.uplinkstate.stateClass)
                }
                $("#slider .main.clearfix h1").show()
                $('.version.clearfix strong:first').html(json.version.hardware_version);
                $('.version.clearfix strong:eq(1)').html(json.version.firmware_version);
                //wifi0
                $('.loc1').addClass(json.wifi0.sta_info.leaf_color || "gray");
                $('.loc2').addClass(json.wifi0.ap_info.leaf_color || "gray");
                $('.column.extender.first ul strong:first').html(json.wifi0.sta_info.leaf_rate + 'Mbps');
                //signal_strength
                $("#signalStrength2g .signalStrength").attr("class", "signalStrength " + json.wifi0.sta_info.signal_strength)
                $('.column.extender.first ul strong:eq(1)').html(json.wifi0.sta_info.ssid.replace(/&nbsp;/g, ' '));
                $('.column.extender.first ul strong:eq(2)').html(json.wifi0.sta_info.leaf_channel);
                $('.column.extender.first ul strong:eq(3)').html(json.wifi0.sta_info.connection_status == "1" ? client_con_mark : client_discon_mark);
                $('.column.apmode.first ul strong:eq(1)').html(json.wifi0.sta_info.connection_status == "1" ? client_con_mark : client_discon_mark);
                $('.column.apmode.second ul strong:eq(1)').html(json.wifi1.sta_info.connection_status == "1" ? client_con_mark : client_discon_mark);
                $('.column.apmode.third ul strong:eq(1)').html(json.wifi2.sta_info.connection_status == "1" ? client_con_mark : client_discon_mark);
                $('.column.wifi.first ul strong:first').html(json.wifi0.ap_info.ssid.replace(/&nbsp;/g, ' '));
                $('.column.wifi.first ul strong:eq(1)').html(json.wifi0.ap_info.channel);
                $('.column.wifi.first ul strong:eq(2)').html(region_switch(json.wifi0.ap_info.region));
                $('.column.wifi.first ul strong:eq(3)').html(mode_string(json.wifi0.ap_info.wireless_mode));
                $('.column.wifi.first ul strong:eq(4)').html(on_off(json.wifi0.ap_info.wireless_ap));
                $('.column.wifi.first ul strong:eq(5)').html(on_off(json.wifi0.ap_info.broadcast_name));
                $('.column.wifi.first ul strong:eq(6)').html(configured_or_not(json.wifi0.ap_info.wps));
                $('.column.wifi.first ul strong:eq(7)').html($.formatSecType(json.wifi0.ap_info.security_type));
                $('#cc24gSta').html('CH ' + json.wifi0.sta_info.leaf_channel + ', ' + json.wifi0.sta_info.leaf_rate + 'Mbps');
                $('#cc24gAp').html('CH ' + json.wifi0.ap_info.leaf_channel + ', ' + mode_string(json.wifi0.ap_info.leaf_mode));
                if (have_guest_network == "1") {
                    $('.column.guest.first ul strong:first').html(json.wifi0.guest_info.ssid.replace(/&nbsp;/g, ' '));
                    $('.column.guest.first ul strong:eq(1)').html(on_off(json.wifi0.guest_info.wireless_ap));
                    $('.column.guest.first ul strong:eq(2)').html(on_off(json.wifi0.guest_info.broadcast_name));
                    $('.column.guest.first ul strong:eq(3)').html(on_off(json.wifi0.guest_info.allow_to_local));
                }
                if (sta_5g == "1") {
                    $('.loc3').addClass(json.wifi1.ap_info.leaf_color || "gray");
                    $('.loc4').addClass(json.wifi1.sta_info.leaf_color || "gray");
                } else {
                    $('.loc3').addClass(json.wifi2.ap_info.leaf_color || "gray");
                    $('.loc4').addClass(json.wifi2.sta_info.leaf_color || "gray");
                }
                //wifi1
                $('.column.extender.second ul strong:first').html(json.wifi1.sta_info.leaf_rate + 'Mbps');
                //signal_strength
                $("#signalStrength5g .signalStrength").attr("class", "signalStrength " + json.wifi1.sta_info.signal_strength)
                $('.column.extender.second ul strong:eq(1)').html(json.wifi1.sta_info.ssid.replace(/&nbsp;/g, ' '));
                $('.column.extender.second ul strong:eq(2)').html(json.wifi1.sta_info.leaf_channel);
                $('.column.extender.second ul strong:eq(3)').html(json.wifi1.sta_info.connection_status == "1" ? client_con_mark : client_discon_mark);
                $('.column.wifi.second ul strong:first').html(json.wifi1.ap_info.ssid.replace(/&nbsp;/g, ' '));
                $('.column.wifi.second ul strong:eq(1)').html(json.wifi1.ap_info.channel);
                $('.column.wifi.second ul strong:eq(2)').html(region_switch(json.wifi1.ap_info.region));
                $('.column.wifi.second ul strong:eq(3)').html(mode_string(json.wifi1.ap_info.wireless_mode));
                $('.column.wifi.second ul strong:eq(4)').html(on_off(json.wifi1.ap_info.wireless_ap));
                $('.column.wifi.second ul strong:eq(5)').html(on_off(json.wifi1.ap_info.broadcast_name));
                $('.column.wifi.second ul strong:eq(6)').html(configured_or_not(json.wifi1.ap_info.wps));
                $('.column.wifi.second ul strong:eq(7)').html($.formatSecType(json.wifi1.ap_info.security_type));
                $('#cc5gSta').html('CH ' + json.wifi1.sta_info.leaf_channel + ', ' + json.wifi1.sta_info.leaf_rate + 'Mbps');
                $('#cc5gAp2').html('CH ' + json.wifi1.ap_info.leaf_channel + ', ' + mode_string(json.wifi1.ap_info.leaf_mode));
                if (have_guest_network == "1") {
                    $('.column.guest.second ul strong:first').html(json.wifi1.guest_info.ssid.replace(/&nbsp;/g, ' '));
                    $('.column.guest.second ul strong:eq(1)').html(on_off(json.wifi1.guest_info.wireless_ap));
                    $('.column.guest.second ul strong:eq(2)').html(on_off(json.wifi1.guest_info.broadcast_name));
                    $('.column.guest.second ul strong:eq(3)').html(on_off(json.wifi1.guest_info.allow_to_local));
                }
                //wifi2
                $('.column.extender.third ul strong:first').html(json.wifi2.sta_info.signal_strength + 'Mbps');
                $('.column.extender.third ul strong:eq(1)').html(json.wifi2.sta_info.ssid.replace(/&nbsp;/g, ' '));
                $('.column.extender.third ul strong:eq(2)').html(json.wifi2.sta_info.leaf_channel);
                $('.column.extender.third ul strong:eq(3)').html(json.wifi2.sta_info.connection_status == "1" ? client_con_mark : client_discon_mark);
                $('.column.wifi.third ul strong:first').html(json.wifi2.ap_info.ssid.replace(/&nbsp;/g, ' '));
                $('.column.wifi.third ul strong:eq(1)').html(json.wifi2.ap_info.channel);
                $('.column.wifi.third ul strong:eq(2)').html(region_switch(json.wifi2.ap_info.region));
                $('.column.wifi.third ul strong:eq(3)').html(mode_string(json.wifi2.ap_info.wireless_mode));
                $('.column.wifi.third ul strong:eq(4)').html(on_off(json.wifi2.ap_info.wireless_ap));
                $('.column.wifi.third ul strong:eq(5)').html(on_off(json.wifi2.ap_info.broadcast_name));
                $('.column.wifi.third ul strong:eq(6)').html(configured_or_not(json.wifi2.ap_info.wps));
                $('.column.wifi.third ul strong:eq(7)').html($.formatSecType(json.wifi2.ap_info.security_type));
                $('#cc_5g_sta2').html('CH ' + json.wifi2.sta_info.leaf_channel + ', ' + json.wifi2.sta_info.leaf_rate + 'Mbps');
                $('#cc_5g_ap2').html('CH ' + json.wifi2.ap_info.leaf_channel + ', ' + mode_string(json.wifi2.ap_info.leaf_mode));
                if (have_guest_network == "1") {
                    $('.column.guest.third ul strong:first').html(json.wifi2.guest_info.ssid.replace(/&nbsp;/g, ' '));
                    $('.column.guest.third ul strong:eq(1)').html(on_off(json.wifi2.guest_info.wireless_ap));
                    $('.column.guest.third ul strong:eq(2)').html(on_off(json.wifi2.guest_info.broadcast_name));
                    $('.column.guest.third ul strong:eq(3)').html(on_off(json.wifi2.guest_info.allow_to_local));
                }
                
            });

            function refreshStatusPage() {
                var is_special_region = have_location == "1" && special_region == "1" && dLocation == "outdoor";
                var apmode_obj, extender_obj;
                if (have_wireless_an == "1") {
                    apmode_obj = $('.column.apmode');
                    extender_obj = $('.column.extender');
                } else {
                    apmode_obj = $('.wifiStatus:last');
                    extender_obj = $('.wifiStatus:first');
                }
                if (connectType == "0") { //ap mode
                    apmode_obj.show();
                    extender_obj.hide();
                    $('#wifi24g').html(EXT_STR0293);
                    $('#wifi5g').html(EXT_STR0294);
                    //$('#wifi5g2').html(EXT_STR0294);
                    $('.column').addClass('ap');
                    $('.column.third.wifi').css('display', 'none');
                    //EAX15 no third wifi,hide all third wifi info
                    $('.column.apmode.third').css('display', 'none');
                    $('.column.third.guest').css('display', 'none');
                    $('#cc24gAp').hide();
                    $('#cc_5g_ap2').hide();
                    if (have_guest_network == "1") {
                        $('.column.first.guest').css('display', 'block');
                        $('.column.second.guest').css('display', 'block');
                        $('.column.third.guest').css('display', 'none');
                        $('#guest24g').html(guest_status_ap_24g);
                        $('#guest5g').html(guest_status_ap_5g);
                        //$('#guest_5g2').html(guest_status_ap_5g2);
                    }
                } else { //repeater mode
                    apmode_obj.hide();
                    $('#wifi24g').html(EXT_STR0588);
                    $('#wifi5g').html(EXT_STR0589);
                    $('#wifi5g2').html(EXT_STR0589);
                    $('.column').removeClass('ap');
                    $('#cc24gSta').hide();
                    $('#cc24gAp').hide();
                    //EAX15 no third wifi,hide all third wifi info
                    $('.column.extender.third.existing').css('display', 'none');
                    $('.column.third.wifi').css('display', 'none');
                    $('.column.third.guest').css('display', 'none');
                    //alert(fastlane_surfing);  
                    //alert(furfing_mode_type);                
                    if (fastlane_surfing == "1") //repeater fastlane mode
                    {
                        if (furfing_mode_type == "5G" || is_special_region) // 5G fastlane
                        {
                            //alert("sta_5g=============>1");
                            $('.column.extender.first.existing').css('display', 'none');
                            $('.column.extender.second.existing').css('display', 'block');
                            $('.column.first.wifi').css('display', 'block');
                            $('.column.first.guest').css('display', 'block');
                            $('.column.second.wifi').css('display', 'none');
                            $('.column.second.guest').css('display', 'none');
                            $('.column.third.wifi').css('display', 'none');
                            $('.column.third.guest').css('display', 'none');
                            $('#cc5gSta').hide();
                            if (is_special_region) {
                                $('#cc5gSta').hide();
                                $('#cc_5g_sta2').hide();
                            }
                            $('#cc_5g_ap2').hide();
                            if (have_guest_network == "1") {
                                $('.column.first.guest').css('display', 'block');
                                $('.column.second.guest').css('display', 'none');
                                //EAX15 no third wifi,hide all third wifi info
                                $('.column.third.guest').css('display', 'none');
                                $('#guest24g').html(guest_status_24g);
                                $('#guest5g').html(guest_status_5g);
                            }
                            //EAX15 no third wifi,hide all third wifi info
                            $('.column.extender.third.existing').css('display', 'none');
                            $('.column.third.wifi').css('display', 'none');
                            $('.column.third.guest').css('display', 'none');
                        } else // 2.4G fastlane
                        {
                            //alert("sta_5g=============>0");
                            $('.column.extender.first.existing').css('display', 'block');
                            $('.column.extender.second.existing').css('display', 'none');
                            $('.column.first.wifi').css('display', 'none');
                            $('.column.first.guest').css('display', 'none');
                            $('.column.second.wifi').css('display', 'block');
                            $('.column.second.guest').css('display', 'block');
                            $('.column.third.wifi').css('display', 'none');
                            $('.column.third.guest').css('display', 'none');
                            $('#cc_5g_sta2').hide();
                            $('#cc5gAp2').hide();
                            if (have_guest_network == "1") {
                                $('.column.first.guest').css('display', 'none');
                                $('.column.second.guest').css('display', 'block');
                                //EAX15 no third wifi,hide all third wifi info
                                $('.column.third.guest').css('display', 'none');
                                $('#guest24g').html(guest_status_24g);
                                $('#guest5g').html(guest_status_5g);
                            }
                            //EAX15 no third wifi,hide all third wifi info
                            $('.column.extender.third.existing').css('display', 'none');
                            $('.column.third.wifi').css('display', 'none');
                            $('.column.third.guest').css('display', 'none');
                        }
                        $('.column.apmode.third').css('display', 'none');
                        if (furfing_mode_type == "5G" || is_special_region) // 5G fastlane
                        {
                            $('.column.extender.first.existing').css('display', 'none');
                            $('.column.extender.second.existing').css('display', 'block');
                            $('.column.extender.third.existing').css('display', 'none');
                        } else {
                            $('.column.extender.first.existing').css('display', 'block');
                            $('.column.extender.second.existing').css('display', 'none');
                            $('.column.extender.third.existing').css('display', 'none');
                        }
                    } else //repeater basic mode
                    {
                        extender_obj.show();
                        $('#cc_5g_ap2').hide();
                        $('#cc_5g_sta2').hide();
                        $('.column.extender.first.existing').css('display', 'block');
                        $('.column.extender.second.existing').css('display', 'block');
                        $('.column.first.wifi').css('display', 'block');
                        $('.column.first.guest').css('display', 'block');
                        $('.column.second.wifi').css('display', 'block');
                        $('.column.second.guest').css('display', 'block');
                        $('.column.third.wifi').css('display', 'none');
                        $('.column.third.guest').css('display', 'none');
                        $('#guest24g').html(guest_status_24g);
                        $('#guest5g').html(guest_status_5g);
                    }
                    if (link_status_5g == "1") {
                        if (host_name.toUpperCase() == 'EX7700') {
                            if (sta_5g == "2") $('#backhaul5glow').show();
                        } else {
                            if (sta_5g == "1") {
                                $('#backhaul5glow').show();
                            }
                        }
                    } else if (link_status == "1") {
                        $('#backhaul2g').show();
                    }
                }
                if (link_status == "1" || (link_status == "0" && wlg_sta_ssid != "12345678NETGEAR")) $('.column.extender.first.existing ul strong:eq(1)').show();
                else $('.column.extender.first.existing ul strong:eq(1)').hide();
                if (link_status == "0") $('.column.extender.first.existing ul li:eq(2)').hide();
                if (sta_5g == "2" || is_special_region) {
                    $('.column.extender.third.existing').hide();
                    if (link_status_5g == "1" || (link_status_5g == "0" && wla_2nd_sta_ssid != "12345678NETGEAR-5G")) $('.column.extender.second.existing ul strong:eq(1)').show();
                    else $('.column.extender.third.existing ul strong:eq(1)').hide();
                } else {
                    $('.column.extender.third.existing').hide();
                    if (link_status_5g == "1" || (link_status_5g == "0" && wla_sta_ssid != "12345678NETGEAR-5G")) $('.column.extender.second.existing ul strong:eq(1)').show();
                    else $('.column.extender.second.existing ul strong:eq(1)').hide();
                }
                if (link_status_5g == "0" || link_status_5g == "") {
                    $('.column.extender.second.existing ul li:eq(2)').hide();
                    $('.column.extender.third.existing ul li:eq(2)').hide();
                }
                var curLang = $("#language option:selected").text();
                if ('Español' == curLang || 'Polski' == curLang) {
                    $('#smartSetupBt').css('font-size', '13px');
                } else if ('Čeština' == curLang) {
                    $('#smartSetupBt').css('font-size', '12px');
                } else if ('Română' == curLang) {
                    $('#smartSetupBt').css('font-size', '10px');
                }
                var cur_browser = $.getBrowser();
                if ('IE' == cur_browser) {
                    var obj1 = $('.column.extender.first.existing');
                    var obj2 = $('.column.first.wifi');
                    if (obj1.find('.status_ssid').find('strong').innerWidth() + 10 > obj1.innerWidth()
                        || obj2.find('.status_ssid').find('strong').innerWidth() + 10 > obj2.innerWidth())
                        $('.networkWrap').css('display', 'table-header-group');
                } else if ('Chrome' == cur_browser || 'Opera' == cur_browser) {
                    $('.networkWrap').css('display', '-webkit-flex');
                }
                if (fastlane_surfing == "1" && connectType != "0") {
                    $('.networkWrap').css('display', 'inline');
                    $('.column.first.null').css('display', 'block');
                    $('.networkWrap_copy').css('display', 'inline');
                    //$('.column.extender.first.existing').css('display', 'inline');
                    //$('.column.first.wifi').css('display', 'inline');
                    //$('.column.second.first.existing').css('display', 'inline');
                    //$('.column.second.wifi').css('display', 'inline');
                }
            }
            //refreshStatusPage();
            if (sta_5g == "2")
            {
                $('.column.extender.third.existing').hide();
                $('.column.apmode.third').hide();
            }
            
        }
        /*else if ( !$('body.setup').length  && $.getUrlParam('check') != '1') {
                                $.auto_check();
                        }*/
    }); // end ready function
}(jQuery));