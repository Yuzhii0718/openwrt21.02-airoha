{
	"led_state": "<% cat_file("/tmp/led_state") %>",
	"led_btn_state": "<% cat_file("/proc/simple_config/led_btn_state") %>",
	"ntp_updated": "<% access_file("/tmp/ntp_updated") %>",
	"led_on": "<% cfg_get("led_on") %>",
	"led_light": "<% cfg_get("led_light") %>",
	"led_light3": "<% cfg_get("led_light3") %>"
}
