{
	"list": [
		<% led_schedule_json() %>
	]
}
