<% mobile_wait_for_search() %>
