<% start_netscan() %>
{
	"status": "1"
}
