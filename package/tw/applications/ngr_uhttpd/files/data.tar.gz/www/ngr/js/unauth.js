/**
 * For setup flow
 */
(function ($) {

	"use strict";

	$(function () {
		if (typeof (no_auth) != 'undefined' && no_auth == "1") {
			location.href = "start.htm" + $.ID_2;
		}


		if ($('#recover').length) {
			$('#continue').click(function () {
				$("#continue").prop('disabled', true);
				$('.errorMsg').remove();
				$.submit_wait('body', $.WAITING_DIV);
				$.postForm('#recover', '', function (json) {
					$("#continue").prop('disabled', false);
					$('.running').remove();
					if (json.status == '1') {
						if (json.url == "user_passwd_help.html" || json.url == "unauth.html") {
							location.href = json.url;
						} 
					} else {
						$('.running').remove();
						//$.alertBox(json.msg);
					}
				});
			});
		}
	}); // end ready function
}(jQuery));
