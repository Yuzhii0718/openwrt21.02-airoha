﻿<% http_head("new_ext_setup","js/jquery.base64.js","js/jquery.dropkick-1.0.0.js","js/login.js","css/select.css") %>
<body class="reset">
<% top_bar_no_lang() %>
<% form_register("resetPwdForm", "status.htm", "passwd_reset") %>
    <div class="start">
        <div class="container">
			<div class="main">
              <table class="formTable">
		<tr>
			<td colspan="3"><label id="reset_title">$$pwd_reset</label></td>
		</tr>
		<tr>
			<td colspan="3"><b>$$reset_passwd</b></td>
		</tr>
                <tr>
			<td>$$EXT_STR0617</td>
			<td>
				<input type="text" id="resetName" name="new_username" placeholder="$$user_name" autocomplete="off" maxlength="32" />
			</td>
                </tr>
                <tr>
			<td>$$EXT_STR0618</td>
			<td>
				<input type="password" id="resetPwd" name="new_pwd" placeholder="$$passwd" autocomplete="off" maxlength="32" />
						<!--<span><img id="pwd_warn" src="" style="display:none; margin-top:10px;"></span>--!>
			</td>
			<td>
			    <img id="pwd_sucess" src="">
			</td>
		</tr>
		<tr id="passwd_hint" style="display:none;">
			<td></td>
			<td class="top0">
				<div id="passwd_hint_content" style="max-width:500px;">
					<ul style="padding-left: 0px;">
						<li>
                                                        <span>$$passwd_condition</span>
                                                </li>
                                                <li>
                                                        <ul style="padding-left:35px;">
                                                                <li>
                                                                        <img id="pwd_len" src="">
                                                                        <span>$$password_reset_conditions5_1</span>
                                                                </li>
                                                                <li>
                                                                        <img id="pwd_identical" src="">
                                                                        <span>$$password_reset_conditions6</span>
                                                                </li>
                                                       </ul>
                                                 </li>
                                                 <li>
                                                       <img id="pwd_complex" src="">
                                                       <span style="white-space: normal;">$$password_reset_tip3</span>
                                                 </li>
                                                 <li>
                                                       <ul style="padding-left:35px;">
                                                                <li>
                                                                       <img id="pwd_complex1" src="">
                                                                       <span>$$password_reset_conditions1</span>
                                                                </li>
                                                                <li>
                                                                       <img id="pwd_complex2" src="">
                                                                       <span>$$password_reset_conditions2</span>
                                                                </li>
                                                                <li>
                                                                       <img id="pwd_complex3" src="">
                                                                       <span>$$password_reset_conditions3</span>
                                                                </li>
                                                                <li>
                                                                       <img id="pwd_complex4" src="">
                                                                       <span>$$password_reset_conditions4</span>
                                                                </li>
                                                       </ul>
                                                </li>
					</ul>
				</div>
			</td>
		</tr>
		<tr>
			<td>$$EXT_STR0305</td>
			<td>
				<input type="password" id="resetPwdVerify" name="verify_pwd" placeholder="$$re_passwd" autocomplete="off" maxlength="32" disabled="disabled" />
			</td>
		</tr>
		<tr>
			<td>$$security_question_1*</td>
			<td class="securityQuestionForm">
				<select class="pwdQuestion" value="0" name="question1" id="resetQue1">
						<option value="0">$$select_a_question</option>
						<option value="1">$$quest1_1</option>
						<option value="2">$$quest1_2</option>
						<option value="3">$$quest1_3</option>
						<option value="4">$$quest1_4</option>
						<option value="5">$$quest1_5</option>
						<option value="6">$$quest1_6</option>
						<option value="7">$$quest1_7</option>
						<option value="8">$$quest1_8</option>
						<option value="9">$$quest1_9</option>
				</select>
			</td>
		</tr>
		<tr>
			<td>$$answer*</td>
			<td>
				<input type="text" class="answer" name="answer1" id="resetAn1" placeholder="$$answer" maxlength="64" autocomplete="off" onFocus="this.select();" />
			</td>
		</tr>
		<tr>
			<td>$$security_question_2*</td>
			<td class="securityQuestionForm">
				<select class="pwdQuestion" value="0" name="question2" id="resetQue2">
					<option value="0">$$select_a_question</option>
					<option value="1">$$quest2_1</option>
					<option value="2">$$quest2_2</option>
					<option value="3">$$quest2_3</option>
					<option value="4">$$quest2_4</option>
					<option value="5">$$quest2_5</option>
					<option value="6">$$quest2_6</option>
					<option value="7">$$quest2_7</option>
					<option value="8">$$quest2_8</option>
				</select>
			</td>
		</tr>
		<tr>
			<td>$$answer*</td>
			<td>
				<input type="text" class="answer" name="answer2" id="resetAn2" placeholder="$$answer" maxlength="64" autocomplete="off" onFocus="this.select();" />
			</td>
		</tr>
		<tr>
			<td>$$required_information</td>
		</tr>
	  </table>
          </div>
        </div>
        <!-- end main -->
      </div>
      <!-- end container -->
      <div id="fixedFooter">
        <div class="container">
          <footer>
            <div class="centerButtons">
              <div class="processButtons">
              <input id="nextStep" name="next" class="btn primary" type="button" value="$$EXT_STR0248" disabled>
            </div>
            </div>
          </footer>
      </div>
      </div>
      <div id="continue" hidden="">
		<div id="continueReset">
			<table class="formTable">
                                <tr>
                                        <td colspan="3"><label id="reset_title">$$pwd_reset</label></td>
                                </tr>
                                <tr>
                                        <td colspan="3"><b>$$recovered_succes</b></td>
                                </tr>
				<tr>
                                        <td colspan="3"><b>$$use_recovered_password_login</b></td>
                                </tr>
			</table>
		</div>
		<div id="fixedFooter">
			<div class="container">
                        <footer>
				<div class="centerButtons">
					<div class="processButtons">
						<a id="continueStep" name="next" class="btn primary" href="login.html">$$EXT_STR0248</a>
					</div>
				</div>
			</footer>
		</div>
	</div>
      <!-- end fixed footer -->
    </form>
  </body>
  </html>
