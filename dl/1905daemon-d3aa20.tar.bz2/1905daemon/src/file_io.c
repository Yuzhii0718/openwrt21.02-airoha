/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <syslog.h>
#include <errno.h>
#include <assert.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <sys/sem.h>
#include <stddef.h>
#include <unistd.h>

#include "p1905_managerd.h"
#include "multi_ap.h"
#include "cmdu_message.h"
#include "debug.h"
#ifdef EM_PLUS_SUPPORT
#include "emplus.h"
#endif

#define TOPOLOGY_DISCOVERY_COUNT 11     /*11 * 5s = 55s*/
#define DECRYPT_FAULURE_THRESHOLD 100

unsigned char BtoH(char ch)
{
    if (ch >= '0' && ch <= '9') return (ch - '0');        /* Handle numerals*/
    if (ch >= 'A' && ch <= 'F') return (ch - 'A' + 0xA);  /* Handle capitol hex digits*/
    if (ch >= 'a' && ch <= 'f') return (ch - 'a' + 0xA);  /* Handle small hex digits*/
    return(255);
}


void AtoH(char *src, char *dest, int destlen)
{
	unsigned char *srcptr = NULL;
	unsigned char *destTemp = NULL;
	unsigned char upperNibble = 0, lowerNibble = 0;

	srcptr = (unsigned char *)src;
	destTemp = (unsigned char *)dest;

	while (destlen--) {
		upperNibble = (unsigned char)(BtoH(*srcptr++) << 4);
		lowerNibble = (unsigned char)(BtoH(*srcptr++));
		*destTemp = (unsigned char)(upperNibble | lowerNibble);
		destTemp++;
	}
}

char * map_config_get_line(char *s,
	int size, FILE *stream, int *line, char **_pos)
{
	char *pos, *end, *sstart;

    while (fgets(s, size, stream)) {
        (*line)++;
        s[size - 1] = '\0';
        pos = s;

        /* Skip white space from the beginning of line. */
        while (*pos == ' ' || *pos == '\t' || *pos == '\r')
            pos++;

        /* Skip comment lines and empty lines */
        if (*pos == '#' || *pos == '\n' || *pos == '\0')
            continue;

        /*
         * Remove # comments unless they are within a double quoted
         * string.
		 */
        sstart = os_strchr(pos, '"');
        if (sstart)
            sstart = os_strrchr(sstart + 1, '"');
        if (!sstart)
            sstart = pos;
        end = os_strchr(sstart, '#');
        if (end)
            *end-- = '\0';
        else
            end = pos + os_strlen(pos) - 1;

        /* Remove trailing white space. */
        while (end > pos &&
               (*end == '\n' || *end == ' ' || *end == '\t' ||
            *end == '\r'))
            *end-- = '\0';

        if (*pos == '\0')
            continue;

		if (_pos)
            *_pos = pos;
        return pos;
    }

    if (_pos)
        *_pos = NULL;
    return NULL;
}


int _1905_write_mid(char* name, unsigned short mid)
{
	FILE *f;
	int fd;
	f = fopen(name, "w");
	if (f == NULL)
	{
		debug(DEBUG_ERROR, "[%d]Failed to open '%s' for writing, errno %d!\n",
			__LINE__, name, errno);
		return -1;
	}
	if (fprintf(f, "mid 0x%04x\n", mid) < 0) {
		debug(DEBUG_ERROR, "[%d]fprintf fail!\n", __LINE__);
		if (fclose(f) < 0)
			debug(DEBUG_ERROR, "[%d]fclose fail!\n", __LINE__);
		return -1;
	}
	fd = fileno(f);
	fsync(fd);
	if (fclose(f) < 0)
		debug(DEBUG_ERROR, "[%d]fclose fail, errno %d!\n", __LINE__, errno);
	return 0;
}

static char *get_line(char *s,
	int size, FILE *stream, unsigned int *line, char **_pos)
{
	char *pos, *end;

	while (fgets(s, size, stream)) {
		(*line)++;
		s[size - 1] = '\0';
		pos = s;

		/* Skip white space from the beginning of line. */
		while (*pos == ' ' || *pos == '\t' || *pos == '\r')
			pos++;

		/* Skip comment lines and empty lines */
		if (*pos == '#' || *pos == '\n' || *pos == '\0')
			continue;

		end = pos + os_strlen(pos) - 1;

		/* Remove trailing white space. */
		while (end > pos &&
			(*end == '\n' || *end == ' ' || *end == '\t' ||
			*end == '\r'))
			*end-- = '\0';

		if (*pos == '\0')
			continue;

		if (_pos)
			*_pos = pos;
		return pos;
	}

	if (_pos)
		*_pos = NULL;

	return NULL;
}



int _1905_read_set_config_cert(struct p1905_managerd_ctx *ctx, char *name,
	struct set_config_bss_info bss_info[], unsigned char max_bss_num,
	unsigned char *config_bss_num)
{
	FILE *f = NULL;
	unsigned int i = 0;
	char c_grp_id = 0;
	long int_grp_id = 0, index = 0, resv1 = 0, resv2 = 0;
	unsigned int mac_int[6] = {0}, line = 0;
	long authmode = 0, encrytype = 0;
	char *pos = NULL, *pos1 = NULL, *pos2 = NULL;
	char buf[512] = {0}, config_str[512] = {0};
	unsigned char fh_bss_unhidden = 0, num = 0, id = 0;
	char backslash = 0x5C, space = 0x20, SUB = 0x1A;
	unsigned int pvid = 0, vid = 0, pcp = 0;
	unsigned int dummy_len = 0, dummy_len1 = 0, dummy_len2 = 0;
	unsigned char dummy_ssid[MAX_SSID_LEN] = {0};
	char *endptr = NULL;

	if (!max_bss_num) {
		debug(DEBUG_ERROR, "input max_bss_num is 0, invaild");
		return -1;
	}

	f = fopen(name, "r");
	if (f == NULL) {
		debug(DEBUG_ERROR, "open file %s fail\n", name);
		return -1;
	}

	for (i = 0; i < max_bss_num; i++)
		memset(&bss_info[i], 0, sizeof(struct set_config_bss_info));

	while (get_line(buf, sizeof(buf) - 1, f, &line, &pos)) {
		num++;
		id = num - 1;
		if (num > max_bss_num) {
			debug(DEBUG_ERROR, "too much bss wireless setting info\n");
			break;
		}
		memset(config_str, 0, sizeof(config_str));
		/*rebuild the line due to ssid contains space*/
		/* If ssid is a space, need add \ as ESC infront of it in wts file. As space is regard as
		* a separator. If ssid is a \, need add \ as ESC in front of it. when parsing wts file,
		"\space"need remove \ and replace space to SUB. "\\"need remove \*/
		for (i = 0; i < strlen(pos); i++) {
			if (pos[i] == backslash) {
				if (pos[i + 1] == space) {
					config_str[i] = SUB;
					i++;
					continue;
				} else if (pos[i + 1] == backslash) {
					config_str[i] = backslash;
					i++;
					continue;
				}
			}
			config_str[i] = pos[i];
		}
		/*insert ' ' before '\0'*/
		config_str[i++] = ' ';
		config_str[i++] = '\0';
		debugbyte(DEBUG_TRACE, "line(%d)=%s\n", line, config_str);
		/*initialization*/
		bss_info[id].vid = INVALID_VLAN_ID;
		pos1 = config_str;
		/*index*/
		pos2 = strchr(pos1, ',');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "index not found\n");
			goto err;
		}
		*pos2 = '\0';

		errno = 0;
		index = strtol(pos1, &endptr, 10);
		if ((errno == ERANGE && (index == LONG_MAX || index == LONG_MIN))
			|| (errno != 0 && index == 0) || (endptr == pos1)) {
			debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
			goto err;
		}
		pos2++;
		pos1 = pos2;

		/*mac*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "mac not found\n");
			goto err;
		}
		*pos2 = '\0';
		if (sscanf(pos1, "%02x:%02x:%02x:%02x:%02x:%02x", mac_int,
			(mac_int + 1), (mac_int + 2), (mac_int + 3),
			(mac_int + 4), (mac_int + 5)) != 6) {
			debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
			goto err;
		}
		for (i = 0; i < 6; i++)
			bss_info[id].mac[i] = (unsigned char)mac_int[i];
		pos2++;
		pos1 = pos2;

		/*opclass*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "opclass not found\n");
			goto err;
		}
		*pos2 = '\0';
		if (sscanf(pos1, "%03s", bss_info[id].oper_class) != 1) {
			debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
			goto err;
		}
		bss_info[id].band_support = find_band_by_opclass(bss_info[id].oper_class);
		pos2++;
		pos1 = pos2;

		/*ssid*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "ssid not found\n");
			goto err;
		}
		*pos2 = '\0';
		if (sscanf(pos1, "%32s", bss_info[id].ssid) != 1) {
			debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
			goto err;
		}
		/*replace SUB to space for ssid*/
		bss_info[id].ssid_len = os_strlen(bss_info[id].ssid);
		for (i = 0; i < bss_info[i].ssid_len; i++) {
			if (bss_info[id].ssid[i] == SUB)
				bss_info[id].ssid[i] = space;
		}
		pos2++;
		pos1 = pos2;

		/*authmode*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "authmode not found\n");
			goto err;
		}
		*pos2 = '\0';

		errno = 0;
		authmode = strtol(pos1, &endptr, 16);
		if ((errno == ERANGE && (authmode == LONG_MAX || authmode == LONG_MIN))
			|| (errno != 0 && authmode == 0) || (endptr == pos1)) {
			debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
			goto err;
		}
		bss_info[id].authmode = (unsigned short)authmode;
		pos2++;
		pos1 = pos2;

		/*encrytype*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "encrytype not found\n");
			goto err;
		}
		*pos2 = '\0';

		errno = 0;
		encrytype = strtol(pos1, &endptr, 16);
		if ((errno == ERANGE && (encrytype == LONG_MAX || encrytype == LONG_MIN))
			|| (errno != 0 && encrytype == 0) || (endptr == pos1)) {
			debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
			goto err;
		}
		bss_info[id].encryptype = (unsigned short)encrytype;
		pos2++;
		pos1 = pos2;

		/*key*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "key not found\n");
			goto err;
		}
		*pos2 = '\0';
		if (sscanf(pos1, "%64s", bss_info[id].key) != 1) {
			debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
			goto err;
		}
		/*replace SUB to space for passphase*/
		for (i = 0; i < 64; i++) {
			if (bss_info[id].key[i] == SUB)
				bss_info[id].key[i] = space;
		}
		pos2++;
		pos1 = pos2;

		/*resv1*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "resv1 not found\n");
			goto err;
		}
		*pos2 = '\0';

		errno = 0;
		resv1 = strtol(pos1, &endptr, 10);
		if ((errno == ERANGE && (resv1 == LONG_MAX || resv1 == LONG_MIN))
			|| (errno != 0 && resv1 == 0) || (endptr == pos1)) {
			debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
			goto err;
		}
		bss_info[id].wfa_vendor_extension |= (resv1 & 0x01) << 6;
		pos2++;
		pos1 = pos2;

		/*resv2*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "resv2 not found\n");
			goto err;
		}
		*pos2 = '\0';

		errno = 0;
		resv2 = strtol(pos1, &endptr, 10);
		if ((errno == ERANGE && (resv2 == LONG_MAX || resv2 == LONG_MIN))
			|| (errno != 0 && resv2 == 0) || (endptr == pos1)) {
			debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
			goto err;
		}
		bss_info[id].wfa_vendor_extension |= (resv2 & 0x01) << 5;
		pos2++;
		pos1 = pos2;

		/*MAP R1 Cert end here*/
		if (*pos1 == '\0')
			continue;

		/*MAP R2 Cert*/
		pos2 = strstr(pos1, "0xB5");
		if (pos2) {
			debug(DEBUG_TRACE, "[%d] check TS!\n", __LINE__);
			if (sscanf(pos1, "0xB5 0x%04x 0x%04x 0x%02x 0xB6 0x%04x 0x01 0x%02x %[^ ] 0x%04x",
				&dummy_len, &pvid, &pcp, &dummy_len1, &dummy_len2, dummy_ssid, &vid) != 7) {
				debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
				goto err;
			}
#ifdef MAP_R2
			ctx->map_policy.setting.primary_vid = pvid;
			ctx->map_policy.setting.dft.PCP = pcp;
#endif
			bss_info[id].pvid = pvid;
			bss_info[id].pcp = pcp;
			bss_info[id].vid = vid;
			/* TS end here */
			pos2 = strstr(pos1, "mld_groupID");
			if (!pos2)
				continue;
		}

		/*MLO Group index parsing*/
		pos2 = strstr(pos1, "mld_groupID");
		if (pos2) {
			debug(DEBUG_TRACE, "[%d] check mld_groupID!\n", __LINE__);
			pos1 = pos2;
			pos2 = strchr(pos1, ' ');
			if (pos2 == NULL) {
				debug(DEBUG_ERROR, "[%d] no mld group id specified!\n", __LINE__);
				goto err;
			}
			*pos2 = '\0';
			pos2++;
			pos1 = pos2;

			pos2 = strchr(pos1, ' ');
			if (pos2 == NULL) {
				debug(DEBUG_ERROR, "[%d] no mld group id specified!\n", __LINE__);
				goto err;
			}
			*pos2 = '\0';

			int_grp_id = strtol(pos1, NULL, 10);
			if (int_grp_id != 0) {
				if ((int_grp_id < 0) || (int_grp_id > 64)) {
					debug(DEBUG_ERROR, "[%d]invalid mld group id %d!\n", __LINE__, (int)int_grp_id);
					goto err;
				}

				bss_info[id].mlo_grp_id = (unsigned char)int_grp_id;
				debug(DEBUG_ERROR, "[%d]int mld group id %d!\n", __LINE__, (int)int_grp_id);
			} else {
				c_grp_id = *pos1;

				switch (c_grp_id) {
				case 'A':
					bss_info[id].mlo_grp_id = 1;
				break;
				case 'B':
					bss_info[id].mlo_grp_id = 2;
				break;
				case 'C':
					bss_info[id].mlo_grp_id = 3;
				break;
				case 'D':
					bss_info[id].mlo_grp_id = 4;
				break;
				default:
				break;
				}
				debug(DEBUG_ERROR, "[%d]c_grp_id %c!\n", __LINE__, c_grp_id);
			}

			pos2++;
			pos1 = pos2;

			/* R6 end here */
			if (*pos1 == '\0')
				continue;
		}
	}

	*config_bss_num = num;
	debug(DEBUG_OFF, "config_bss_num=%d\n", *config_bss_num);

	if (fclose(f) < 0) {
		debug(DEBUG_ERROR, "[%d]fclose fail!\n", __LINE__);
		return -1;
	}

	for (id = 0; id < num; id++) {
		debug(DEBUG_OFF, "set bss index=%d, mac="MACSTR","
				" opclass=%s, ssid=%s, ssid_len %d, authmode=%04x, encrytype=%04x, key=%s, "
				"bh_bss=%s, fh_bss=%s pvid %d, pcp %d, vlan %d hidden_ssid=%d mlo_grp_id=%d\n",
				(int)index, PRINT_MAC(bss_info[id].mac), bss_info[id].oper_class,
				bss_info[id].ssid, bss_info[id].ssid_len,  (int)authmode, (int)encrytype,
				bss_info[id].key,
				bss_info[id].wfa_vendor_extension & BIT_BH_BSS ? "1" : "0",
				bss_info[id].wfa_vendor_extension & BIT_FH_BSS ? "1" : "0",
				bss_info[id].pvid, bss_info[id].pcp, bss_info[id].vid,
				bss_info[id].hidden_ssid, bss_info[id].mlo_grp_id);

		if ((bss_info[id].wfa_vendor_extension & BIT_FH_BSS) &&
		    (bss_info[id].hidden_ssid == 0))
			fh_bss_unhidden |= bss_info[id].band_support;
	}

	if (!(fh_bss_unhidden & BAND_2G_CAP))
		debug(DEBUG_OFF, "2G bss is hidden or empty! wps may fail!\n");

	if (!(fh_bss_unhidden & BAND_5GL_CAP))
		debug(DEBUG_ERROR, "5GL bss is hidden or empty! wps may fail!\n");

	if (!(fh_bss_unhidden & BAND_5GH_CAP))
		debug(DEBUG_ERROR, "5GH bss is hidden or empty! wps may fail!\n");

	if (!(fh_bss_unhidden & BAND_6G_CAP))
		debug(DEBUG_ERROR, "6G bss is hidden or empty! wps may fail!\n");
#ifdef MAP_R2
	delete_exist_traffic_policy(ctx, &ctx->map_policy.tpolicy);
	update_traffic_separation_policy(ctx, bss_info, *config_bss_num);
#endif
	return 0;
err:
	if (fclose(f) < 0)
		debug(DEBUG_ERROR, "[%d]fclose fail!\n", __LINE__);
	return -1;
}

#ifdef MAP_R6
void _1905_read_bsta_wsc_reconfig(struct p1905_managerd_ctx *ctx)
{
	char *pos = NULL, *pos1 = NULL, *pos2 = NULL;
	unsigned int mac_int[6] = {0}, line = 0;
	char buf[512] = {0}, config_str[512] = {0};
	unsigned char max_bsta_num = 8, num = 0;
	unsigned int i = 0, j = 0;
	char backslash = 0x5C, space = 0x20, SUB = 0x1A;
	struct wps_cred_reconf_info wsc_info = {0};
	unsigned char al_mac[ETH_ALEN] = {0};
	FILE *f = NULL;
	long auth_mode = 0;
	long encr_type = 0;
	long index = 0;
	char *endptr = NULL;

	os_memset(&ctx->cred_reconfig, 0, sizeof(struct bsta_wps_cred_reconf));

	f = fopen(MAP_BSTA_WSC_RECONFIG_FILE, "r");
	if (f == NULL) {
		debug(DEBUG_ERROR, "no (%s), ignore\n", MAP_BSTA_WSC_RECONFIG_FILE);
		return;
	}

	while (get_line(buf, sizeof(buf) - 1, f, &line, &pos)) {
		num++;
		if (num > max_bsta_num) {
			debug(DEBUG_ERROR, "too much bsta mlo setting\n");
			break;
		}
		memset(config_str, 0, sizeof(config_str));

		j = 0;
		for (i = 0; i < strlen(pos); i++) {
			if (pos[i] == backslash) {
				if (pos[i + 1] == space) {
					config_str[j] = SUB;
					i++;
					j++;
					continue;
				} else if (pos[i + 1] == backslash) {
					config_str[j] = backslash;
					i++;
					j++;
					continue;
				}
			}
			config_str[j] = pos[i];
			j++;
		}

		/*insert ' ' before '\0'*/
		config_str[j++] = ' ';
		config_str[j++] = '\0';
		debugbyte(DEBUG_ERROR, "line(%d)=%s\n", line, config_str);

		pos1 = config_str;
		/*index*/
		pos2 = strchr(pos1, ',');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "index not found\n");
			goto err;
		}
		*pos2 = '\0';

		errno = 0;
		index = strtol(pos1, &endptr, 10);
		if ((errno == ERANGE && (index == LONG_MAX || index == LONG_MIN))
			|| (errno != 0 && index == 0) || (endptr == pos1)) {
			debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
			goto err;
		}

		pos2++;
		pos1 = pos2;
		debug(DEBUG_ERROR, "index %d\n", (int)index);

		/*al mac*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "mac not found\n");
			goto err;
		}
		*pos2 = '\0';
		if (sscanf(pos1, "%02x:%02x:%02x:%02x:%02x:%02x", mac_int,
			(mac_int + 1), (mac_int + 2), (mac_int + 3),
			(mac_int + 4), (mac_int + 5)) != 6) {
			debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
			goto err;
		}
		for (i = 0; i < 6; i++)
			al_mac[i] = (unsigned char)mac_int[i];
		pos2++;
		pos1 = pos2;
		debug(DEBUG_ERROR, "almac "MACSTR"\n", MAC2STR(al_mac));

		/*ssid*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "ssid not found\n");
			goto err;
		}
		*pos2 = '\0';
		if (sscanf(pos1, "%32s", wsc_info.ssid) != 1) {
			debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
			goto err;
		}
		wsc_info.ssid_len = os_strlen((char *)wsc_info.ssid);
		if (wsc_info.ssid_len > (sizeof(wsc_info.ssid) - 1))
			wsc_info.ssid_len = sizeof(wsc_info.ssid) - 1;
		/*replace SUB to space for passphase*/
		for (i = 0; i < 32; i++) {
			if (wsc_info.ssid[i] == SUB)
				wsc_info.ssid[i] = space;
		}
		debug(DEBUG_ERROR, "ssid %s\n", wsc_info.ssid);
		pos2++;
		pos1 = pos2;

		/*authmode*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "authmode not found\n");
			goto err;
		}
		*pos2 = '\0';

		errno = 0;
		auth_mode = strtol(pos1, &endptr, 16);
		if ((errno == ERANGE && (auth_mode == LONG_MAX || auth_mode == LONG_MIN))
			|| (errno != 0 && auth_mode == 0) || (endptr == pos1)) {
			debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
			goto err;
		}
		debug(DEBUG_ERROR, "auth mode %04x\n", (int)auth_mode);
		wsc_info.auth_mode = (unsigned short)auth_mode;
		pos2++;
		pos1 = pos2;

		/*encrytype*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "encrytype not found\n");
			goto err;
		}
		*pos2 = '\0';

		errno = 0;
		encr_type = strtol(pos1, &endptr, 16);
		if ((errno == ERANGE && (encr_type == LONG_MAX || encr_type == LONG_MIN))
			|| (errno != 0 && encr_type == 0) || (endptr == pos1)) {
			debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
			goto err;
		}
		debug(DEBUG_ERROR, "encryptype %04x\n", (int)encr_type);
		wsc_info.encr_type = (unsigned short)encr_type;
		pos2++;
		pos1 = pos2;

		/*key*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "key not found\n");
			goto err;
		}
		*pos2 = '\0';
		if (sscanf(pos1, "%64s", wsc_info.key) != 1) {
			debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
			goto err;
		}
		wsc_info.key_len = os_strlen((char *)wsc_info.key);
		if (wsc_info.key_len > (sizeof(wsc_info.key) - 1))
			wsc_info.key_len = sizeof(wsc_info.key) - 1;
		/*replace SUB to space for passphase*/
		for (i = 0; i < 64; i++) {
			if (wsc_info.key[i] == SUB)
				wsc_info.key[i] = space;
		}
		debug(DEBUG_ERROR, "key %s\n", wsc_info.key);

		ctx->cred_reconfig.wps_cred_reconfig_num += 1;

		os_memcpy(ctx->cred_reconfig.data[num - 1].al_mac, al_mac, ETH_ALEN);
		os_memcpy(&ctx->cred_reconfig.data[num - 1].info, &wsc_info, sizeof(wsc_info));
	}


	if (fclose(f) < 0)
		debug(DEBUG_ERROR, "[%d]fclose fail, errno %d!\n", __LINE__, errno);

	return;
err:
	if (fclose(f) < 0)
		debug(DEBUG_ERROR, "[%d]fclose fail, errno %d!\n", __LINE__, errno);
}


void _1905_read_bsta_config(struct p1905_managerd_ctx *ctx)
{
	char *pos = NULL, *pos1 = NULL, *pos2 = NULL;
	unsigned int mac_int[6] = {0}, line = 0;
	char buf[512] = {0}, config_str[512] = {0};
	unsigned char max_bsta_num = 9, num = 0;
	unsigned int i = 0, j = 0;
	char backslash = 0x5C, space = 0x20, SUB = 0x1A;
	struct mld_bsta_config_db *sta_db = NULL;
	struct affiliated_sta_db *aff_sta = NULL;
	unsigned char aff_ap_idx = 0;
	unsigned int num_ruid = 0;
	FILE *f = NULL;
	long index = 0, value = 0;
	char *endptr = NULL;

	f = fopen(MAP_WTS_BSTA_CFG_FILE, "r");
	if (f == NULL) {
		debug(DEBUG_ERROR, "no (%s), ignore\n", MAP_WTS_BSTA_CFG_FILE);
		return;
	}

	delete_agent_bsta_cfg(&ctx->agent_bsta_list);
	dl_list_init(&ctx->agent_bsta_list);

	while (get_line(buf, sizeof(buf) - 1, f, &line, &pos)) {
		num++;
		if (num > max_bsta_num) {
			debug(DEBUG_ERROR, "too much bsta mlo setting\n");
			break;
		}
		memset(config_str, 0, sizeof(config_str));

		j = 0;
		for (i = 0; i < strlen(pos); i++) {
			if (pos[i] == backslash) {
				if (pos[i + 1] == space) {
					config_str[j] = SUB;
					i++;
					j++;
					continue;
				} else if (pos[i + 1] == backslash) {
					config_str[j] = backslash;
					i++;
					j++;
					continue;
				}
			}
			config_str[j] = pos[i];
			j++;
		}

		sta_db = os_zalloc(sizeof(struct mld_bsta_config_db));
		if (!sta_db) {
			debug(DEBUG_ERROR, "fail to malloc agent_mld_bsta_db\n");
			break;
		}
		dl_list_init(&sta_db->affiliated_sta_list);
		dl_list_add_tail(&ctx->agent_bsta_list, &sta_db->list);

		/*insert ' ' before '\0'*/
		config_str[j++] = ' ';
		config_str[j++] = '\0';
		debugbyte(DEBUG_ERROR, "line(%d)=%s\n", line, config_str);

		pos1 = config_str;
		/*index*/
		pos2 = strchr(pos1, ',');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "index not found\n");
			goto err;
		}
		*pos2 = '\0';
		errno = 0;

		errno = 0;
		index = strtol(pos1, &endptr, 10);
		if ((errno == ERANGE && (index == LONG_MAX || index == LONG_MIN))
			|| (errno != 0 && index == 0) || (endptr == pos1)) {
			debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
			goto err;
		}
		pos2++;
		pos1 = pos2;
		debug(DEBUG_ERROR, "index %d\n", (int)index);

		/*al mac*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "mac not found\n");
			goto err;
		}
		*pos2 = '\0';
		if (sscanf(pos1, "%02x:%02x:%02x:%02x:%02x:%02x", mac_int,
			(mac_int + 1), (mac_int + 2), (mac_int + 3),
			(mac_int + 4), (mac_int + 5)) != 6) {
			debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
			goto err;
		}
		for (i = 0; i < 6; i++)
			sta_db->al_mac[i] = (unsigned char)mac_int[i];
		pos2++;
		pos1 = pos2;
		debug(DEBUG_ERROR, "almac "MACSTR"\n", MAC2STR(sta_db->al_mac));

		/*num of affiliated ap*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "num of affiliated ap not found\n");
			goto err;
		}
		*pos2 = '\0';

		errno = 0;
		value = strtol(pos1, &endptr, 10);
		if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
			|| (errno != 0 && value == 0) || (endptr == pos1)) {
			debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
			goto err;
		}
		if (value < 0)
			value = 0;
		num_ruid = value;
		pos2++;
		pos1 = pos2;
		sta_db->num_affiliated_sta = (unsigned char)num_ruid;
		if (sta_db->num_affiliated_sta > MAX_RADIO_NUM)
			sta_db->num_affiliated_sta = MAX_RADIO_NUM;
		debug(DEBUG_ERROR, "num of affiliated sta %d\n", sta_db->num_affiliated_sta);

		/*ruid*/
		for (aff_ap_idx = 0; aff_ap_idx < sta_db->num_affiliated_sta; aff_ap_idx++) {
			aff_sta = os_zalloc(sizeof(struct affiliated_sta_db));
			if (!aff_sta) {
				debug(DEBUG_ERROR, "fail to malloc affiliated sta\n");
				goto err;
			}
			dl_list_add_tail(&sta_db->affiliated_sta_list, &aff_sta->list);

			pos2 = strchr(pos1, ' ');
			if (pos2 == NULL) {
				debug(DEBUG_ERROR, "ruid not found\n");
				goto err;
			}
			*pos2 = '\0';
			if (sscanf(pos1, "0x%02x%02x%02x%02x%02x%02x", mac_int,
				(mac_int + 1), (mac_int + 2), (mac_int + 3),
				(mac_int + 4), (mac_int + 5)) != ETH_ALEN) {
				debug(DEBUG_ERROR, "fail to sscanf ruid, continue to check opclass!\n");
				aff_sta->band = find_band_by_opclass(pos1);
				if (aff_sta->band == BAND_INVALID_CAP) {
					debug(DEBUG_ERROR, "fail to get opclass, quit!\n");
					goto err;
				}
				debug(DEBUG_ERROR, "affiliated band %s\n", band_2_string(aff_sta->band));
			} else {
				for (i = 0; i < ETH_ALEN; i++)
					aff_sta->ruid[i] = (unsigned char)mac_int[i];
				debug(DEBUG_ERROR, "affiliated ruid "MACSTR"\n", MAC2STR(aff_sta->ruid));
			}

			pos2++;
			pos1 = pos2;
		}
	}

	if (fclose(f) < 0)
		debug(DEBUG_ERROR, "[%d]fclose fail, errno %d!\n", __LINE__, errno);

	return;
err:
	if (fclose(f) < 0)
		debug(DEBUG_ERROR, "[%d]fclose fail, errno %d!\n", __LINE__, errno);
	delete_agent_bsta_cfg(&ctx->agent_bsta_list);
}

void _1905_read_mlo_max_links(struct p1905_managerd_ctx *ctx)
{
	FILE *f = NULL;
	unsigned int line = 0;
	char *pos = NULL;
	char buf[ETH_ALEN] = {0};
	int value = 0;
	char *endptr = NULL;

	f = fopen(MAP_MLO_MAX_LINKS, "r");
	if (f == NULL) {
		debug(DEBUG_ERROR, "erro read (%s), ignore\n", MAP_MLO_MAX_LINKS);
		return;
	}
	debug(DEBUG_ERROR, "read (%s)\n", MAP_MLO_MAX_LINKS);

	get_line(buf, sizeof(buf) - 1, f, &line, &pos);
	debug(DEBUG_ERROR, "pos %s\n", pos);

	errno = 0;
	value = strtol(pos, &endptr, 10);
	if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
		|| (errno != 0 && value == 0) || (endptr == pos)) {
		debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
		return;
	}
	if (value < 0)
		value = 0;
	ctx->mlo_max_links = (unsigned char)value;
	debug(DEBUG_ERROR, "mlo_max_links %d\n", ctx->mlo_max_links);
	if (fclose(f) < 0)
		debug(DEBUG_ERROR, "[%d]fclose fail, errno %d!\n", __LINE__, errno);
}



void _1905_read_mld_link_config(struct p1905_managerd_ctx *ctx)
{
	char *pos = NULL, *pos1 = NULL, *pos2 = NULL;
	unsigned int mac_int[6] = {0}, line = 0;
	char buf[512] = {0};
	unsigned int i = 0;
	FILE *f = NULL;
	char *action_str = NULL;
	unsigned char almac[ETH_ALEN] = {0};
	unsigned char mldmac[ETH_ALEN] = {0};
	unsigned char ruid[ETH_ALEN] = {0};
	unsigned char bssid[ETH_ALEN] = {0};
	char ssid[MAX_SSID_LEN] = {0};
	long link_id = 0;
	int ret = 0;
	char *endptr = NULL;

	f = fopen(MAP_MLO_LINK_CFG_FILE, "r");
	if (f == NULL) {
		debug(DEBUG_ERROR, "erro read (%s), ignore\n", MAP_MLO_LINK_CFG_FILE);
		return;
	}
	debug(DEBUG_ERROR, "read (%s)\n", MAP_MLO_LINK_CFG_FILE);

	os_memset(&ctx->mld_chg, 0, sizeof(struct mld_link_chage));

	get_line(buf, sizeof(buf) - 1, f, &line, &pos);


	debugbyte(DEBUG_ERROR, "line(%d)=%s\n", line, pos);

	pos1 = pos;
	/* DestALid */
	pos2 = strchr(pos1, ' ');
	if (pos2 == NULL) {
		debug(DEBUG_ERROR, "almac not found\n");
		goto err;
	}
	*pos2 = '\0';
	pos2++;
	pos1 = pos2;

	/* DestALid value */
	pos2 = strchr(pos1, ' ');
	if (pos2 == NULL) {
		debug(DEBUG_ERROR, "almac not found\n");
		goto err;
	}
	*pos2 = '\0';
	ret = sscanf(pos1, "%02x:%02x:%02x:%02x:%02x:%02x", mac_int,
		(mac_int + 1), (mac_int + 2), (mac_int + 3),
		(mac_int + 4), (mac_int + 5));
	if (ret != ETH_ALEN) {
		debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
		goto err;
	}
	for (i = 0; i < ETH_ALEN; i++)
		almac[i] = (unsigned char)mac_int[i];
	pos2++;
	pos1 = pos2;
	debug(DEBUG_ERROR, "almac "MACSTR"\n", MAC2STR(almac));

	/* TargetMLD */
	pos2 = strchr(pos1, ' ');
	if (pos2 == NULL) {
		debug(DEBUG_ERROR, "mld not found\n");
		goto err;
	}
	*pos2 = '\0';
	pos2++;
	pos1 = pos2;

	/* TargetMLD value */
	pos2 = strchr(pos1, ' ');
	if (pos2 == NULL) {
		debug(DEBUG_ERROR, "mld not found\n");
		goto err;
	}
	*pos2 = '\0';
	ret = sscanf(pos1, "%02x:%02x:%02x:%02x:%02x:%02x", mac_int,
		(mac_int + 1), (mac_int + 2), (mac_int + 3),
		(mac_int + 4), (mac_int + 5));
	if (ret != ETH_ALEN) {
		debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
		goto err;
	}
	for (i = 0; i < ETH_ALEN; i++)
		mldmac[i] = (unsigned char)mac_int[i];
	pos2++;
	pos1 = pos2;
	debug(DEBUG_ERROR, "mld mac "MACSTR"\n", MAC2STR(mldmac));

	/* TargetRUID */
	pos2 = strchr(pos1, ' ');
	if (pos2 == NULL) {
		debug(DEBUG_ERROR, "ruid not found\n");
		goto err;
	}
	*pos2 = '\0';
	pos2++;
	pos1 = pos2;

	/* TargetRUID value */
	pos2 = strchr(pos1, ' ');
	if (pos2 == NULL) {
		debug(DEBUG_ERROR, "ruid not found\n");
		goto err;
	}
	*pos2 = '\0';
	ret = sscanf(pos1, "0x%02x%02x%02x%02x%02x%02x", mac_int,
		(mac_int + 1), (mac_int + 2), (mac_int + 3),
		(mac_int + 4), (mac_int + 5));
	if (ret != ETH_ALEN) {
		debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
		goto err;
	}
	for (i = 0; i < ETH_ALEN; i++)
		ruid[i] = (unsigned char)mac_int[i];
	pos2++;
	pos1 = pos2;
	debug(DEBUG_ERROR, "ruid "MACSTR"\n", MAC2STR(ruid));

	/* TargetLink */
	pos2 = strchr(pos1, ' ');
	if (pos2 == NULL) {
		debug(DEBUG_ERROR, "link not found\n");
		goto err;
	}
	*pos2 = '\0';
	pos2++;
	pos1 = pos2;

	/* TargetLink: value */
	pos2 = strchr(pos1, ' ');
	if (pos2 == NULL) {
		debug(DEBUG_ERROR, "link not found\n");
		goto err;
	}
	*pos2 = '\0';
	ret = sscanf(pos1, "%02x:%02x:%02x:%02x:%02x:%02x", mac_int,
		(mac_int + 1), (mac_int + 2), (mac_int + 3),
		(mac_int + 4), (mac_int + 5));
	if (ret != ETH_ALEN) {
		errno = 0;
		link_id = strtol(pos1, &endptr, 0);
		if ((errno == ERANGE && (link_id == LONG_MAX || link_id == LONG_MIN))
			|| (errno != 0 && link_id == 0) || (endptr == pos1)) {
			debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
			goto err;
		}
		if (link_id <= 0)
			goto err;
	}
	for (i = 0; i < ETH_ALEN; i++)
		bssid[i] = (unsigned char)mac_int[i];
	pos2++;
	pos1 = pos2;
	debug(DEBUG_ERROR, "bssid "MACSTR"\n", MAC2STR(bssid));

	/* ssid, optional */
	pos2 = strstr(pos1, "SSID");
	if (pos2) {
		/* "SSID" string */
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "%d SSID not found\n", __LINE__);
			goto err;
		}
		*pos2 = '\0';
		pos2++;
		pos1 = pos2;

		/* "SSID" value */
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "%d SSID value not found\n", __LINE__);
			goto err;
		}
		os_strncpy(ssid, pos1, pos2-pos1);
		ssid[MAX_SSID_LEN-1] = '\0';
		pos2++;
		pos1 = pos2;
		debug(DEBUG_ERROR, "ssid %s\n", ssid);
	}

	/* AgentAction */
	pos2 = strstr(pos1, "AgentAction");
	if (pos2 == NULL) {
		debug(DEBUG_ERROR, "%d AgentAction not found\n", __LINE__);
		goto err;
	} else {
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "%d AgentAction not found\n", __LINE__);
			goto err;
		}
		*pos2 = '\0';
		pos2++;
		pos1 = pos2;

		/* AgentAction: value */
		action_str = strstr(pos1, "APAddition");
		if (action_str) {
			ctx->mld_chg.type = MLD_AP_LINK_CHANGE;
			ctx->mld_chg.action = MLD_LINK_ADD;
			debug(DEBUG_ERROR, "AP MLD LINK ADDITION\n");
		}
		action_str = strstr(pos1, "APRemoval");
		if (action_str) {
			ctx->mld_chg.type = MLD_AP_LINK_CHANGE;
			ctx->mld_chg.action = MLD_LINK_RM;
			debug(DEBUG_ERROR, "AP MLD LINK REMOVAL\n");
		}
		action_str = strstr(pos1, "bSTALinkAddition");
		if (action_str) {
			ctx->mld_chg.type = MLD_BSTA_LINK_CHANGE;
			ctx->mld_chg.action = MLD_LINK_ADD;
			debug(DEBUG_ERROR, "BSTA MLD LINK ADDITION\n");
		}
		action_str = strstr(pos1, "bSTALinkRemoval");
		if (action_str) {
			ctx->mld_chg.type = MLD_BSTA_LINK_CHANGE;
			ctx->mld_chg.action = MLD_LINK_RM;
			debug(DEBUG_ERROR, "BSTA MLD LINK REMOVAL\n");
		}
	}

	os_memcpy(ctx->mld_chg.almac, almac, ETH_ALEN);
	os_memcpy(ctx->mld_chg.mld_mac, mldmac, ETH_ALEN);
	os_memcpy(ctx->mld_chg.ruid, ruid, ETH_ALEN);
	if (ctx->mld_chg.type == MLD_AP_LINK_CHANGE) {
		os_strncpy(ctx->mld_chg.ssid, ssid, strlen(ssid));
		ctx->mld_chg.ssid[MAX_SSID_LEN-1] = '\0';
		ctx->mld_chg.link_id = link_id;
	} else if (ctx->mld_chg.type == MLD_BSTA_LINK_CHANGE)
		os_memcpy(ctx->mld_chg.bssid, bssid, ETH_ALEN);

	if (fclose(f) < 0)
		debug(DEBUG_ERROR, "[%d]fclose fail, errno %d!\n", __LINE__, errno);

	return;
err:
	os_memset(&ctx->mld_chg, 0, sizeof(struct mld_link_chage));
	if (fclose(f) < 0)
		debug(DEBUG_ERROR, "[%d]fclose fail, errno %d!\n", __LINE__, errno);
}

#endif

int _1905_read_set_config(struct p1905_managerd_ctx *ctx, char *name,
	struct set_config_bss_info bss_info[], unsigned char max_bss_num,
	unsigned char *config_bss_num)
{
	FILE *f = NULL;
	unsigned int i = 0, j = 0;
	char c_grp_id = 0;
	int int_grp_id = 0;
	unsigned int mac_int[6] = {0}, line = 0;
	long authmode = 0, encrytype = 0, index = 0, resv1 = 0, resv2 = 0;
	char *pos = NULL, *pos1 = NULL, *pos2 = NULL;
	char buf[512] = {0}, config_str[512] = {0};
	unsigned char fh_bss_unhidden = 0, num = 0, id = 0;
	char backslash = 0x5C, space = 0x20, SUB = 0x1A;
	char hidden_ssid = 'N';
	long pvid = 0, vid = 0, pcp = 0;
	char *endptr = NULL;
#ifdef MAP_R2
	struct traffics_policy updated_tpolicy = {0};
	unsigned char updated = 0;
#endif

	if (!max_bss_num) {
		debug(DEBUG_ERROR, "input max_bss_num is 0, invaild");
		return -1;
	}

	f = fopen(name, "r");
	if (f == NULL) {
		debug(DEBUG_ERROR, "open file %s fail\n", name);
		return -1;
	}

	for (i = 0; i < max_bss_num; i++)
		memset(&bss_info[i], 0, sizeof(struct set_config_bss_info));

#ifdef MAP_R6
	_1905_read_bsta_wsc_reconfig(ctx);
	_1905_read_bsta_config(ctx);
#endif

	if (ctx->MAP_Cer) {
		if (fclose(f) < 0)
			debug(DEBUG_ERROR, "[%d]fclose fail!\n", __LINE__);
		return _1905_read_set_config_cert(ctx, name, bss_info, max_bss_num, config_bss_num);
	}

	while (get_line(buf, sizeof(buf) - 1, f, &line, &pos)) {
		num++;
		id = num - 1;
		if (num > max_bss_num) {
			debug(DEBUG_ERROR, "too much bss wireless setting info\n");
			break;
		}
		memset(config_str, 0, sizeof(config_str));
		/*rebuild the line due to ssid contains space*/
		/* If ssid is a space, need add \ as ESC infront of it in wts file. As space is regard as
		* a separator. If ssid is a \, need add \ as ESC in front of it. when parsing wts file,
		* "\space"need remove \ and replace space to SUB. "\\"need remove \
		*/
		j = 0;
		for (i = 0; i < strlen(pos); i++) {
			if (pos[i] == backslash) {
				if (pos[i + 1] == space) {
					config_str[j] = SUB;
					i++;
					j++;
					continue;
				} else if (pos[i + 1] == backslash) {
					config_str[j] = backslash;
					i++;
					j++;
					continue;
				}
			}
			config_str[j] = pos[i];
			j++;
		}
		/*insert ' ' before '\0'*/
		config_str[j++] = ' ';
		config_str[j++] = '\0';
		debugbyte(DEBUG_TRACE, "line(%d)=%s\n", line, config_str);
		/*initialization*/
		bss_info[id].vid = INVALID_VLAN_ID;
		pos1 = config_str;
		/*index*/
		pos2 = strchr(pos1, ',');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "index not found\n");
			goto err;
		}
		*pos2 = '\0';
		errno = 0;
		index = strtol(pos1, &endptr, 10);
		if ((errno == ERANGE && (index == LONG_MAX || index == LONG_MIN))
			|| (errno != 0 && index == 0) || (endptr == pos1)) {
			debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
			goto err;
		}
		pos2++;
		pos1 = pos2;

		/*mac*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "mac not found\n");
			goto err;
		}
		*pos2 = '\0';
		if (sscanf(pos1, "%02x:%02x:%02x:%02x:%02x:%02x", mac_int,
			(mac_int + 1), (mac_int + 2), (mac_int + 3),
			(mac_int + 4), (mac_int + 5)) != 6) {
			debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
			goto err;
		}
		for (i = 0; i < 6; i++)
			bss_info[id].mac[i] = (unsigned char)mac_int[i];
		pos2++;
		pos1 = pos2;

		/*opclass*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "opclass not found\n");
			goto err;
		}
		*pos2 = '\0';
		if (sscanf(pos1, "%03s", bss_info[id].oper_class) != 1) {
			debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
			goto err;
		}
		bss_info[id].band_support = find_band_by_opclass(bss_info[id].oper_class);
		pos2++;
		pos1 = pos2;

		/*ssid*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "ssid not found\n");
			goto err;
		}
		*pos2 = '\0';
		if (sscanf(pos1, "%32s", bss_info[id].ssid) != 1) {
			debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
			goto err;
		}
		/*replace SUB to space for ssid*/
		bss_info[id].ssid_len = os_strlen(bss_info[id].ssid);
		for (i = 0; i < bss_info[id].ssid_len; i++) {
			if (bss_info[id].ssid[i] == SUB)
				bss_info[id].ssid[i] = space;
		}
		pos2++;
		pos1 = pos2;

		/*authmode*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "authmode not found\n");
			goto err;
		}
		*pos2 = '\0';
		errno = 0;
		authmode = strtol(pos1, &endptr, 16);
		if ((errno == ERANGE && (authmode == LONG_MAX || authmode == LONG_MIN))
			|| (errno != 0 && authmode == 0) || (endptr == pos1)) {
			debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
			goto err;
		}
		bss_info[id].authmode = authmode;
		pos2++;
		pos1 = pos2;

		/*encrytype*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "encrytype not found\n");
			goto err;
		}
		*pos2 = '\0';
		errno = 0;
		encrytype = strtol(pos1, &endptr, 16);
		if ((errno == ERANGE && (encrytype == LONG_MAX || encrytype == LONG_MIN))
			|| (errno != 0 && encrytype == 0) || (endptr == pos1)) {
			debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
			goto err;
		}
		bss_info[id].encryptype = encrytype;
		pos2++;
		pos1 = pos2;

		/*key*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "key not found\n");
			goto err;
		}
		*pos2 = '\0';
		if (sscanf(pos1, "%64s", bss_info[id].key) != 1
			&& authmode != CONFIG_AUTH_OPEN && authmode != CONFIG_AUTH_OWE) {
			debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
			goto err;
		}
		/*replace SUB to space for passphase*/
		for (i = 0; i < 64; i++) {
			if (bss_info[id].key[i] == SUB)
				bss_info[id].key[i] = space;
		}
		pos2++;
		pos1 = pos2;

		/*resv1*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "resv1 not found\n");
			goto err;
		}
		*pos2 = '\0';
		errno = 0;
		resv1 = strtol(pos1, &endptr, 10);
		if ((errno == ERANGE && (resv1 == LONG_MAX || resv1 == LONG_MIN))
			|| (errno != 0 && resv1 == 0) || (endptr == pos1)) {
			debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
			goto err;
		}
		bss_info[id].wfa_vendor_extension |= (resv1 & 0x01) << 6;
		pos2++;
		pos1 = pos2;

		/*resv2*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "resv2 not found\n");
			goto err;
		}
		*pos2 = '\0';
		errno = 0;
		resv2 = strtol(pos1, &endptr, 10);
		debug(DEBUG_ERROR, "errno %d, resv2 %d, pos1 %p, endptr %p\n", errno, (int)resv2, pos1, endptr);
		if ((errno == ERANGE && (resv2 == LONG_MAX || resv2 == LONG_MIN))
			|| (errno != 0 && resv2 == 0) || (endptr == pos1)) {
			debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
			goto err;
		}
		bss_info[id].wfa_vendor_extension |= (resv2 & 0x01) << 5;
		pos2++;
		pos1 = pos2;

		/*MAP R1 Cert end here*/
		if (*pos1 == '\0')
			continue;

		/*hidden ssid*/
		pos2 = strstr(pos1, "hidden");
		if (pos2) {
			pos2 = strchr(pos1, ' ');
			if (pos2 == NULL) {
				debug(DEBUG_ERROR, "hidden ssid not found\n");
				goto err;
			}
			*pos2 = '\0';
			if (sscanf(pos1, "hidden-%c", &hidden_ssid) != 1) {
				debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
				goto err;
			}
			if (hidden_ssid == 'Y')
				bss_info[id].hidden_ssid = 1;
			else
				bss_info[id].hidden_ssid = 0;
			pos2++;
			pos1 = pos2;

			/*MAP R1 turkey end here*/
			if (*pos1 == '\0')
				continue;
		}

		/*MAP R2 TS parameter*/
		/*vid*/
		pos2 = strchr(pos1, ' ');
		if (pos2 == NULL) {
			debug(DEBUG_ERROR, "[%d]strchr fail!\n", __LINE__);
			goto err;
		}
		*pos2 = '\0';

		errno = 0;
		vid = strtol(pos1, &endptr, 10);
		if ((errno != ERANGE) && (endptr != pos1)) {
			pos2++;
			pos1 = pos2;

			/*pvid*/
			pos2 = strchr(pos1, ' ');
			if (pos2 == NULL) {
				debug(DEBUG_ERROR, "[%d]strchr fail!\n", __LINE__);
				goto err;
			}
			*pos2 = '\0';
			if (strstr(pos1, "pvid"))
				pvid = vid;
			else
				pvid = INVALID_VLAN_ID;
			pos2++;
			pos1 = pos2;

			/*pcp*/
			pos2 = strchr(pos1, ' ');
			if (pos2 == NULL) {
				debug(DEBUG_ERROR, "[%d]strchr fail!\n", __LINE__);
				goto err;
			}
			*pos2 = '\0';

			errno = 0;
			pcp = strtol(pos1, &endptr, 10);
			if ((pvid != INVALID_VLAN_ID) &&
				((errno == ERANGE) || (endptr == pos1) ||
				(pcp < 0) || (pcp > 7))) {
				debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
				goto err;
			}
			pos2++;
			pos1 = pos2;
#ifdef MAP_R2
			ctx->map_policy.setting.updated = 0;
			if (pvid != INVALID_VLAN_ID) {
				if ((ctx->map_policy.setting.primary_vid != pvid) ||
					(ctx->map_policy.setting.dft.PCP != pcp)) {
					ctx->map_policy.setting.updated = 1;
					debug(DEBUG_ERROR, "pvid pcp setting changed\n");
				}
				ctx->map_policy.setting.primary_vid = pvid;
				ctx->map_policy.setting.dft.PCP = pcp;
			}

			bss_info[id].pvid = pvid;
			bss_info[id].pcp = pcp;
			bss_info[id].vid = vid;
			ctx->map_policy.tpolicy.updated = 1;
#endif
		}
		/* not ts config, check other parameters */
		else
			*pos2 = ' ';

		if (*pos1 == '\0')
			continue;

		/*MLO Group index parsing*/
		pos2 = strstr(pos1, "mld_groupID");
		if (pos2) {
			pos2 = strchr(pos1, ' ');
			if (pos2 == NULL) {
				debug(DEBUG_ERROR, "[%d] no mld group id specified!\n", __LINE__);
				goto err;
			}
			*pos2 = '\0';
			pos2++;
			pos1 = pos2;

			pos2 = strchr(pos1, ' ');
			if (pos2 == NULL) {
				debug(DEBUG_ERROR, "[%d] no mld group id specified!\n", __LINE__);
				goto err;
			}
			*pos2 = '\0';

			errno = 0;
			int_grp_id = strtol(pos1, NULL, 10);
			if (int_grp_id != 0) {
				if ((int_grp_id < 0) || (int_grp_id > 64)) {
					debug(DEBUG_ERROR, "[%d]invalid mld group id %d!\n", __LINE__, int_grp_id);
					goto err;
				}

				bss_info[id].mlo_grp_id = (unsigned char)int_grp_id;
				debug(DEBUG_TRACE, "[%d]int mld group id %d!\n", __LINE__, int_grp_id);
			} else {
				c_grp_id = *pos1;

				switch (c_grp_id) {
				case 'A':
					bss_info[id].mlo_grp_id = 1;
				break;
				case 'B':
					bss_info[id].mlo_grp_id = 2;
				break;
				case 'C':
					bss_info[id].mlo_grp_id = 3;
				break;
				case 'D':
					bss_info[id].mlo_grp_id = 4;
				break;
				default:
				break;
				}
				debug(DEBUG_TRACE, "[%d]c_grp_id %c!\n", __LINE__, c_grp_id);
			}

			pos2++;
			pos1 = pos2;

			/* R6 end here */
			if (*pos1 == '\0')
				continue;
		}
	}

	*config_bss_num = num;
	debug(DEBUG_OFF, "config_bss_num=%d\n", *config_bss_num);

	if (fclose(f) < 0) {
		debug(DEBUG_ERROR, "[%d]fclose fail!\n", __LINE__);
		return -1;
	}

	for (id = 0; id < num; id++) {
		debug(DEBUG_OFF, "set bss index=%d, mac="MACSTR","
				" opclass=%s, ssid=%s, ssid_len %d, authmode=%04x, encrytype=%04x, key=%s, "
				"bh_bss=%s, fh_bss=%s pvid %d, pcp %d, vlan %d hidden_ssid=%d mlo_grp_id=%d\n",
				(int)index, PRINT_MAC(bss_info[id].mac), bss_info[id].oper_class,
				bss_info[id].ssid, bss_info[id].ssid_len,
				bss_info[id].authmode, bss_info[id].encryptype, bss_info[id].key,
				bss_info[id].wfa_vendor_extension & BIT_BH_BSS ? "1" : "0",
				bss_info[id].wfa_vendor_extension & BIT_FH_BSS ? "1" : "0",
				bss_info[id].pvid, bss_info[id].pcp, bss_info[id].vid,
				bss_info[id].hidden_ssid, bss_info[id].mlo_grp_id);

		if ((bss_info[id].wfa_vendor_extension & BIT_FH_BSS) &&
			(bss_info[id].hidden_ssid == 0))
				fh_bss_unhidden |= bss_info[id].band_support;
	}

	if (!(fh_bss_unhidden & BAND_2G_CAP)) {
		debug(DEBUG_OFF, "2G bss is hidden or empty! wps may fail!\n");
	}

	if (!(fh_bss_unhidden & BAND_5GL_CAP)) {
		debug(DEBUG_ERROR, "5GL bss is hidden or empty! wps may fail!\n");
	}

	if (!(fh_bss_unhidden & BAND_5GH_CAP)) {
		debug(DEBUG_ERROR, "5GH bss is hidden or empty! wps may fail!\n");
	}

	if (!(fh_bss_unhidden & BAND_6G_CAP)) {
		debug(DEBUG_ERROR, "6G bss is hidden or empty! wps may fail!\n");
	}
#ifdef MAP_R2
	update_traffic_separation_policy_ex(ctx, &updated_tpolicy, bss_info, *config_bss_num);
	updated = check_traffic_policy_config_updated(ctx, &ctx->map_policy.tpolicy, &updated_tpolicy);
	delete_exist_traffic_policy(ctx, &updated_tpolicy);
	delete_exist_traffic_policy(ctx, &ctx->map_policy.tpolicy);
	update_traffic_separation_policy(ctx, bss_info, *config_bss_num);
	ctx->map_policy.tpolicy.updated = updated;

#endif
	return 0;
err:
	if (fclose(f) < 0)
		debug(DEBUG_ERROR, "[%d]fclose fail!\n", __LINE__);
	return -1;
}

char* get_raw_data_end(char *content)
{
	char flag_ch[5] = {'_', 0x0a, 0x0d, '\0', ' '};
	int i = 0;
	char* temp = NULL;
	char* temp_min = NULL;

	for(i = 0; i < 5; i++)
	{
		temp = strchr(content, flag_ch[i]);
		if(temp == NULL)
		{
			continue;
		}
		if((temp_min != NULL && temp_min > temp) || temp_min == NULL)
		{
			temp_min = temp;
		}
	}
	return temp_min;

}
char* str_locate(char *org_string, char *t_string)
{
	int i = 0;
	int org_len = 0, t_len = 0;

	org_len = strlen(org_string);
	t_len = strlen(t_string);

	for(i = 0; i <= org_len - t_len; i++)
	{
		if(!strncmp(org_string + i, t_string, t_len))
		{
			return (char* )(org_string + i);
		}
	}
	return NULL;
}
int _1905_read_dev_send_1905(struct p1905_managerd_ctx* ctx,
	char* name, unsigned char *almac, unsigned short* _type, unsigned short *tlv_len, unsigned char *pay_load)
{
	FILE* f;
	int i;
	char *content = NULL;
	unsigned short pay_load_len = 0;
	long value = 0;
	char* pos1, *pos2;
	unsigned int mac_int[ETH_ALEN];
	unsigned char al_mac[ETH_ALEN];
	long msg_type = 0;
	signed char ch;
	unsigned char byte_value[3];
	unsigned char ts_tlv_flag =  0, ts_tlv_count = 0;
	unsigned char k = 0, num;
	unsigned char ssid[64] = {0};
	char *endptr = NULL;
#ifdef MAP_R3
	unsigned char sa_mac[ETH_ALEN] = {0}, da_mac[ETH_ALEN] = {0};
	unsigned int flag_mask = 0, add_rm_flag = 0;;
#endif
#ifdef MAP_R5
	unsigned char qostlv = 0;
	unsigned short offset = 0, qostlv_len = 0;
#endif

	f = fopen(name, "r");
	if (f == NULL)
	{
		debug(DEBUG_ERROR, "open file %s fail\n", name);
		return -1;
	}

	/*alloc more memory to support parse jumbo TLV from file.*/
	content = os_malloc(25*1024);
	if (!content) {
		debug(DEBUG_ERROR, "alloc memory for fail\n");
		goto error1;
	}

	os_memset(content, 0, 25*1024);

	i = 0;

	while ((ch = (signed char)fgetc(f)) != EOF)
		content[i++] = ch;
	debug(DEBUG_TRACE, "\n");

	hex_dump("raw content:", (unsigned char *)content, i);

	pos1 = content;
	/*al mac*/
	pos2 = strchr(pos1, ' ');
	if(pos2 == NULL)
	{
		debug(DEBUG_ERROR, "white space not found\n");
		goto error1;
	}
	*pos2 = '\0';
	if (sscanf(pos1, "%02x:%02x:%02x:%02x:%02x:%02x", mac_int, mac_int + 1,
			mac_int + 2, mac_int + 3, mac_int + 4, mac_int + 5) < 0) {
		debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
		goto error1;
	}
	for(i = 0; i < 6; i++)
	{
		al_mac[i] = (unsigned char)mac_int[i];
	}
	pos2++;
	pos1 = pos2;
	debug(DEBUG_TRACE, "almac:"MACSTR"\n", PRINT_MAC(al_mac));


	/*msg type*/
	pos2 = strchr(pos1, '\n');
	if(pos2 == NULL)
	{
		debug(DEBUG_ERROR, "\\n not  found\n");
		goto error1;
	}
	*pos2 = '\0';
	errno = 0;
	msg_type = strtol(pos1, &endptr, 16);
	if ((errno == ERANGE && (msg_type == LONG_MAX || msg_type == LONG_MIN))
		|| (errno != 0 && msg_type == 0) || (endptr == pos1)) {
		debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
		goto error1;
	}
	pos2++;
	pos1 = pos2;
	debug(DEBUG_TRACE, "msg_type=0x%04x\n", (int)msg_type);

	while(1)
	{
		pos1 = str_locate(pos1, "0x");
		/*end of data*/
		if(pos1 == NULL)
		{
			break;
		}
		/*skip '0x'*/
		pos1 += 2;

		pos2 = get_raw_data_end(pos1);

		if(pos2 == NULL)
		{
			debug(DEBUG_ERROR, "error find raw data end\n");
			goto error1;
		}
		if(pos2 < pos1)
		{
			debug(DEBUG_ERROR, "pos2 must larger than pos1\n");
			goto error1;
		}
		if(((int)(pos2 - pos1)) % 2 != 0)
		{
			pos1--;
			*pos1 = '0';
		}
		while(1)
		{
			memset(byte_value, 0, sizeof(byte_value));
			memcpy(byte_value, pos1, 2);
			errno = 0;
			value = strtol((char *)byte_value, &endptr, 16);
			if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
				|| (errno != 0 && value == 0) || (endptr == (char *)byte_value)) {
				debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
				goto error1;
			}
			pay_load[pay_load_len++] = (unsigned char)value;
			pos1 += 2;
			if(pos1 >= pos2)
			{
				break;
			}
		}

#ifdef MAP_R5
		/* QoS Management Descriptor TLV
		 * offset: will indicate the offset of length this TLV.
		 * 00:0c:43:4b:ae:5a 0x8023
		 * 0xDC 0x002A 0x0002 0x020c431aee39 0x04cf4b239c31 0xB9 0x1A 0x01 0x00 0xB80105 0x0E
		 * 0x13 0xFF 0x04 0x5F 0x04 0xC0A56464 0xC0A5648E 0x2774 0x13EC 0x00 0x11 0x00
		 */
		if (!qostlv && (value == QOS_MANAGEMENT_DESCRIPTOR_TLV_TYPE)) {
			offset = pay_load_len;
			qostlv = 1;
			continue;
		}
		if (qostlv) {
			if ((pay_load_len - offset) == 2) {
				qostlv_len = (unsigned short)((pay_load[offset] << 8) | pay_load[offset+1]);
				debug(DEBUG_OFF, "qostlv_len:%d\n", qostlv_len);
			} else if (qostlv_len && (pay_load_len - offset - 2) >= qostlv_len) {
				qostlv_len = 0;
				qostlv = 0;
			}
			continue;
		}
#endif

		/* TS TLV will appear as:
		 * 00:0c:43:48:98:FC 0x8003
		 * 0xB5 0x0003 0x000A 0x00 0xB6 0x0014 0x02 0x0E Multi-AP-5GL-1 0x000A 0x0E Multi-AP-5GL-2 0x0014
		 */

		if ((value == TRAFFIC_SEPARATION_POLICY_TYPE) && (msg_type == MAP_POLICY_CONFIG_REQUEST))
			ts_tlv_flag = 1;

		if (ts_tlv_flag == 1)
			ts_tlv_count++;

		if (ts_tlv_count == 3) {
			num = value;
			for (k = 0; k < num; k++) {
				pos1 = str_locate(pos1, "0x");
				if (!pos1)
					goto error1;
				/*skip '0x', parse ssid length*/
				pos1 += 2;

				memset(byte_value, 0, sizeof(byte_value));
				memcpy(byte_value, pos1, 2);
				errno = 0;
				value = strtol((char *)byte_value, &endptr, 16);
				if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
					|| (errno != 0 && value == 0) || (endptr == (char *)byte_value)) {
					debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
					goto error1;
				}
				pay_load[pay_load_len++] = (unsigned char)value;
				pos1 += 2;

				pos1 += 1; /*skip '_'*/
				memset(ssid, 0, 64);
				if (sscanf((char *)pos1, "%32s", ssid) < 0) {
					debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
					goto error1;
				}
				memcpy(&pay_load[pay_load_len], ssid, value);
				pay_load_len += value;

				debug(DEBUG_ERROR, "ssid len=%d, ssid:%s\n", (int)value, ssid);

				/*vlan id*/
				pos1 = str_locate(pos1, "0x");
				if (!pos1)
					goto error1;
				/*skip '0x'*/
				pos1 += 2;
				pos2 = get_raw_data_end(pos1);
				do {
					memset(byte_value, 0, sizeof(byte_value));
					memcpy(byte_value, pos1, 2);
					errno = 0;
					value = strtol((char *)byte_value, &endptr, 16);
					if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
						|| (errno != 0 && value == 0) || (endptr == (char *)byte_value)) {
						debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
						goto error1;
					}
					pay_load[pay_load_len++] = (unsigned char)value;
					pos1 += 2;
					if(pos1 >= pos2)
					{
						break;
					}
				}while(1);
				debug(DEBUG_ERROR, "vlanid:%u\n",
					(unsigned short)((pay_load[pay_load_len-2]<<8)|pay_load[pay_load_len-1]));
			}
			ts_tlv_flag = 0;
			ts_tlv_count = 0;
		}
#ifdef MAP_R3
		/* SP TLV will appear as:
		 * 00:0c:43:48:a0:6f, 0x8023,
		 * 0xB9,0x0009,0x00000000 0x80 0xFE 0x05 0x20 0x03,
		 * 0xB9,0x0009,0x00000001 0x80 0xFD 0x04 0x20 0x01,
		 * 0xB9,0x000E,0x00000002 0x80 0xFC 0x02 0x02 5c:80:b6:0f:c5:c1,
		 * 0xB9,0x0014,0x00000003 0x80 0xFB 0x01 0x0A a4:c3:f0:ec:8e:1b 5c:80:b6:0f:c5:c1,
		 * 0xB9,0x000E,0x00000004 0x80 0xFA 0x03 0x08 a4:c3:f0:ec:8e:11
		*/
		if ((value == SERVICE_PRIORITIZATION_RULE_TYPE) && (msg_type == SERVICE_PRIORITIZATION_REQUEST)) {
			/*skip '0x', tlv length*/
			pos1 = str_locate(pos1, "0x");
			if (!pos1)
				goto error1;
			pos1 += 2;
			for (i = 0; i < 2; i ++) {
				memset(byte_value, 0, sizeof(byte_value));
				memcpy(byte_value, pos1, 2);
				errno = 0;
				value = strtol((char *)byte_value, &endptr, 16);
				if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
					|| (errno != 0 && value == 0) || (endptr == (char *)byte_value)) {
					debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
					goto error1;
				}
				pay_load[pay_load_len++] = (unsigned char)value;
				pos1 += 2;
			}

			/*skip '0x', rule ID*/
			pos1 = str_locate(pos1, "0x");
			if (!pos1)
				goto error1;
			pos1 += 2;
			for (i = 0; i < 4; i ++) {
				memset(byte_value, 0, sizeof(byte_value));
				memcpy(byte_value, pos1, 2);
				errno = 0;
				value = strtol((char *)byte_value, &endptr, 16);
				if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
					|| (errno != 0 && value == 0) || (endptr == (char *)byte_value)) {
					debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
					goto error1;
				}
				pay_load[pay_load_len++] = (unsigned char)value;
				pos1 += 2;
			}
			debug(DEBUG_OFF, "ruleid:0x%02x\n", (int)value);

			/*skip '0x', add-remove filter*/
			pos1 = str_locate(pos1, "0x");
			if (!pos1)
				goto error1;
			pos1 += 2;
			memset(byte_value, 0, sizeof(byte_value));
			memcpy(byte_value, pos1, 2);
			errno = 0;
			value = strtol((char *)byte_value, &endptr, 16);
			if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
				|| (errno != 0 && value == 0) || (endptr == (char *)byte_value)) {
				debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
				goto error1;
			}
			pay_load[pay_load_len++] = (unsigned char)value;
			pos1 += 2;
			add_rm_flag = value;
			debug(DEBUG_OFF, "add-remove:0x%02x\n", (int)value);

			/*skip '0x', precedence*/
			if (!add_rm_flag) {
				/* there is no any more data when add_rm_flag equals 0 */
				/* continue to check if any other rule need to be handled */
				debug(DEBUG_OFF, "no more data for this rule, continue to check other rules\n");
				continue;
			}

			pos1 = str_locate(pos1, "0x");
			if (!pos1)
				goto error1;
			pos1 += 2;
			memset(byte_value, 0, sizeof(byte_value));
			memcpy(byte_value, pos1, 2);
			errno = 0;
			value = strtol((char *)byte_value, &endptr, 16);
			if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
				|| (errno != 0 && value == 0) || (endptr == (char *)byte_value)) {
				debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
				goto error1;
			}
			pay_load[pay_load_len++] = (unsigned char)value;
			pos1 += 2;
			debug(DEBUG_OFF, "precedence:0x%02x\n", (int)value);

			/*skip '0x', output*/
			pos1 = str_locate(pos1, "0x");
			if (!pos1)
				goto error1;
			pos1 += 2;
			memset(byte_value, 0, sizeof(byte_value));
			memcpy(byte_value, pos1, 2);
			errno = 0;
			value = strtol((char *)byte_value, &endptr, 16);
			if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
				|| (errno != 0 && value == 0) || (endptr == (char *)byte_value)) {
				debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
				goto error1;
			}
			pay_load[pay_load_len++] = (unsigned char)value;
			pos1 += 2;
			debug(DEBUG_OFF, "output:0x%02x\n", (int)value);

			/*skip '0x', parse flag_mask*/
			pos1 = str_locate(pos1, "0x");
			if (!pos1)
				goto error1;
			pos1 += 2;
			memset(byte_value, 0, sizeof(byte_value));
			memcpy(byte_value, pos1, 2);
			errno = 0;
			value = strtol((char *)byte_value, &endptr, 16);
			if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
				|| (errno != 0 && value == 0) || (endptr == (char *)byte_value)) {
				debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
				goto error1;
			}
			pay_load[pay_load_len++] = (unsigned char)flag_mask;
			pos1 += 2;
			debug(DEBUG_OFF, "flag_mask:0x%02x\n", flag_mask);

			if (flag_mask & 0x20) {
				/*skip '0x', up*/
				pos1 = str_locate(pos1, "0x");
				if (!pos1)
					goto error1;
				pos1 += 2;
				memset(byte_value, 0, sizeof(byte_value));
				memcpy(byte_value, pos1, 2);
				errno = 0;
				value = strtol((char *)byte_value, &endptr, 16);
				if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
					|| (errno != 0 && value == 0) || (endptr == (char *)byte_value)) {
					debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
					goto error1;
				}
				pay_load[pay_load_len++] = (unsigned char)value;
				pos1 += 2;
				debug(DEBUG_OFF, "up:0x%02x\n", (int)value);
			}

			if (flag_mask & 0x08) {
				/*find source mac, smac*/
				pos1 = str_locate(pos1, ":");
				if (!pos1)
					goto error1;
				pos1 -= 2;
				if (sscanf(pos1, "%02x:%02x:%02x:%02x:%02x:%02x", mac_int, mac_int + 1,
					mac_int + 2, mac_int + 3, mac_int + 4, mac_int + 5) < 0) {
					debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
					goto error1;
				}
				for(i = 0; i < 6; i++)
					sa_mac[i] = (unsigned char)mac_int[i];
				pos1 += 17;
				memcpy(&pay_load[pay_load_len], sa_mac, ETH_ALEN);
				pay_load_len += ETH_ALEN;
				debug(DEBUG_OFF, "SA: "MACSTR"\n", MAC2STR(sa_mac));
			}

			if (flag_mask & 0x02) {
				/*find dest mac, dmac*/
				pos1 = str_locate(pos1, ":");
				if (!pos1)
					goto error1;
				pos1 -= 2;
				if (sscanf(pos1, "%02x:%02x:%02x:%02x:%02x:%02x", mac_int, mac_int + 1,
					mac_int + 2, mac_int + 3, mac_int + 4, mac_int + 5) < 0) {
					debug(DEBUG_ERROR, "[%d]sscanf fail!\n", __LINE__);
					goto error1;
				}
				for(i = 0; i < 6; i++)
					da_mac[i] = (unsigned char)mac_int[i];
				pos1 += 17;
				memcpy(&pay_load[pay_load_len], da_mac, ETH_ALEN);
				pay_load_len += ETH_ALEN;
				debug(DEBUG_OFF, "DA: "MACSTR"\n", MAC2STR(da_mac));
			}
		}
#endif
	}
	hex_dump("dev_send_1905", pay_load, pay_load_len);
	*tlv_len = pay_load_len;
	*_type = (unsigned short)msg_type;
	memcpy(almac, al_mac, 6);
	if (fclose(f) < 0)
		debug(DEBUG_ERROR, "[%d]fclose fail!\n", __LINE__);
	os_free(content);
	return 0;
error1:
	if (fclose(f) < 0)
		debug(DEBUG_ERROR, "[%d]fclose fail!\n", __LINE__);
	if (content)
		os_free(content);
	return -1;


}

int _1905_write_wts_file_content(char *buf, char *name)
{
	FILE *f = NULL;
	size_t result;

	debug(DEBUG_OFF, "%s\n", __func__);

	f = fopen(name, "w+");
	if (f == NULL) {
		debug(DEBUG_ERROR, "%s: open file %s fail\n", __func__, name);
		return -1;
	}

	result = fwrite(buf, 1, strlen(buf), f);
	if (result != strlen(buf)) {
		debug(DEBUG_ERROR, "%s: write error", __func__);
		if (fclose(f) < 0)
			debug(DEBUG_ERROR, "[%d]fclose fail!\n", __LINE__);
		return -1;
	}

	if (fclose(f) < 0)
		debug(DEBUG_ERROR, "[%d]fclose fail!\n", __LINE__);
	return 0;
}

int write_almac_to_1905_cfg_file(char *cfg_file_name, unsigned char *almac)
{
	FILE *file;
	char *cpos = NULL, *apos = NULL;
	char almac_str[32];
	int cpos_cnt = 0, apos_cnt = 0, i = 0;
	char file_name[MAX_FILE_PATH_LENGTH] = {0};
	char content[2048] = {0};
	signed char ch = 0;
	int tmp = 0;

	tmp = snprintf(file_name, sizeof(file_name), "%s", cfg_file_name);
	if (os_snprintf_error(sizeof(file_name), tmp)) {
		debug(DEBUG_ERROR, "[%d]snprintf fail!\n", __LINE__);
		return -1;
	}

	file = fopen(file_name, "r");
	if (!file) {
		debug(DEBUG_ERROR, "open MAP cfg file (%s) fail\n", file_name);
		return -1;
	}
	do {
		tmp = fgetc(file);
		if (tmp == EOF)
			break;
		ch = (signed char)tmp;
		content[i++] = ch;
	}while (EOF != ch && i < (sizeof(content) - 1));
	(void)fclose(file);

	cpos = strstr(content, "map_controller_alid");
	if (!cpos) {
		debug(DEBUG_ERROR, "cannot find map_controller_alid str\n");
		return -1;
	}
	apos = strstr(content, "map_agent_alid");
	if (!apos) {
		debug(DEBUG_ERROR, "cannot find map_agent_alid str\n");
		return -1;
	}

	cpos_cnt = cpos - content + os_strlen("map_controller_alid");
	apos_cnt = apos - content + os_strlen("map_agent_alid");

	file = fopen(file_name, "r+");
	if (!file) {
		debug(DEBUG_ERROR, "open MAP cfg file (%s) fail at second time\n", file_name);
		return -1;
	}
	if (fseek(file, 0, SEEK_SET) != 0) {
		debug(DEBUG_ERROR, "[%d]feek fail!\n", __LINE__);
		(void)fclose(file);
		return -1;
	}
	if (fseek(file, cpos_cnt, SEEK_SET) != 0) {
		debug(DEBUG_ERROR, "[%d]feek fail!\n", __LINE__);
		(void)fclose(file);
		return -1;
	}
	do {
		tmp = fgetc(file);
		if (tmp == EOF)
			break;
		ch = (signed char)tmp;
		if (ch != '=' && ch != ' ')
			break;
	} while (ch != '\n' && ch != '\r');
	os_memset(almac_str, 0, sizeof(almac_str));
	tmp = snprintf(almac_str, sizeof(almac_str), ""MACSTR"", PRINT_MAC(almac));
	if (os_snprintf_error(sizeof(almac_str), tmp)) {
		(void)fclose(file);
		return -1;
	}

	if (fseek(file, -1, SEEK_CUR) != 0) {
		debug(DEBUG_ERROR, "[%d]feek fail!\n", __LINE__);
		(void)fclose(file);
		return -1;
	}
	if (fputs(almac_str, file) == EOF) {
		debug(DEBUG_ERROR, "[%d]fputs fail", __LINE__);
		(void)fclose(file);
		return -1;
	}
	if (fseek(file, 0, SEEK_SET) != 0) {
		debug(DEBUG_ERROR, "[%d]feek fail!\n", __LINE__);
		(void)fclose(file);
		return -1;
	}
	if (fseek(file, apos_cnt, SEEK_SET) != 0) {
		debug(DEBUG_ERROR, "[%d]feek fail!\n", __LINE__);
		(void)fclose(file);
		return -1;
	}
	do {
		tmp = fgetc(file);
		if (tmp == EOF)
			break;
		ch = (signed char)tmp;
		if (ch != '=' && ch != ' ')
			break;
	} while (ch != '\n' && ch != '\r');
	os_memset(almac_str, 0, sizeof(almac_str));
	tmp = snprintf(almac_str, sizeof(almac_str), ""MACSTR"", PRINT_MAC(almac));
	if (os_snprintf_error(sizeof(almac_str), tmp)) {
		debug(DEBUG_ERROR, "[%d]snprinft fail!\n", __LINE__);
		(void)fclose(file);
		return -1;
	}

	if (fseek(file, -1, SEEK_CUR) != 0) {
		debug(DEBUG_ERROR, "[%d]feek fail!\n", __LINE__);
		(void)fclose(file);
		return -1;
	}
	if (fputs(almac_str, file) == EOF) {
		debug(DEBUG_ERROR, "[%d]fputs fail", __LINE__);
		(void)fclose(file);
		return -1;
	}
	(void)fclose(file);

	return 0;
}


int write_bss_prio_to_1905_cfg_file(char *cfg_file_name, char *bss_prio)
{
	char cmd[512] = {0};
	int ret_len = 0;
	int ret = 0;

	ret_len = snprintf(cmd, sizeof(cmd),
		"datconf -f %s set bss_config_priority \"%s\"",
		cfg_file_name, bss_prio);
	if (os_snprintf_error(sizeof(cmd), ret_len)) {
		debug(DEBUG_ERROR, BSS_PRIO_PREX"snprintf for bss_config_priority fail\n");
		return -1;
	}

	ret = os_execute("/usr/sh", 3, "sh", "-c", cmd);
	if (ret < 0) {
		debug(DEBUG_OFF, BSS_PRIO_PREX"cmd fail:%s\n", cmd);
		return -1;
	}

	return 0;
}

#ifdef MAP_R2
static int parse_transparent_vid(struct p1905_managerd_ctx *ctx, char *str_vids)
{
	char *token = NULL;
	unsigned char i = 0;
	long vid = 0;
	char *endptr;

	token = strtok(str_vids, ";");

	while (token != NULL) {
		errno = 0;
		vid = strtol(token, &endptr, 10);

		if (token == endptr || *endptr != '\0') {
			vid = INVALID_VLAN_ID;
			debug(DEBUG_ERROR, "fail to parse transparent vid, continue\n");
		} else {
			debug(DEBUG_OFF, "\transparent vid=%ld\n", vid);
		}

		token = strtok(NULL, ";");

		if (vid >= INVALID_VLAN_ID || vid < 1) {
			debug(DEBUG_ERROR, "invalid vlan id %ld\n", vid);
			continue;
		}

		ctx->map_policy.trans_vlan.transparent_vids[i++] = (unsigned short)vid;
		if (i >= MAX_NUM_TRANSPARENT_VID)
			break;
	}

	ctx->map_policy.trans_vlan.num = i;
	ctx->map_policy.trans_vlan.updated = 1;
	debug(DEBUG_ERROR, "transparent vlan id number=%d\n", ctx->map_policy.trans_vlan.num);

	return 0;
}
#endif


int map_read_config_file(struct p1905_managerd_ctx *ctx)
{
	FILE *file;
	char buf[256], *pos, *token, *token1;
	char tmpbuf[256];
	int line = 0, i = 0;
	unsigned char intf_idx = 0;
	long value = 0;
	int ret = 0;
	char *endptr = NULL;
#ifdef EM_PLUS_SUPPORT
		int feature_id = 0, feature_ver = 0;
		struct emplus_feature_prof *feature_prof = &ctx->feature_prof;
#endif /* EM_PLUS_SUPPORT */

	if (strlen(ctx->map_cfg_file) == 0) {
		ret = snprintf(ctx->map_cfg_file, sizeof(ctx->map_cfg_file), "%s", MAP_CFG_FILE);
		if (os_snprintf_error(sizeof(ctx->map_cfg_file), ret)) {
			debug(DEBUG_ERROR, "[%d]snprintf fail!\n", __LINE__);
			return -1;
		}
	}

	file = fopen(ctx->map_cfg_file, "r");
	if (!file) {
		debug(DEBUG_ERROR, "open MAP cfg file (%s) fail\n", ctx->map_cfg_file);
		return -1;
	}
	os_memset(buf, 0, 256);
	os_memset(tmpbuf, 0, 256);

	while (map_config_get_line(buf, sizeof(buf), file, &line, &pos)) {
		if (strlen(pos) < 256) {
			ret = snprintf(tmpbuf, sizeof(tmpbuf), "%s", pos);
			if (os_snprintf_error(sizeof(tmpbuf), ret)) {
				debug(DEBUG_ERROR, "[%d]snprintf fail!\n", __LINE__);
				goto error;
			}
		}
		token = strtok(pos, "=");
		if (token != NULL) {
			if (os_strcmp(token, "map_controller_alid") == 0) {
				if (ctx->role == CONTROLLER) {
					token = strtok(NULL, "");
					if (!token) {
						debug(DEBUG_ERROR, "no map_controller_alid content\n");
						goto error;
					}
					i = 0;
					token1 = strtok(token, ":");
					while (token1 != NULL) {
						AtoH(token1, (char *)&ctx->p1905_al_mac_addr[i], 1);
						i++;
						if (i >= ETH_ALEN)
							break;
						token1 = strtok(NULL, ":");
					}
					debug(DEBUG_OFF, "map_controller_alid = "MACSTR"\n",
						PRINT_MAC(ctx->p1905_al_mac_addr));
				}
			} else if (os_strcmp(token, "map_agent_alid") == 0) {
				if (ctx->role == AGENT) {
					token = strtok(NULL, "");
					if (!token) {
						debug(DEBUG_ERROR, "no map_agent_alid content\n");
						goto error;
					}
					i = 0;
					token1 = strtok(token, ":");
					while (token1 != NULL) {
						AtoH(token1, (char *)&ctx->p1905_al_mac_addr[i], 1);
						i++;
						if (i >= ETH_ALEN)
							break;
						token1 = strtok(NULL, ":");
					}
					debug(DEBUG_OFF, "map_agent_alid = "MACSTR"\n",
						PRINT_MAC(ctx->p1905_al_mac_addr));
				}
			} else if (os_strcmp(token, "br_inf") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					debug(DEBUG_ERROR, "no br_inf content\n");
					goto error;
				}
				ret = snprintf((char *)ctx->br_name, sizeof(ctx->br_name), "%s", token);
				if (os_snprintf_error(sizeof(ctx->br_name), ret)) {
					debug(DEBUG_ERROR, "[%d]snprintf fail!\n", __LINE__);
					goto error;
				}
				debug(DEBUG_OFF, "br_inf = %s\n", ctx->br_name);
			} else if (os_strcmp(token, "lan") == 0) {
				intf_idx = ctx->itf_number;
				token = strtok(NULL, "");
				if (!token)
					continue;
				ret = snprintf((char *)ctx->itf[intf_idx].if_name,
					sizeof(ctx->itf[intf_idx].if_name), "%s", token);
				if (os_snprintf_error(sizeof(ctx->itf[intf_idx].if_name), ret)) {
					debug(DEBUG_ERROR, "[%d]snprintf fail!\n", __LINE__);
					goto error;
				}
				debug(DEBUG_OFF, "lan = %s\n", ctx->itf[intf_idx].if_name);
				ctx->itf[intf_idx].media_type = IEEE802_3_GROUP;
				ctx->itf[intf_idx].is_wifi_sta = 0;
				ctx->itf_number++;
			} else if (os_strcmp(token, "wan") == 0) {
				intf_idx = ctx->itf_number;
				token = strtok(NULL, "");
				if (!token)
					continue;
				/* skip modem interface */
				if (memcmp(token, "eth", 3))
					continue;
				ret = snprintf((char *)ctx->itf[intf_idx].if_name,
					sizeof(ctx->itf[intf_idx].if_name), "%s", token);
				if (os_snprintf_error(sizeof(ctx->itf[intf_idx].if_name), ret)) {
					debug(DEBUG_ERROR, "[%d]snprintf fail!\n", __LINE__);
					goto error;
				}
				debug(DEBUG_OFF, "wan = %s\n", ctx->itf[intf_idx].if_name);
				ctx->itf[intf_idx].media_type = IEEE802_3_GROUP;
				ctx->itf[intf_idx].is_wifi_sta = 0;
				ctx->itf[intf_idx].is_wan = 1;
				ctx->itf_number++;
			} else if(os_strcmp(token, "veth") == 0) {
				intf_idx = ctx->itf_number;
				token = strtok(NULL, "");
				if (!token)
					continue;
				ret = snprintf((char *)ctx->itf[intf_idx].if_name,
					sizeof(ctx->itf[intf_idx].if_name), "%s", token);
				if (os_snprintf_error(sizeof(ctx->itf[intf_idx].if_name), ret)) {
					debug(DEBUG_ERROR, "[%d]snprintf fail!\n", __LINE__);
					goto error;
				}
				debug(DEBUG_OFF, "veth = %s\n", ctx->itf[intf_idx].if_name);
				ctx->itf[intf_idx].media_type = IEEE802_3_GROUP;
				ctx->itf[intf_idx].is_wifi_sta = 0;
				ctx->itf[intf_idx].is_veth = 1;
				ctx->itf_number++;
			} else if (os_strcmp(token, "ob_wan_only") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					debug(DEBUG_ERROR, "[%d]no OB_WAN_ONLY!\n", __LINE__);
					goto error;
				}
				errno = 0;
				value = strtol(token, &endptr, 10);
				if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
					|| (errno != 0 && value == 0) || (endptr == token)) {
					debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
					goto error;
				}
				if (value < 0)
					value = 0;
				ctx->restrict_wan_onboarding = value;
			}
#ifdef MAP_R2
 			else if (os_strcmp(token, "map_ver") == 0) {
 				token = strtok(NULL, "");
				if (!token) {
					debug(DEBUG_ERROR, "no map_ver content\n");
					goto error;
				}
				if (os_strcmp(token, "R1") == 0)
					ctx->map_version = DEV_TYPE_R1;
				else
					ctx->map_version = DEV_TYPE_R2;

#ifdef MAP_R3
				if (os_strcmp(token, "R3") == 0)
					ctx->map_version = DEV_TYPE_R3;
#endif


				debug(DEBUG_OFF, "ctx->map_version = %d\n", ctx->map_version);
			} else if (os_strcmp(token, "transparent_vids") == 0) {
				if (ctx->role == CONTROLLER) {
					token = strtok(NULL, "");
					if (!token)
						continue;
					parse_transparent_vid(ctx, token);
				}
			}
#endif
			else if (os_strcmp(token, "al_inf") == 0) {
				token = strtok(NULL, "");
				if (!token)
					continue;
				os_memset(ctx->al_inf, 0, IFNAMSIZ);
				ret = snprintf((char *)ctx->al_inf, sizeof(ctx->al_inf), "%s", token);
				if (os_snprintf_error(sizeof(ctx->al_inf), ret)) {
					debug(DEBUG_ERROR, "[%d]snprintf fail!\n", __LINE__);
					goto error;
				}
				debug(DEBUG_OFF, "al_inf = %s\n", ctx->al_inf);
			}
			else if (os_strcmp(token, "discovery_cnt") == 0) {
				token = strtok(NULL, "");
				if (!token)
					continue;
				errno = 0;
				value = strtol(token, &endptr, 10);
				if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
					|| (errno != 0 && value == 0) || (endptr == token)) {
					debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
					goto error;
				}
				if (value < 0)
					value = 0;
				ctx->discovery_cnt = (int)value;
				debug(DEBUG_OFF, "discovery_cnt = %d\n", ctx->discovery_cnt);
			} else if (os_strcmp(token, "bss_config_priority") == 0) {
				token = strtok(NULL, "");
				if (!token)
					continue;
				if (os_strlen(token) >= (MAX_RADIO_NUM * (IFNAMSIZ + 1) * MAX_BSS_NUM)) {
					debug(DEBUG_ERROR, "bss_config_priority string too long\n");
					continue;
				}
				ret = snprintf(ctx->bss_priority_str, sizeof(ctx->bss_priority_str), "%s", token);
				if (os_snprintf_error(sizeof(ctx->bss_priority_str), ret)) {
					debug(DEBUG_ERROR, "[%d]snprintf fail!\n", __LINE__);
					goto error;
				}
				debug(DEBUG_OFF, "bss_config_priority: %s\n", token);
			}
#ifdef MAP_R3
			else if (os_strcmp(token, "decrypt_fail_threshold") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					debug(DEBUG_ERROR, "[%d]no decrypt_fail_threshold!\n", __LINE__);
					goto error;
				}
				errno = 0;
				value = strtol(token, &endptr, 10);
				if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
					|| (errno != 0 && value == 0) || (endptr == token)) {
					debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
					goto error;
				}
				if (value < 0)
					value = 0;
				ctx->decrypt_fail_threshold = (unsigned int)value;
				if (ctx->decrypt_fail_threshold <= 0) {
					ctx->decrypt_fail_threshold = DECRYPT_FAULURE_THRESHOLD;
				}
				debug(DEBUG_OFF, "decrypt_fail_threshold = %d\n", ctx->decrypt_fail_threshold);
			}
			else if (os_strcmp(token, "gtk_rekey_interval") == 0) {
				long interval = 0;
				token = strtok(NULL, "");
				if (!token) {
					debug(DEBUG_ERROR, "[%d]no gtk_rekey_interval!\n", __LINE__);
					goto error;
				}
				errno = 0;
				interval = strtol(token, &endptr, 10);
				if ((errno == ERANGE && (interval == LONG_MAX || interval == LONG_MIN))
					|| (errno != 0 && interval == 0) || (endptr == token)) {
					debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
					goto error;
				}
				if (interval <= 0)
					interval = 100;

				ctx->gtk_rekey_interval = (unsigned int)interval;
			}
#endif

#ifdef MAP_R5
			else if (os_strcmp(token, "mscs_capa") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					debug(DEBUG_ERROR, "[%d]no mscs_capa!\n", __LINE__);
					goto error;
				}
				errno = 0;
				value = strtol(token, &endptr, 10);
				if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
					|| (errno != 0 && value == 0) || (endptr == token)) {
					debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
					goto error;
				}
				if (value == 1)
					ctx->config_adv_capability |= AP_CAPA_SUPPORT_MSCS;
				else
					ctx->config_adv_capability &= ~AP_CAPA_SUPPORT_MSCS;

				debug(DEBUG_TRACE, "mscs_capa = %d\n", (int)value);
			} else if (os_strcmp(token, "scs_capa") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					debug(DEBUG_ERROR, "[%d]no scs_capa!\n", __LINE__);
					goto error;
				}
				errno = 0;
				value = strtol(token, &endptr, 10);
				if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
					|| (errno != 0 && value == 0) || (endptr == token)) {
					debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
					goto error;
				}
				if (value == 1)
					ctx->config_adv_capability |= AP_CAPA_SUPPORT_SCS;
				else
					ctx->config_adv_capability &= ~AP_CAPA_SUPPORT_SCS;

				debug(DEBUG_TRACE, "scs_capa = %d\n", (int)value);
			} else if (os_strcmp(token, "qosmap_capa") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					debug(DEBUG_ERROR, "[%d]no qosmap_capa!\n", __LINE__);
					goto error;
				}
				errno = 0;
				value = strtol(token, &endptr, 10);
				if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
					|| (errno != 0 && value == 0) || (endptr == token)) {
					debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
					goto error;
				}
				if (value == 1)
					ctx->config_adv_capability |= AP_CAPA_SUPPORT_DSCP_TO_UP_MAP;
				else
					ctx->config_adv_capability &= ~AP_CAPA_SUPPORT_DSCP_TO_UP_MAP;

				debug(DEBUG_TRACE, "qosmap_capa = %d\n", (int)value);
			} else if (os_strcmp(token, "dscppolicy_capa") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					debug(DEBUG_ERROR, "[%d]no dscppolicy_capa!\n", __LINE__);
					goto error;
				}
				errno = 0;
				value = strtol(token, &endptr, 10);
				if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
					|| (errno != 0 && value == 0) || (endptr == token)) {
					debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
					goto error;
				}
				if (value == 1)
					ctx->config_adv_capability |= AP_CAPA_SUPPORT_DSCP_POLICY;
				else
					ctx->config_adv_capability &= ~AP_CAPA_SUPPORT_DSCP_POLICY;

				debug(DEBUG_TRACE, "dscppolicy_capa = %d\n", (int)value);
			}
#endif
#ifdef BR_IP_TLV_SUPPORT
			else if (os_strcmp(token, "br_info_tlv") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					debug(DEBUG_ERROR, "[%d]br info tlv!\n", __LINE__);
					goto error;
				}
				errno = 0;
				value = strtol(token, &endptr, 10);
				if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
					|| (errno != 0 && value == 0) || (endptr == token)) {
					debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
					goto error;
				}
				if (value > 0)
					ctx->include_brinfo_tlv = 1;
				else
					ctx->include_brinfo_tlv = 0;
				debug(DEBUG_ERROR, "include_brinfo_tlv:%d\n", ctx->include_brinfo_tlv);
			}
#endif /* BR_IP_TLV_SUPPORT */
			else if (os_strcmp(token, "DisableTearDown") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					debug(DEBUG_ERROR, "[%d]DisableTearDown!\n", __LINE__);
					goto error;
				}
				errno = 0;
				value = strtol(token, &endptr, 10);
				if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
					|| (errno != 0 && value == 0) || (endptr == token)) {
					debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
					goto error;
				}
				if (value < 0)
					value = 0;
				ctx->disable_tear_down = value;
			}
			else if (os_strcmp(token, "block_bss_autoconfig") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					debug(DEBUG_ERROR, "block_bss_autoconfig is NULL\n");
					continue;
				}
				errno = 0;
				value = strtol(token, &endptr, 10);
				if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
					|| (errno != 0 && value == 0) || (endptr == token)) {
					debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
					goto error;
				}
				if (value > 0)
					ctx->block_bss_info.block_bss_autoconfig = 1;
				else
					ctx->block_bss_info.block_bss_autoconfig = 0;
				debug(DEBUG_INFO, "block_bss_autoconfig = %d\n", ctx->block_bss_info.block_bss_autoconfig);
			}
#ifdef EM_PLUS_SUPPORT
			else if (os_strcmp(token, "emplus_version") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					debug(DEBUG_ERROR, "emplus_version is NULL\n");
					continue;
				}
				token1 = strtok(token, ".");
				if (token1 != NULL) {
					errno = 0;
					value = strtol(token1, &endptr, 10);
					if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
						|| (errno != 0 && value == 0) || (endptr == token1)) {
						debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
						goto error;
					}
					if (value < 0)
						value = 0;
					feature_prof->master_ver = value;
				}
				token1 = strtok(NULL, ".");
				if (token1 != NULL) {
					errno = 0;
					value = strtol(token1, &endptr, 10);
					if ((errno == ERANGE && (value == LONG_MAX || value == LONG_MIN))
						|| (errno != 0 && value == 0) || (endptr == token1)) {
						debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
						goto error;
					}
					if (value < 0)
						value = 0;
					feature_prof->sub_ver = value;
				}
				debug(DEBUG_TRACE, "emplus feature profile master ver = %d, sub ver = %d",
				feature_prof->master_ver, feature_prof->sub_ver);
			} else if (os_strcmp(token, "emplus_dev_metircs") == 0) {
				feature_id = EMPLUS_DEV_METRICES_ID;
			} else if (os_strcmp(token, "emplus_1905_2014") == 0) {
				feature_id = EMPLUS_SUPPORT_1905_2014;
			} else if (os_strcmp(token, "emplus_dev_info") == 0) {
				feature_id = EMPLUS_DEV_INFO_ID;
			} else if (os_strcmp(token, "emplus_eth_status") == 0) {
				feature_id = EMPLUS_ETH_STATS_ID;
			} else if (os_strcmp(token, "emplus_reboot_reset") == 0) {
				feature_id = EMPLUS_REBOOT_REQ_ID;
			} else if (os_strcmp(token, "emplus_wifi6_cap_report") == 0) {
				feature_id = EMPLUS_SUPPORT_WIFI6;
			} else if (os_strcmp(token, "emplus_dpp_onboad") == 0) {
				feature_id = EMPLUS_SUPPORT_DPP;
			} else if (os_strcmp(token, "emplus_stp_support") == 0) {
				feature_id = EMPLUS_SUPPORT_STP;
			} else if (os_strcmp(token, "	") == 0) {
				feature_id = EMPLUS_SUPPORT_LED_ID;
			} else if (os_strcmp(token, "emplus_wifi_switch") == 0) {
				feature_id = EMPLUS_SUPPORT_WIFI_SWTICH;
			} else if (os_strcmp(token, "emplus_hidden_ssid") == 0) {
				feature_id = EMPLUS_SUPPORT_HIDDEN_SSID;
			} else if (os_strcmp(token, "emplus_radio_mode_sharing") == 0) {
				feature_id = EMPLUS_SUPPORT_RADIO_MODE_SHARING;
			} else if (os_strcmp(token, "emplus_client_id") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					debug(DEBUG_ERROR, "no emplus_client_id content\n");
					continue;
				}
				ctx->client_id_len = strlen(token);
				ctx->client_id = os_zalloc(ctx->client_id_len + 1);
				if (!ctx->client_id)
					goto error;
				ret = snprintf((char *)ctx->client_id, ctx->client_id_len + 1, "%s", token);
				if (os_snprintf_error(sizeof(ctx->client_id), ret)) {
					debug(DEBUG_ERROR, "[%d]snprintf fail!\n", __LINE__);
					goto error;
				}
			} else if (os_strcmp(token, "emplus_client_secret") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					debug(DEBUG_ERROR, "no emplus_client_secret content\n");
					continue;
				}
				ctx->client_secret_len = strlen(token);
				ctx->client_secret = os_zalloc(ctx->client_secret_len + 1);
				if (!ctx->client_secret)
					goto error;
				ret = snprintf((char *)ctx->client_secret, ctx->client_secret_len + 1, "%s", token);
				if (os_snprintf_error(sizeof(ctx->client_secret), ret)) {
					debug(DEBUG_ERROR, "[%d]snprintf fail!\n", __LINE__);
					goto error;
				}
			} else if (os_strcmp(token, "emplus_product_class") == 0) {
				int  product_class = 0;
				token = strtok(NULL, "");
				if (!token)
					continue;
				errno = 0;
				product_class = strtol(token, &endptr, 10);
				if ((errno == ERANGE && (product_class == LONG_MAX || product_class == LONG_MIN))
					|| (errno != 0 && product_class == 0) || (endptr == token)) {
					debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
					goto error;
				}
				if (product_class == GATWAY)
					ctx->emplus_product_class |= EMPLUS_GATEWAY;
				else if (product_class == EXTENDER)
					ctx->emplus_product_class |= EMPLUS_EXTENDER;
				else if (product_class == STB)
					ctx->emplus_product_class = EMPLUS_STB;
				else
					debug(DEBUG_ERROR, "not find ctx->emplus_product_class\n");
				debug(DEBUG_TRACE, "emplus_product_class = %d\n", ctx->emplus_product_class);
			} else if (os_strcmp(token, "ser_num") == 0) {
				token = strtok(NULL, "");
				if (!token) {
					debug(DEBUG_ERROR, "no ser_num\n");
					continue;
				}

				ctx->product.ser_num_len = os_strlen(token);
				ctx->product.ser_num = os_zalloc(ctx->product.ser_num_len + 1);
				if (!ctx->product.ser_num)
					goto error;

				os_memcpy(ctx->product.ser_num, token, ctx->product.ser_num_len);
				debug(DEBUG_TRACE, "ser_num: %s\n", ctx->product.ser_num);
			} else if (os_strcmp(token, "BH_BSS_NAME") == 0) {
				token = strtok(NULL, ",");
				i = 0;
				while (token) {
					if (i >= MAX_RADIO_NUM)
						break;

					ret = snprintf((char *)&ctx->bh_bss_name[i], IFNAMSIZ, "%s", token);
					if (os_snprintf_error(IFNAMSIZ, ret)) {
						debug(DEBUG_ERROR, "[%d]snprintf fail!\n", __LINE__);
						goto error;
					}
					ctx->bh_bss_number++;
					i++;
					token = strtok(NULL, ",");
				}
				for (int i = 0; i < ctx->bh_bss_number; i++)
					debug(DEBUG_ERROR, "BH_BSS[%d] %s\n", i, ctx->bh_bss_name[i]);
				debug(DEBUG_ERROR, "BH_BSS_NUMBER = %d\n", ctx->bh_bss_number);
				if (!token)
					continue;
			} else if (os_strcmp(token, "GUEST_BSS_NAME") == 0) {
				token = strtok(NULL, ",");
				i = 0;
				while (token) {
					if (i >= MAX_RADIO_NUM * MAX_BSS_NUM)
						break;

					ret = snprintf((char *)&ctx->guest_bss_name[i], IFNAMSIZ, "%s", token);
					if (os_snprintf_error(IFNAMSIZ, ret)) {
						debug(DEBUG_ERROR, "[%d]snprintf fail!\n", __LINE__);
						goto error;
					}
					ctx->guest_bss_number++;
					i++;
					token = strtok(NULL, ",");
				}
				for (int i = 0; i < ctx->guest_bss_number; i++)
					debug(DEBUG_ERROR, "GUEST_BSS[%d] %s\n", i, ctx->guest_bss_name[i]);
				debug(DEBUG_ERROR, "GUEST_BSS_NUMBER = %d\n", ctx->guest_bss_number);
				if (!token)
					continue;
			}
			if (feature_id != 0) {
				token = strtok(NULL, "");
				if (!token) {
					debug(DEBUG_ERROR, "feature id %d, no ver info using default\n",
						feature_id);
					feature_ver = 0;
					insert_emplus_feature_list(ctx, feature_id, feature_ver);
					/* reset feature_id */
					feature_id = 0;
					continue;
				}
				errno = 0;
				feature_ver = strtol(token, &endptr, 10);
				if ((errno == ERANGE && (feature_ver == LONG_MAX || feature_ver == LONG_MIN))
					|| (errno != 0 && feature_ver == 0) || (endptr == token)) {
					debug(DEBUG_ERROR, "[%d]strtol fail!\n", __LINE__);
					goto error;
				}
				if (feature_ver < 0)
					feature_ver = 0;
				debug(DEBUG_TRACE, "emplus feature_id %d, feature_ver %d\n",
					feature_id, feature_ver);
				insert_emplus_feature_list(ctx, feature_id, feature_ver);
				/* reset feature_id */
				feature_id = 0;
			}
#endif /* EM_PLUS_SUPPORT */

		}
	}

	(void)fclose(file);

	if (ctx->discovery_cnt <= 0 || ctx->discovery_cnt > 60) {
		ctx->discovery_cnt = TOPOLOGY_DISCOVERY_COUNT;
		debug(DEBUG_OFF, "set discovery_cnt to defaut value(%d)\n",
			ctx->discovery_cnt);
	}

	return 0;

error:
	(void)fclose(file);
	return -1;
}

