/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdio.h>
#include <string.h>
#include <syslog.h>
#include <assert.h>
#include <linux/if_ether.h>
#include <asm/byteorder.h>
#include <stdlib.h>
#include "p1905_managerd.h"
#include "cmdu_message.h"
#include "cmdu_tlv_parse.h"
#include "cmdu.h"
#include "debug.h"
#include "_1905_lib_io.h"
#include "file_io.h"
#include "lldp_message_parse.h"
#include "topology.h"
#include "multi_ap.h"
#include "eloop.h"
#include "ethernet_layer.h"
#include "lldp.h"
#include "cmdu_tlv.h"
#ifdef MAP_R3
#include "security_engine.h"
#include "wpa_extern.h"
#endif

static unsigned char p1905_multicast_address[6]
	= { 0x01, 0x80, 0xc2, 0x00, 0x00, 0x13 };
static unsigned char nearest_bridge_group_address[6]
                    = { 0x01, 0x80, 0xc2, 0x00, 0x00, 0x0e };


struct _find_leaf {
	unsigned char al_mac[ETH_ALEN];
	unsigned char find_result;
};

char gw_agent_almac[ETH_ALEN];

struct leaf *create_leaf(unsigned char *al_mac)
{
	struct leaf *node = NULL;

	node = (struct leaf*)os_malloc(sizeof(struct leaf));
	if (!node) {
		debug(DEBUG_ERROR, "allocate leaf memory fail for ("MACSTR")\n",
			PRINT_MAC(al_mac));
		return NULL;
	}

	dl_list_init(&node->children);
	os_memcpy(node->al_mac, al_mac, ETH_ALEN);
	os_get_time(&node->create_time);
	node->renew_send_round = 0;
	return node;
}


void free_leaf(struct p1905_managerd_ctx *ctx, struct leaf *del_leaf)
{
	struct agent_list_db *agent_info = NULL;
#ifdef MAP_R3
	unsigned int wait_time = 30;
	struct r3_member *peer = NULL;

	if (ctx->MAP_Cer) {
		wait_time = 300;
		/* don't reset tx/rx counter in turnkey
		** tx rx counter may mismatch while plug in/out cable frequently
		*/
		ptk_peer_reset_encrypt_txrx_counter(del_leaf->al_mac);
	}
	peer = get_r3_member(del_leaf->al_mac);
	if (peer) {
		debug(DEBUG_ERROR, "del R3 sec info after %d sec\n", wait_time);
		eloop_cancel_timeout(timeout_delete_r3_member,
			(void *)ctx, (void *)peer);
		eloop_register_timeout(wait_time, 0,
			timeout_delete_r3_member, (void *)ctx, (void *)peer);
	}
#endif

	find_agent_info(ctx, del_leaf->al_mac, &agent_info);
	if (agent_info) {
		/*reset the band configured status of agent which leaves from current network*/
		debug(DEBUG_ERROR, TOPO_PREX"reset agent("MACSTR") config states\n",
			PRINT_MAC(agent_info->almac));
		clear_agent_all_radio_config_stat(agent_info);
	}
	dl_list_del(&del_leaf->entry);
	os_free(del_leaf);
}

struct topology_response_db *lookup_tprdb_by_almac(struct p1905_managerd_ctx *ctx, unsigned char *al_mac)
{
	struct topology_response_db *rpdb = NULL;

	SLIST_FOREACH(rpdb, &ctx->topology_entry.tprdb_head, tprdb_entry) {
		if (!os_memcmp(rpdb->al_mac_addr, al_mac, ETH_ALEN))
			break;
	}

	return rpdb;
}

unsigned char is_neighbor(struct topology_response_db *rpdb, unsigned char *al_mac)
{
	struct device_info_db *dev_info = NULL;
	struct p1905_neighbor_device_db *neighbor_db = NULL;

	SLIST_FOREACH(dev_info, &rpdb->devinfo_head, devinfo_entry) {
		SLIST_FOREACH(neighbor_db, &dev_info->p1905_nbrdb_head, p1905_nbrdb_entry) {
			if (!os_memcmp(neighbor_db->p1905_neighbor_al_mac, al_mac, ETH_ALEN))
				return 1;
		}
	}

	return 0;
}

struct leaf *lookup_childleaf_by_almac(struct leaf *current_leaf, unsigned char *almac)
{
	struct leaf *child_leaf = NULL;
	unsigned char found = 0;

	dl_list_for_each(child_leaf, &current_leaf->children, struct leaf, entry) {
		if (!os_memcmp(child_leaf->al_mac, almac, ETH_ALEN)) {
			found = 1;
			break;
		}
	}
	if (found == 0)
		child_leaf = NULL;

	return child_leaf;
}

void find_leaf_handler(void *context, void* parent_leaf, void *current_leaf, void *data)
{
	struct leaf *cur_leaf = (struct leaf *)current_leaf;
	struct _find_leaf *find_data = (struct _find_leaf *)data;

	if (find_data->find_result == 1)
		return;

	if (!os_memcmp(cur_leaf->al_mac, find_data->al_mac, ETH_ALEN))
		find_data->find_result = 1;
}

unsigned char is_leaf_exist(struct p1905_managerd_ctx * ctx, struct leaf *current_leaf, unsigned char *almac)
{
	struct _find_leaf find;

	os_memset(&find, 0, sizeof(struct _find_leaf));
	os_memcpy(find.al_mac, almac, ETH_ALEN);

	trace_topology_tree_cb(ctx, current_leaf, (topology_tree_cb_func)find_leaf_handler, (void*)&find);
	return find.find_result;
}

unsigned char build_tree_from_current_leaf(struct p1905_managerd_ctx *ctx, struct topology_response_db *current_rsp, struct leaf *current_leaf, struct leaf *parent_leaf)
{
	struct device_info_db *dev_info = NULL;
	struct p1905_neighbor_device_db *neighbor_db = NULL;
	struct topology_response_db *child_rpdb = NULL;
	struct leaf *child_leaf = NULL;

	SLIST_FOREACH(dev_info, &current_rsp->devinfo_head, devinfo_entry) {
		SLIST_FOREACH(neighbor_db, &dev_info->p1905_nbrdb_head, p1905_nbrdb_entry) {
			/*1. if neighbor exist in topology response db
			   2. if neighbor's 1905 neighbor tlv match the current devices's al mac and no leaf exist in current node
			       then create the child leaf
			   2.5 check whether this leaf exist, if yes, do not add this one until the exist one has deleted
			   3. and from this new/existed child leaf, buld all its child leaves*/
			child_rpdb = NULL;
			child_leaf = NULL;
			/*skip the parent leaf*/
			if (!os_memcmp(neighbor_db->p1905_neighbor_al_mac, parent_leaf->al_mac, ETH_ALEN))
				continue;
			/*1.*/
			child_rpdb = lookup_tprdb_by_almac(ctx, neighbor_db->p1905_neighbor_al_mac);
			if (!child_rpdb) {
				debug(DEBUG_TRACE, TOPO_PREX"almac("MACSTR") not exist in my topology rsp db\n",
					PRINT_MAC(neighbor_db->p1905_neighbor_al_mac));
				continue;
			}

			/*2.*/
			if (!is_neighbor(child_rpdb, current_leaf->al_mac)) {
				debug(DEBUG_TRACE, TOPO_PREX"child dev("MACSTR") is not a neighbor of dev("MACSTR")\n",
					PRINT_MAC(child_rpdb->al_mac_addr),
					PRINT_MAC(current_leaf->al_mac));
				continue;
			}

			child_leaf = lookup_childleaf_by_almac(current_leaf, child_rpdb->al_mac_addr);
			if (!child_leaf) {
				/*2.5*/
				if (is_leaf_exist(ctx, ctx->root_leaf, child_rpdb->al_mac_addr)) {
					debug(DEBUG_TRACE, TOPO_PREX"current leaf("MACSTR") exist, do not create\n",
						PRINT_MAC( child_rpdb->al_mac_addr));
					continue;
				}

				child_leaf = create_leaf(child_rpdb->al_mac_addr);

				if(!child_leaf)
					continue;
				debug(DEBUG_ERROR, TOPO_PREX"leaf add!current(%p)("MACSTR")----->child(%p)("MACSTR")\n",
					current_leaf, PRINT_MAC(current_leaf->al_mac),
					child_leaf, PRINT_MAC(child_leaf->al_mac));
				dl_list_add(&current_leaf->children, &child_leaf->entry);
			}

			/*3.*/
			build_tree_from_current_leaf(ctx, child_rpdb, child_leaf, current_leaf);
		}
	}

	return 0;
}

int delete_tree_from_current_leaf(struct p1905_managerd_ctx *ctx, struct leaf *current_leaf)
{
	struct leaf *child_leaf = NULL, *child_leaf_next = NULL;

	if (!current_leaf)
		return 0;

	dl_list_for_each_safe(child_leaf, child_leaf_next, &current_leaf->children, struct leaf, entry) {
		debug(DEBUG_ERROR, TOPO_PREX"leaf delete from current(%p)("MACSTR")\n",
				child_leaf, PRINT_MAC(child_leaf->al_mac));
		delete_tree_from_current_leaf(ctx, child_leaf);

		free_leaf(ctx, child_leaf);
	}

	return 0;
}

int detect_deleted_leaf_from_current_leaf(struct p1905_managerd_ctx *ctx, struct leaf *current_leaf)
{
	struct leaf *child_leaf = NULL, *child_leaf_next = NULL;
	struct topology_response_db *current_rsp = NULL, *child_rpdb = NULL;

	current_rsp = lookup_tprdb_by_almac(ctx, current_leaf->al_mac);

	if (!current_rsp) {
		debug(DEBUG_ERROR, TOPO_PREX"BUG here!!!current leaf ("MACSTR") not exist in my tpr db\n",
			PRINT_MAC(current_leaf->al_mac));
		return -1;
	}

	dl_list_for_each_safe(child_leaf, child_leaf_next, &current_leaf->children, struct leaf, entry) {
		child_rpdb = lookup_tprdb_by_almac(ctx, child_leaf->al_mac);
		/*maybe this condition should be add more, like check neighbor of child rsp db to see if it is current device*/
		if (child_rpdb && is_neighbor(current_rsp, child_leaf->al_mac)) {
			detect_deleted_leaf_from_current_leaf(ctx, child_leaf);
		} else {
			/*if child leaf is not my neighbor, should delete this child leaf and all its children leaves of this child leaf*/
			debug(DEBUG_ERROR, TOPO_PREX"leaf delete from current(%p)("MACSTR")\n",
				child_leaf, PRINT_MAC(child_leaf->al_mac));
			delete_tree_from_current_leaf(ctx, child_leaf);
			free_leaf(ctx, child_leaf);
		}
	}

	return 0;
}

/*init the root leaf of the tree, the root leaf always should represent current device*/
int create_topology_tree(struct p1905_managerd_ctx* ctx)
{
	struct leaf *root_leaf = NULL;

	if (ctx->root_leaf) {
		debug(DEBUG_ERROR, "root leaf already exist\n");
		goto fail;
	}

	root_leaf = create_leaf(ctx->p1905_al_mac_addr);
	if (!root_leaf)
		goto fail;

	ctx->root_leaf = root_leaf;
	return 0;
fail:
	return -1;
}

int update_topology_tree(struct p1905_managerd_ctx* ctx)
{
	struct p1905_neighbor_info *neighor_info = NULL;
	struct topology_response_db *child_rpdb = NULL;
	struct leaf *child_leaf = NULL, *child_leaf_next = NULL;
	int i = 0;
	unsigned char found = 0;

	if (!ctx->root_leaf) {
		debug(DEBUG_ERROR, TOPO_PREX"root leaf not exist, could not update topology tree\n");
		goto fail;
	}

	for (i = 0; i < ctx->itf_number; i++) {
		/*check the leaves that should be added to topology tree*/
		LIST_FOREACH(neighor_info, &ctx->p1905_neighbor_dev[i].p1905nbr_head, p1905nbr_entry) {
			child_rpdb = NULL;
			child_leaf = NULL;
			/*1. if neighbor exist in topology response db
			   2. if neighbor's 1905 neighbor tlv match the current devices's al mac and no leaf exist in current node
			       then create the child leaf
			   2.5 check whether this leaf exist, if yes, do not add this one until the exist one has deleted
			   3. and from this new/existed child leaf, rebuld its child leaves*/
			/*1.*/
			child_rpdb = lookup_tprdb_by_almac(ctx, neighor_info->al_mac_addr);
			if (!child_rpdb) {
				debug(DEBUG_TRACE, TOPO_PREX"neighbor dev("MACSTR") not exist in my topology rsp db\n",
					PRINT_MAC(neighor_info->al_mac_addr));
				continue;
			}

			/*2.*/
			if (!is_neighbor(child_rpdb, ctx->root_leaf->al_mac)) {
				debug(DEBUG_TRACE, TOPO_PREX"neighbor dev("MACSTR") has no neighbor of me\n",
					PRINT_MAC(child_rpdb->al_mac_addr));
				continue;
			}

			child_leaf = lookup_childleaf_by_almac(ctx->root_leaf, neighor_info->al_mac_addr);
			if (!child_leaf) {
				/*2.5*/
				if (is_leaf_exist(ctx, ctx->root_leaf, neighor_info->al_mac_addr)) {
					debug(DEBUG_TRACE, TOPO_PREX"current leaf("MACSTR") exist, do not create!\n",
						PRINT_MAC(neighor_info->al_mac_addr));
					continue;
				}

				child_leaf = create_leaf(neighor_info->al_mac_addr);
				if (!child_leaf)
					continue;
				debug(DEBUG_ERROR, TOPO_PREX"leaf add! root(%p)("MACSTR")----->child(%p)("MACSTR")\n",
					ctx->root_leaf, PRINT_MAC(ctx->root_leaf->al_mac),
					child_leaf, PRINT_MAC(child_leaf->al_mac));
				dl_list_add(&ctx->root_leaf->children, &child_leaf->entry);
			}
			/*3.*/
			build_tree_from_current_leaf(ctx, child_rpdb, child_leaf, ctx->root_leaf);
		}
	}

	/*check the leaves that should be deleted from topology tree*/
	dl_list_for_each_safe(child_leaf, child_leaf_next, &ctx->root_leaf->children, struct leaf, entry) {
		found = 0;
		for (i = 0; i < ctx->itf_number; i++) {
			LIST_FOREACH(neighor_info, &ctx->p1905_neighbor_dev[i].p1905nbr_head, p1905nbr_entry) {
				if (!os_memcmp(child_leaf->al_mac, neighor_info->al_mac_addr, ETH_ALEN)) {
					found = 1;
					break;
				}
			}
			if (found)
				break;
		}

		child_rpdb = lookup_tprdb_by_almac(ctx, child_leaf->al_mac);

		if (!found || !child_rpdb) {
			debug(DEBUG_ERROR, TOPO_PREX"leaf delete from current(%p)("MACSTR")\n",
				child_leaf, PRINT_MAC(child_leaf->al_mac));
			delete_tree_from_current_leaf(ctx, child_leaf);
			free_leaf(ctx, child_leaf);
		} else {
			detect_deleted_leaf_from_current_leaf(ctx, child_leaf);
		}
	}

	return 0;
fail:
	return -1;
}

int clear_topology_tree(struct p1905_managerd_ctx* ctx)
{
	delete_tree_from_current_leaf(ctx, ctx->root_leaf);
	os_free(ctx->root_leaf);
	ctx->root_leaf = NULL;

	return 0;
}

int trace_topology_tree_cb(struct p1905_managerd_ctx* ctx, struct leaf *current_leaf, topology_tree_cb_func cb, void *data)
{
	struct leaf *child_leaf = NULL, *child_leaf_next = NULL;

	if (!current_leaf)
		return 0;

	dl_list_for_each_safe(child_leaf, child_leaf_next, &current_leaf->children, struct leaf, entry) {
		cb((void*)ctx, (void*)current_leaf, (void*)child_leaf, data);
		trace_topology_tree_cb(ctx, child_leaf, cb, data);
	}

	return 0;
}

int topology_tree_travel_preorder(struct p1905_managerd_ctx* ctx, struct leaf *current_leaf)
{
	struct leaf *child_leaf = NULL, *child_leaf_next = NULL;
	leaf_info leaf_in;
	struct agent_list_db *agent_info = NULL;

	if (!current_leaf)
		return 0;

	os_memset(&leaf_in, 0, sizeof(leaf_in));

	/*push to stack*/
	debug(DEBUG_OFF, "push to stack:("MACSTR")\n",
		PRINT_MAC(current_leaf->al_mac));
	os_memcpy(leaf_in.al_mac, current_leaf->al_mac, ETH_ALEN);
#ifdef MAP_R3
		struct r3_member *peer = NULL;
		dl_list_for_each(peer, &r3_member_head, struct r3_member, entry) {
			if (!os_memcmp(peer->al_mac, current_leaf->al_mac, ETH_ALEN)) {
				if (peer->security_1905) {
					leaf_in.profile = MAP_PROFILE_R3;
					debug(DEBUG_OFF, "it's a r3 device\n");
				}
			}
		}
#endif
	if (os_memcmp(current_leaf->al_mac, ctx->p1905_al_mac_addr, ETH_ALEN)) {
		find_agent_info(ctx, current_leaf->al_mac, &agent_info);
		if (agent_info)
			clear_agent_all_radio_config_stat(agent_info);
	}
	push(&ctx->topo_stack, leaf_in);

	dl_list_for_each_safe(child_leaf, child_leaf_next, &current_leaf->children, struct leaf, entry) {
		topology_tree_travel_preorder(ctx, child_leaf);
	}

	return 0;
}

/*this is for GPON feature*/
void detect_neighbor_existence(struct p1905_managerd_ctx *ctx,
	unsigned char *neth_almac, unsigned char *sta_mac)
{
	struct topology_discovery_db *tpg_db = NULL;
	struct neighbor_list_db *ndb = NULL;
	unsigned int i = 0, j = 0;
	unsigned char remote_almac[ETH_ALEN] = {0};
	unsigned char zero_mac[ETH_ALEN] = {0};
	unsigned char meida = 0;

	if (neth_almac) {
		os_memcpy(remote_almac, neth_almac, ETH_ALEN);
		meida = 0;
	} else if (sta_mac) {
		find_neighbor_almac_by_intf_mac(ctx, sta_mac, remote_almac);
		meida = 1;
	} else {
		debug(DEBUG_ERROR, TOPO_PREX"unhandle event\n");
		return;
	}

	if (!os_memcmp(remote_almac, zero_mac, ETH_ALEN))
		return;

	tpg_db = find_discovery_by_almac(ctx, remote_almac);
	if (tpg_db && (tpg_db->mtk_tpd == 0)) {
		debug(DEBUG_ERROR, TOPO_PREX"Skip non MTK neighbor("MACSTR")\n",
			PRINT_MAC(remote_almac));
		return;
	}

	debug(DEBUG_OFF, TOPO_PREX"detect %s neighbor("MACSTR")\n",
		(meida ? "wifi" : "eth"), PRINT_MAC(remote_almac));

	LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry) {
		if (os_memcmp(tpg_db->al_mac, remote_almac, ETH_ALEN))
			continue;
		SLIST_FOREACH(ndb, &ctx->query_neighbor_head, neighbor_entry) {
			if (!os_memcmp(tpg_db->al_mac, ndb->nalmac, ETH_ALEN) &&
				!os_memcmp(tpg_db->itf_mac, ndb->nitf_mac, ETH_ALEN))
				break;
		}
		if (ndb)
			continue;
		ndb = (struct neighbor_list_db *)malloc(sizeof(struct neighbor_list_db));
		if (ndb == NULL) {
			debug(DEBUG_ERROR, TOPO_PREX"allocate neighbor_list_db fail\n");
			return;
		}
	    os_memcpy(ndb->nalmac, tpg_db->al_mac, ETH_ALEN);
		os_memcpy(ndb->nitf_mac, tpg_db->itf_mac, ETH_ALEN);
	    SLIST_INSERT_HEAD(&ctx->query_neighbor_head, ndb, neighbor_entry);
		for(i = 0; i < ctx->itf_number; i++) {
			if (os_memcmp(tpg_db->receive_itf_mac, ctx->itf[i].mac_addr, ETH_ALEN))
				continue;
			for(j = 0; j < 3; j++) {
				ctx->mid++;
				insert_cmdu_txq(p1905_multicast_address, ctx->p1905_al_mac_addr,
					e_topology_discovery_with_vendor_ie, ctx->mid, ctx->itf[i].if_name, 0);
			}
			debug(DEBUG_OFF, TOPO_PREX"tx discovery_with_vendor_ie(last_mid-(%04x) to "MACSTR" on %s",
				ctx->mid - 1, PRINT_MAC(remote_almac), ctx->itf[i].if_name);
			eloop_register_timeout(DETECT_NEIGHBOR_TIME, 0, recv_neighbor_disc_timeout,
				(void *)ctx, (void *)ndb);
			break;
		}
	}
}

/**
 *  delete all non-1905.1 neighbor device.
 *
 * \param  non_p1905_dev  pointer of non_1905.1 database
 * \param  retun error code
 */
void delete_non_p1905_neighbor_dev_info(struct non_p1905_neighbor *non_p1905_dev)
{
    int i = 0;
    struct non_p1905_neighbor_info *dev_info, *dev_info_temp;

    for(i=0;i<ITF_NUM;i++)
    {
        if(!LIST_EMPTY(&(non_p1905_dev[i].non_p1905nbr_head)))
        {
            dev_info = LIST_FIRST(&(non_p1905_dev[i].non_p1905nbr_head));
            while(dev_info)
            {
                dev_info_temp = LIST_NEXT(dev_info, non_p1905nbr_entry);
                LIST_REMOVE(dev_info, non_p1905nbr_entry);
                free(dev_info);
                dev_info = dev_info_temp;
            }
        }
    }
}

void recv_neighbor_disc_timeout(void *eloop_data, void *user_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_data;
	struct neighbor_list_db *ndb = (struct neighbor_list_db *)user_ctx;
	struct topology_discovery_db *tpg_db = NULL, *tpg_db_tmp = NULL;
	struct topology_response_db *tpgr_db = NULL;
	unsigned char del_rsp_cnt = 0;
	int cotroller = 0, i = 0;

	tpg_db = LIST_FIRST(&ctx->topology_entry.tpddb_head);
	while (tpg_db) {
		tpg_db_tmp = LIST_NEXT(tpg_db, tpddb_entry);
		if (!os_memcmp(tpg_db->al_mac, ndb->nalmac, ETH_ALEN) &&
			!os_memcmp(tpg_db->itf_mac, ndb->nitf_mac, ETH_ALEN)) {
			LIST_REMOVE(tpg_db, tpddb_entry);
			debug(DEBUG_OFF, RED("del neighbor("MACSTR")"
				" itf("MACSTR")\n"),
				PRINT_MAC(tpg_db->al_mac), PRINT_MAC(tpg_db->itf_mac));
			delete_p1905_neighbor_dev_info(ctx, tpg_db->al_mac,
				(unsigned char *)tpg_db->receive_itf_mac);
			if (find_discovery_by_almac(ctx, tpg_db->al_mac) == NULL) {
				debug(DEBUG_OFF, "delete topology rsp ("MACSTR")\n",
					PRINT_MAC(tpg_db->al_mac));
				/*topo C--ETH--A1--ETH--A2
				*reboot A1; during A1 get start, A2 will get C topology discovery by ETH
				*PON with MAP logic will run and drop A1 discovery
				*Add this logic to solve the issue mentioned above
				*/
				tpgr_db = find_topology_rsp_by_almac(ctx, tpg_db->al_mac);
				if (tpgr_db) {
					for (i = 0; i < tpgr_db->support_service_cnt; i++) {
						if (tpgr_db->support_service[i] == 0) {
						cotroller = 1;
						break;
					}
					}
					if (cotroller)
					{
						if (ctx->conn_port.is_set) {
							ctx->conn_port.is_set = 0;
							debug(DEBUG_OFF, RED("clear conn_port=%d\n"), ctx->conn_port.port_num);
						}
					}
					delete_exist_topology_response_database(ctx, tpg_db->al_mac);
					del_rsp_cnt++;
				}
			}
			os_free(tpg_db);
		}
		tpg_db = tpg_db_tmp;
	}

	report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
		ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
       	ctx->service, &ctx->ap_cap_entry.oper_bss_head,
        &ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);

	if (del_rsp_cnt)
		mark_valid_topo_rsp_node(ctx);

	SLIST_REMOVE(&ctx->query_neighbor_head, ndb, neighbor_list_db, neighbor_entry);
	os_free(ndb);
}

void check_neighbor_discovery(struct p1905_managerd_ctx *ctx,
	unsigned char *al_mac, unsigned char *itf_mac)
{
	struct neighbor_list_db *ndb = NULL;
	int ret = 0;

	SLIST_FOREACH(ndb, &ctx->query_neighbor_head, neighbor_entry) {
		if (!os_memcmp(ndb->nalmac, al_mac, ETH_ALEN) &&
			!os_memcmp(ndb->nitf_mac, itf_mac, ETH_ALEN)) {
			break;
		}
	}
	if (!ndb)
		return;

	ret= eloop_is_timeout_registered(recv_neighbor_disc_timeout, ctx, ndb);
	if (ret) {
		debug(DEBUG_ERROR, TOPO_PREX"[neighbor detect]receive discovery("MACSTR") "
			"peer intf("MACSTR")\n",
			PRINT_MAC(al_mac),
			PRINT_MAC(itf_mac));
		eloop_cancel_timeout(recv_neighbor_disc_timeout, ctx, ndb);
		SLIST_REMOVE(&ctx->query_neighbor_head, ndb, neighbor_list_db, neighbor_entry);
		os_free(ndb);
	}
}

void topology_discovery_action(struct p1905_managerd_ctx *ctx, unsigned char *peer_al_mac,
			       unsigned char need_query, unsigned char need_notify)
{
	unsigned int j = 0;

	if (need_query) {
		insert_cmdu_txq(peer_al_mac, ctx->p1905_al_mac_addr, e_topology_query, ++ctx->mid,
				ctx->itf[ctx->recent_cmdu_rx_if_number].if_name, 0);
		debug(DEBUG_ERROR, TOPO_PREX "tx query(mid-%04x) on intf(%s) to " MACSTR "\n",
		      ctx->mid, ctx->itf[ctx->recent_cmdu_rx_if_number].if_name, PRINT_MAC(peer_al_mac));
	}
	if (need_notify == 1) {
		ctx->mid++;
		debug(DEBUG_ERROR, TOPO_PREX "tx multicast notification(mid-%04x) on all intf\n", ctx->mid);
		for (j = 0; j < ctx->itf_number; j++) {
			/*send multicast cmdu to all the interface */
			insert_cmdu_txq((unsigned char *)p1905_multicast_address, ctx->p1905_al_mac_addr,
					e_topology_notification, ctx->mid, ctx->itf[j].if_name, 0);
#ifdef SUPPORT_CMDU_RELIABLE
			cmdu_reliable_send(ctx, e_topology_notification, ctx->mid, j);
#endif
		}
	} else if (need_notify == 2) {
		ctx->mid++;
		if (fill_send_tlv(ctx, peer_al_mac, ETH_ALEN) == -1)
			debug(DEBUG_ERROR, "[%d]fill_send_tlv fail!\n", __LINE__);

		debug(DEBUG_ERROR, TOPO_PREX "tx multicast notification(with vendor tlv)(mid-%04x) on all intf\n",
		      ctx->mid);
		for (j = 0; j < ctx->itf_number; j++) {
			/*send multicast cmdu to all the interface */
			insert_cmdu_txq((unsigned char *)p1905_multicast_address,
					ctx->p1905_al_mac_addr,
					e_topology_notification_with_vendor_ie, ctx->mid, ctx->itf[j].if_name, 0);
#ifdef SUPPORT_CMDU_RELIABLE
			cmdu_reliable_send(ctx, e_topology_notification_with_vendor_ie, ctx->mid, j);
#endif
		}
	}
}

/**
 *  add/update 1905.1 neighbor device information.
 *
 * \param  ctx  1905.1 managerd context
 * \param  al_mac  neighbor al mac addr in topology discovery message.
 * \param  neighbor_itf_mac  neighbor device interface mac in topology discover.
 * \param  itf_mac_addr  the interface topology discovery received from.
 * \param  notify  if need to send topology notify, set this flag
 * \param  retun error code
 */
int update_p1905_neighbor_dev_info(struct p1905_managerd_ctx *ctx,
				   unsigned char *al_mac, unsigned char *neighbor_itf_mac,
				   unsigned char *itf_mac_addr, unsigned char *notify)
{
	int i = 0;
	struct p1905_neighbor_info *dev_info = NULL;

	for (i = 0; i < ctx->itf_number; i++) {
		if (!memcmp(ctx->p1905_neighbor_dev[i].local_mac_addr, itf_mac_addr, ETH_ALEN))
			break;
	}

	if (i >= ctx->itf_number) {
		debug(DEBUG_ERROR, TOPO_PREX "no local interface with addr "MACSTR"\n", MAC2STR(itf_mac_addr));
		return -1;
	}

	if (!LIST_EMPTY(&ctx->p1905_neighbor_dev[i].p1905nbr_head)) {
		LIST_FOREACH(dev_info, &ctx->p1905_neighbor_dev[i].p1905nbr_head, p1905nbr_entry) {
			if (!memcmp(dev_info->al_mac_addr, al_mac, ETH_ALEN)) {
				if (dev_info->ieee802_1_bridge == 0) {
					/* can not find any matched mac address in LLDP storage
					 * it means that local device just receive the topology
					 * discovery but no 802.1 bridge detection message.
					 * so a 802.1 bridge exist
					 */
					if (find_lldp_by_port_id_mac(itf_mac_addr, neighbor_itf_mac) == 0) {
						dev_info->ieee802_1_bridge = 1;
						*notify = 1;
					}
				}
				return 0;
			}
		}
	}

	dev_info = (struct p1905_neighbor_info *)malloc(sizeof(struct p1905_neighbor_info));
	if (!dev_info) {
		debug(DEBUG_ERROR, TOPO_PREX "alloc dev_info fail\n");
		return -1;
	}
	memcpy(dev_info->al_mac_addr, al_mac, ETH_ALEN);
	dev_info->ieee802_1_bridge = 1;
	LIST_INSERT_HEAD(&ctx->p1905_neighbor_dev[i].p1905nbr_head, dev_info, p1905nbr_entry);
	debug(DEBUG_OFF, TOPO_PREX "local intf(%s) add 1905 neighbor(" MACSTR ")\n",
	      ctx->itf[i].if_name, PRINT_MAC(al_mac));
	/*need to send topology notification message */
	*notify = 1;

	return 0;
}

/**
 *  delete 1905.1 topology response database.
 *
 * \param  ctx  1905.1 managerd context
 * \param  al_mac  input the target device al mac to delete.
 */
void delete_exist_topology_response_database(struct p1905_managerd_ctx *ctx, unsigned char *al_mac)
{
	struct topology_response_db *tpgr_db;
	struct device_info_db *dev_info, *dev_info_temp;
	struct p1905_neighbor_device_db *p1905_neighbor, *p1905_neighbor_temp;
	struct non_p1905_neighbor_device_list_db *non_p1905_neighbor, *non_p1905_neighbor_temp;
	struct device_bridge_capability_db *br_cap, *br_cap_temp;

	if (!SLIST_EMPTY(&(ctx->topology_entry.tprdb_head))) {
		SLIST_FOREACH(tpgr_db, &(ctx->topology_entry.tprdb_head), tprdb_entry) {
			if (!memcmp(tpgr_db->al_mac_addr, al_mac, ETH_ALEN)) {
				if (!SLIST_EMPTY(&(tpgr_db->devinfo_head))) {
					dev_info = SLIST_FIRST(&(tpgr_db->devinfo_head));
					while (dev_info) {
						dev_info_temp = SLIST_NEXT(dev_info, devinfo_entry);
						if (!SLIST_EMPTY(&(dev_info->p1905_nbrdb_head))) {
							/*delete all p1905.1 device in this interface */
							p1905_neighbor = SLIST_FIRST(&(dev_info->p1905_nbrdb_head));
							while (p1905_neighbor) {
								p1905_neighbor_temp =
								    SLIST_NEXT(p1905_neighbor, p1905_nbrdb_entry);

								SLIST_REMOVE(&(dev_info->p1905_nbrdb_head),
									     p1905_neighbor, p1905_neighbor_device_db,
									     p1905_nbrdb_entry);
								free(p1905_neighbor);
								p1905_neighbor = p1905_neighbor_temp;
							}
						}

						/*delete all non-p1905.1 device in this interface */
						if (!SLIST_EMPTY(&(dev_info->non_p1905_nbrdb_head))) {
							non_p1905_neighbor =
							    SLIST_FIRST(&(dev_info->non_p1905_nbrdb_head));
							while (non_p1905_neighbor) {
								non_p1905_neighbor_temp =
								    SLIST_NEXT(non_p1905_neighbor,
									       non_p1905_nbrdb_entry);

								SLIST_REMOVE(&(dev_info->non_p1905_nbrdb_head),
									     non_p1905_neighbor,
									     non_p1905_neighbor_device_list_db,
									     non_p1905_nbrdb_entry);
								free(non_p1905_neighbor);
								non_p1905_neighbor = non_p1905_neighbor_temp;
							}
						}
						/*remove this device info db from list */
						SLIST_REMOVE(&(tpgr_db->devinfo_head), dev_info,
							     device_info_db, devinfo_entry);
						/*delete this device info db */
						if (dev_info->vs_info_len)
							free(dev_info->vs_info);

						free(dev_info);
						dev_info = dev_info_temp;
					}
				}

				/*delete bridge capability info */
				if (!LIST_EMPTY(&(tpgr_db->brcap_head))) {
					br_cap = LIST_FIRST(&(tpgr_db->brcap_head));
					while (br_cap) {
						br_cap_temp = LIST_NEXT(br_cap, brcap_entry);
						LIST_REMOVE(br_cap, brcap_entry);

						if (br_cap->interface_amount)
							free(br_cap->interface_mac_tuple);

						free(br_cap);
						br_cap = br_cap_temp;
					}
				}
				/*finall, delete whole topology response with this AL MAC */
				SLIST_REMOVE(&(ctx->topology_entry.tprdb_head), tpgr_db,
					     topology_response_db, tprdb_entry);
				free(tpgr_db);
				return;
			}
		}
	}
}

void update_bridge_cap(struct list_head_brcap *dst_br_head, struct list_head_brcap *src_br_head)
{
	struct device_bridge_capability_db *br = NULL;
	struct device_bridge_capability_db *br_temp = NULL;

	if (!dst_br_head || !src_br_head)
		return;
	if (LIST_EMPTY(src_br_head))
		return;

	br = LIST_FIRST(src_br_head);
	while (br) {
		br_temp = LIST_NEXT(br, brcap_entry);
		LIST_REMOVE(br, brcap_entry);
		LIST_INSERT_HEAD(dst_br_head, br, brcap_entry);
		br = br_temp;
	}
}

void update_dev_info(struct list_head_devinfo *dst_devinfo_head, struct list_head_devinfo *src_devinfo_head)
{
	struct device_info_db *dev = NULL;
	struct device_info_db *dev_tmp = NULL;

	if (!dst_devinfo_head || !src_devinfo_head)
		return;
	if (SLIST_EMPTY(src_devinfo_head))
		return;

	dev = SLIST_FIRST(src_devinfo_head);
	while (dev) {
		dev_tmp = SLIST_NEXT(dev, devinfo_entry);
		SLIST_REMOVE(src_devinfo_head, dev, device_info_db, devinfo_entry);
		SLIST_INSERT_HEAD(dst_devinfo_head, dev, devinfo_entry);
		debug(DEBUG_TRACE, "insert struct dev info db\n");
		debug(DEBUG_TRACE, "dev mac("MACSTR") media_type=%d\n", PRINT_MAC(dev->mac_addr), dev->media_type);
		dev = dev_tmp;
	}
}

struct topology_response_db *delete_exist_topology_response_content(struct p1905_managerd_ctx *ctx,
	unsigned char *al_mac)
{
	struct topology_response_db *tpgr_db = NULL;
	struct device_info_db *dev_info, *dev_info_temp;
	struct p1905_neighbor_device_db *p1905_neighbor, *p1905_neighbor_temp;
	struct non_p1905_neighbor_device_list_db *non_p1905_neighbor, *non_p1905_neighbor_temp;
	struct device_bridge_capability_db *br_cap, *br_cap_temp;

	SLIST_FOREACH(tpgr_db, &(ctx->topology_entry.tprdb_head), tprdb_entry) {
		if (os_memcmp(tpgr_db->al_mac_addr, al_mac, ETH_ALEN))
			continue;

		dev_info = SLIST_FIRST(&tpgr_db->devinfo_head);
		while (dev_info) {
			dev_info_temp = SLIST_NEXT(dev_info, devinfo_entry);
			/*delete all p1905.1 device in this interface */
			p1905_neighbor = SLIST_FIRST(&dev_info->p1905_nbrdb_head);
			while (p1905_neighbor) {
				p1905_neighbor_temp = SLIST_NEXT(p1905_neighbor, p1905_nbrdb_entry);
				SLIST_REMOVE(&dev_info->p1905_nbrdb_head,
					     p1905_neighbor, p1905_neighbor_device_db, p1905_nbrdb_entry);
				free(p1905_neighbor);
				p1905_neighbor = p1905_neighbor_temp;
			}
			/*delete all non-p1905.1 device in this interface */
			non_p1905_neighbor = SLIST_FIRST(&dev_info->non_p1905_nbrdb_head);
			while (non_p1905_neighbor) {
				non_p1905_neighbor_temp = SLIST_NEXT(non_p1905_neighbor, non_p1905_nbrdb_entry);
				SLIST_REMOVE(&dev_info->non_p1905_nbrdb_head,
					     non_p1905_neighbor, non_p1905_neighbor_device_list_db,
					     non_p1905_nbrdb_entry);
				free(non_p1905_neighbor);
				non_p1905_neighbor = non_p1905_neighbor_temp;
			}
			/*remove this device info db from list */
			SLIST_REMOVE(&tpgr_db->devinfo_head, dev_info, device_info_db, devinfo_entry);
			/*delete this device info db */
			if (dev_info->vs_info_len)
				free(dev_info->vs_info);

			free(dev_info);
			dev_info = dev_info_temp;
		}

		/*delete bridge capability info */
		br_cap = LIST_FIRST(&tpgr_db->brcap_head);
		while (br_cap) {
			br_cap_temp = LIST_NEXT(br_cap, brcap_entry);
			LIST_REMOVE(br_cap, brcap_entry);

			if (br_cap->interface_amount)
				free(br_cap->interface_mac_tuple);

			free(br_cap);
			br_cap = br_cap_temp;
		}
		return tpgr_db;
	}

	return tpgr_db;
}

void delete_exist_topology_discovery_database(struct p1905_managerd_ctx *ctx,
					      unsigned char *al_mac, unsigned char *itf_mac)
{
	struct topology_discovery_db *tpg_db = NULL;

	if (!LIST_EMPTY(&ctx->topology_entry.tpddb_head)) {
		LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry) {
			if (!memcmp(tpg_db->al_mac, al_mac, 6) && !memcmp(tpg_db->itf_mac, itf_mac, 6)) {
				delete_p1905_neighbor_dev_info(ctx, tpg_db->al_mac,
							       (unsigned char *)tpg_db->receive_itf_mac);
				/*delete the topology discovery database */
				LIST_REMOVE(tpg_db, tpddb_entry);
				free(tpg_db);
				return;
			}
		}
	}
}

/*
Fn to delete the topology rsp db by port by local interface mac address
	port == -1 delete by local interface mac address
	local_mac == NULL delete by port number index
*/
void delete_topo_response_db_by_port_interface(struct p1905_managerd_ctx *ctx, int port)
{
	struct topology_response_db *tpgr_db = NULL, *tpgr_db_tmp = NULL;
	unsigned char del_cnt = 0;

	if (port == -1) {
		debug(DEBUG_ERROR, TOPO_PREX "error port(-1)!!!\n");
		return;
	}

	tpgr_db = SLIST_FIRST(&ctx->topology_entry.tprdb_head);
	while (tpgr_db) {
		tpgr_db_tmp = SLIST_NEXT(tpgr_db, tprdb_entry);
		if (tpgr_db->eth_port == port) {
			delete_exist_topology_response_database(ctx, tpgr_db->al_mac_addr);
			del_cnt++;
		}
		tpgr_db = tpgr_db_tmp;
	}

	if (del_cnt)
		mark_valid_topo_rsp_node(ctx);
}

/*
Fn to delete the discovery db by port number or local interface mac address
	port == -1 delete by local interface mac address
	local_mac == NULL delete by port number index
*/
int delete_topo_disc_db_by_port(struct p1905_managerd_ctx *ctx, int port, unsigned char *exclude_almac)
{
	struct topology_discovery_db *db = NULL, *db_temp = NULL;
	int cnt = 0, del_rsp_cnt = 0;

	if (port == -1)
		return cnt;

	if (!LIST_EMPTY(&ctx->topology_entry.tpddb_head)) {
		db = LIST_FIRST(&ctx->topology_entry.tpddb_head);
		while (db) {
			db_temp = LIST_NEXT(db, tpddb_entry);
			if (db->eth_port == port) {
				if (exclude_almac && !os_memcmp(exclude_almac, db->al_mac, ETH_ALEN)) {
					db = db_temp;
					continue;
				}
				delete_p1905_neighbor_dev_info(ctx, db->al_mac, db->receive_itf_mac);
				LIST_REMOVE(db, tpddb_entry);
				cnt++;
				debug(DEBUG_ERROR,
				      TOPO_PREX "del discovery(" MACSTR ") peer intf(" MACSTR ") recv intf(" MACSTR
				      ") port(%d)\n", PRINT_MAC(db->al_mac), PRINT_MAC(db->itf_mac),
				      PRINT_MAC(db->receive_itf_mac), db->eth_port);
				if (find_discovery_by_almac(ctx, db->al_mac) == NULL) {
					debug(DEBUG_ERROR, TOPO_PREX "no discovery in db! del topology rsp\n");
					delete_exist_topology_response_database(ctx, db->al_mac);
					del_rsp_cnt++;
				}
				os_free(db);
			}
			db = db_temp;
		}
	}

	if (del_rsp_cnt)
		mark_valid_topo_rsp_node(ctx);

	return cnt;
}

/**
 *  delete one 1905.1 neighbor device.
 *
 * \param  ctx  1905.1 managerd context
 * \param  al_mac  input the neighbor device al mac to delete.
 * \param  retun error code
 */
int delete_p1905_neighbor_dev_info(struct p1905_managerd_ctx *ctx, unsigned char *al_mac, unsigned char *recvif_mac)
{
	int i = 0;
	struct p1905_neighbor_info *dev_info;
#ifdef MAP_R3
	struct r3_member *peer = NULL;
	unsigned int wait_time = 30;
#endif

	for (i = 0; i < ctx->itf_number; i++) {
		if (!memcmp(recvif_mac, ctx->itf[i].mac_addr, ETH_ALEN)) {
			LIST_FOREACH(dev_info, &ctx->p1905_neighbor_dev[i].p1905nbr_head, p1905nbr_entry) {
				if (!memcmp(dev_info->al_mac_addr, al_mac, ETH_ALEN)) {
					debug(DEBUG_ERROR, TOPO_PREX "del neighbor(" MACSTR ") on %s\n",
					      PRINT_MAC(al_mac), ctx->itf[i].if_name);
#ifdef MAP_R3
					if (ctx->MAP_Cer) {
						wait_time = 300;
						ptk_peer_reset_encrypt_txrx_counter(al_mac);
					}
					peer = get_r3_member(al_mac);
					if (peer) {
						debug(DEBUG_ERROR, "del R3 sec info after %d sec\n", wait_time);
						eloop_cancel_timeout(timeout_delete_r3_member,
							(void *)ctx, (void *)peer);
						eloop_register_timeout(wait_time, 0,
							timeout_delete_r3_member, (void *)ctx, (void *)peer);
					}
#endif
					LIST_REMOVE(dev_info, p1905nbr_entry);
					free(dev_info);
					return 1;
				}
			}
		}
	}

	return 0;
}

struct topology_discovery_db *get_tpd_db_by_mac(struct p1905_managerd_ctx *ctx, unsigned char *mac)
{
	struct topology_discovery_db *tpg_db = NULL;

	LIST_FOREACH(tpg_db, &(ctx->topology_entry.tpddb_head), tpddb_entry) {
		if (!os_memcmp(tpg_db->itf_mac, mac, ETH_ALEN)) {
			break;
		}
	}

	return tpg_db;
}

struct topology_response_db *get_trsp_db_by_mac(struct p1905_managerd_ctx *ctx, unsigned char *mac)
{
	struct topology_response_db *trsp_db = NULL;

	SLIST_FOREACH(trsp_db, &(ctx->topology_entry.tprdb_head), tprdb_entry) {
		if (!os_memcmp(trsp_db->al_mac_addr, mac, ETH_ALEN))
			break;
	}

	return trsp_db;
}

/**
 *  update the time to live for topology dicovery message.
 *  if value of time to live is less than 0, need to delete this record
 *
 *
 * \param  ctx  1905.1 managerd context
 * \param  sec  for 1905.1 managerd use.
 * \return error code
 */
int delete_not_exist_p1905_neighbor_device(struct p1905_managerd_ctx *ctx, int sec)
{
	struct topology_discovery_db *tpg_db, *tpg_db_temp;
	int result = 0;
	char del_rsp_cnt = 0;

	if (!LIST_EMPTY(&ctx->topology_entry.tpddb_head)) {
		tpg_db = LIST_FIRST(&ctx->topology_entry.tpddb_head);
		while (tpg_db) {
			tpg_db_temp = LIST_NEXT(tpg_db, tpddb_entry);
			tpg_db->time_to_live -= sec;
			if (tpg_db->time_to_live <= 0) {
				/*delete the local p1905.1 neighbor device info */
				debug(DEBUG_ERROR,
				      TOPO_PREX "timeout! del neighbor(" MACSTR ") peer tx intf(" MACSTR ") recv intf("
				      MACSTR ")\n", PRINT_MAC(tpg_db->al_mac), PRINT_MAC(tpg_db->itf_mac),
				      PRINT_MAC(tpg_db->receive_itf_mac));
				if (delete_p1905_neighbor_dev_info
				    (ctx, tpg_db->al_mac, (unsigned char *)tpg_db->receive_itf_mac))
					result = 1;
				/*delete the topology discovery database */
				LIST_REMOVE(tpg_db, tpddb_entry);
				if (find_discovery_by_almac(ctx, tpg_db->al_mac) == NULL) {
					debug(DEBUG_ERROR, TOPO_PREX "no discovery in db; del rsp\n");
					delete_exist_topology_response_database(ctx, tpg_db->al_mac);
					del_rsp_cnt++;
				}
				unmask_control_conn_port(ctx, tpg_db->eth_port);
				free(tpg_db);
			}
			tpg_db = tpg_db_temp;
		}
	}

	if (del_rsp_cnt)
		mark_valid_topo_rsp_node(ctx);

	return result;
}

void delete_not_exist_p1905_topology_device(struct p1905_managerd_ctx *ctx, int sec)
{
	struct topology_device_db *tpdev_db, *tpdev_db_temp;

	if (!SLIST_EMPTY(&ctx->topodev_entry.tpdevdb_head)) {
		tpdev_db = SLIST_FIRST(&ctx->topodev_entry.tpdevdb_head);
		while (tpdev_db) {
			tpdev_db_temp = SLIST_NEXT(tpdev_db, tpdev_entry);
			tpdev_db->time_to_live -= sec;
			if (tpdev_db->time_to_live <= 0) {
				SLIST_REMOVE(&ctx->topodev_entry.tpdevdb_head,
					     tpdev_db, topology_device_db, tpdev_entry);
				free(tpdev_db);
			}
			tpdev_db = tpdev_db_temp;
		}
	}
}

void query_neighbor_info(struct p1905_managerd_ctx *ctx, unsigned char *almac, unsigned int if_number)
{
	struct topology_response_db *tpgr = NULL, *tpgr_tmp = NULL;
	struct device_info_db *dev_info = NULL;
	struct p1905_neighbor_device_db *dev = NULL;
	unsigned char exist = 0;

	SLIST_FOREACH(tpgr, &ctx->topology_entry.tprdb_head, tprdb_entry) {
		if (!os_memcmp(tpgr->al_mac_addr, almac, 6))
			break;
	}

	if (!tpgr) {
		debug(DEBUG_ERROR, TOPO_PREX "something wrong!!! no 1905.1 dev " MACSTR "\n", PRINT_MAC(almac));
		return;
	}

	SLIST_FOREACH(dev_info, &tpgr->devinfo_head, devinfo_entry) {
		SLIST_FOREACH(dev, &dev_info->p1905_nbrdb_head, p1905_nbrdb_entry) {
			if (!os_memcmp(dev->p1905_neighbor_al_mac, ctx->p1905_al_mac_addr, ETH_ALEN))
				continue;

			exist = 0;
			SLIST_FOREACH(tpgr_tmp, &ctx->topology_entry.tprdb_head, tprdb_entry) {
				if (os_memcmp(tpgr_tmp->al_mac_addr, almac, ETH_ALEN)) {
					if (!os_memcmp(tpgr_tmp->al_mac_addr, dev->p1905_neighbor_al_mac, ETH_ALEN) &&
					    (tpgr_tmp->valid == 1)) {
						debug(DEBUG_INFO, TOPO_PREX "topo exist almac " MACSTR "\n",
						      PRINT_MAC(dev->p1905_neighbor_al_mac));
						exist = 1;
						break;
					}
				}
			}
			if (!exist) {
				insert_cmdu_txq(dev->p1905_neighbor_al_mac, ctx->p1905_al_mac_addr,
						e_topology_query, ++ctx->mid, ctx->itf[if_number].if_name, 0);
				debug(DEBUG_ERROR, TOPO_PREX "tx query(mid-%04x) to 1905.1 dev(" MACSTR ") on %s\n",
				      ctx->mid, PRINT_MAC(dev->p1905_neighbor_al_mac), ctx->itf[if_number].if_name);
			}
		}
	}
}

int insert_topology_discovery_database(struct p1905_managerd_ctx *ctx,
				       unsigned char *al_mac, unsigned char *itf_mac, unsigned char *recv_itf_mac)
{
	struct topology_discovery_db *tpg_db = NULL;

	LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry) {
		if (!os_memcmp(tpg_db->al_mac, al_mac, 6) && !os_memcmp(tpg_db->itf_mac, itf_mac, 6)) {
			return 0;
		}
	}

	if (!tpg_db) {
		tpg_db = (struct topology_discovery_db *)malloc(sizeof(struct topology_discovery_db));
		if (!tpg_db)
			return -1;
		os_memset(tpg_db, 0, sizeof(*tpg_db));
		os_memcpy(tpg_db->al_mac, al_mac, ETH_ALEN);
		os_memcpy(tpg_db->itf_mac, itf_mac, ETH_ALEN);
		os_memcpy(tpg_db->receive_itf_mac, recv_itf_mac, ETH_ALEN);
		tpg_db->time_to_live = TOPOLOGY_DISCOVERY_TTL;
		LIST_INSERT_HEAD(&ctx->topology_entry.tpddb_head, tpg_db, tpddb_entry);
		debug(DEBUG_ERROR,
		      TOPO_PREX "insert discovery db!!! al_mac(" MACSTR ") peer intf(" MACSTR ") recv intf(" MACSTR
		      ")\n", PRINT_MAC(al_mac), PRINT_MAC(itf_mac), PRINT_MAC(recv_itf_mac));
	}

	return 1;
}

struct topology_discovery_db *find_discovery_by_almac(struct p1905_managerd_ctx *ctx, unsigned char *al_mac)
{
	struct topology_discovery_db *tpg_db = NULL;

	LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry) {
		if (!os_memcmp(tpg_db->al_mac, al_mac, ETH_ALEN)) {
			return tpg_db;
		}
	}

	return tpg_db;
}

void find_neighbor_almac_by_intf_mac(struct p1905_managerd_ctx *ctx, unsigned char *itf_mac, unsigned char *almac)
{
	struct topology_discovery_db *tpg_db = NULL;
	struct topology_response_db *tpgr_db = NULL;
	struct device_info_db *dev_db = NULL;

	SLIST_FOREACH(tpgr_db, &ctx->topology_entry.tprdb_head, tprdb_entry) {
		SLIST_FOREACH(dev_db, &tpgr_db->devinfo_head, devinfo_entry) {
			if (!os_memcmp(dev_db->mac_addr, itf_mac, ETH_ALEN))
				break;
		}
		if (dev_db)
			break;
	}

	if (!tpgr_db) {
		debug(DEBUG_ERROR, "cannot find tpgr_db by itf_mac(" MACSTR ")\n", PRINT_MAC(itf_mac));
		return;
	}

	LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry) {
		if (!os_memcmp(tpg_db->al_mac, tpgr_db->al_mac_addr, ETH_ALEN)) {
			os_memcpy(almac, tpg_db->al_mac, ETH_ALEN);
			debug(DEBUG_OFF,
			      RED("neighbor(" MACSTR ") find based on sta(" MACSTR ")\n"),
			      PRINT_MAC(tpg_db->al_mac), PRINT_MAC(itf_mac));
			break;
		}
	}
}

struct topology_response_db *find_response_by_almac(struct p1905_managerd_ctx *ctx, unsigned char *al_mac)
{
	struct topology_response_db *tpgr_db = NULL;

	SLIST_FOREACH(tpgr_db, &ctx->topology_entry.tprdb_head, tprdb_entry) {
		if (!os_memcmp(tpgr_db->al_mac_addr, al_mac, ETH_ALEN)) {
			return tpgr_db;
		}
	}

	return tpgr_db;
}

int find_almac_by_connect_mac(struct p1905_managerd_ctx *ctx, unsigned char *mac, unsigned char *almac)
{
	struct topology_discovery_db *tpg_db = NULL;
	struct topology_response_db *tpgr_db = NULL;
	struct device_info_db *dev_info = NULL;

	LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry) {
		if (!os_memcmp(tpg_db->itf_mac, mac, ETH_ALEN)) {
			os_memcpy(almac, tpg_db->al_mac, ETH_ALEN);
			return 1;
		}
	}

	SLIST_FOREACH(tpgr_db, &ctx->topology_entry.tprdb_head, tprdb_entry) {
		SLIST_FOREACH(dev_info, &tpgr_db->devinfo_head, devinfo_entry) {
			if (!os_memcmp(dev_info->mac_addr, mac, ETH_ALEN)) {
				os_memcpy(almac, tpgr_db->al_mac_addr, ETH_ALEN);
				return 2;
			}
		}
	}

	return 0;
}

/*used for PON with MAP device feature
*need reform mesh topology to tree topology in agent side
*/
void mask_control_conn_port(struct p1905_managerd_ctx *ctx, struct topology_response_db *tpgr_db)
{
	struct topology_discovery_db *tpg_db = NULL;
	int rsp_port = 0, disc_port = 0;
	unsigned char role = AGENT;
	int i = 0;

	if (ctx->role == CONTROLLER || ctx->conn_port.is_set)
		return;

	for (i = 0; i < tpgr_db->support_service_cnt; i++) {
		if (tpgr_db->support_service[i] == 0) {
			role = CONTROLLER;
			break;
		}
	}
	rsp_port = tpgr_db->eth_port;

	if (role == CONTROLLER && rsp_port >= 0) {
		tpg_db = find_discovery_by_almac(ctx, tpgr_db->al_mac_addr);
		if (!tpg_db) {
			struct device_info_db *dev_info = NULL;
			struct p1905_neighbor_device_db *p1905_neighbor = NULL;
			struct topology_discovery_db *tpgd_child = NULL;

			/* Foreach controller neighor, find the neighbor which connect current dev with swtich,
			* mark it as controller_agent, make this eth port as controller port, clear related topo
			* info except the controller_agent. This marked eth port later just receive the discovery
			* from the controller_agent.
			*/
			debug(DEBUG_TRACE, TOPO_PREX "cannot find discovery from C, try to find its neighbor via port %d\n",
				rsp_port);

			SLIST_FOREACH(dev_info, &tpgr_db->devinfo_head, devinfo_entry) {
				SLIST_FOREACH(p1905_neighbor, &dev_info->p1905_nbrdb_head, p1905_nbrdb_entry) {
					tpgd_child = find_discovery_by_almac(ctx, p1905_neighbor->p1905_neighbor_al_mac);

					debug(DEBUG_TRACE, "controller(" MACSTR ") for neighbor (" MACSTR ")\n",
						PRINT_MAC(tpgr_db->al_mac_addr), PRINT_MAC(p1905_neighbor->p1905_neighbor_al_mac));
					if (tpgd_child && (tpgd_child->eth_port == rsp_port)) {

					   debug(DEBUG_TRACE, TOPO_PREX "find neighbor recv rsp & discovery from the same eth_port\n");
					   debug(DEBUG_OFF, TOPO_PREX "set neighbor conn_port=%d\n", rsp_port);
					   ctx->conn_port.is_set = 1;
					   ctx->conn_port.port_num = rsp_port;
					   os_memcpy(ctx->conn_port.filter_almac, tpgd_child->al_mac, ETH_ALEN);
					   delete_topo_disc_db_by_port(ctx, ctx->conn_port.port_num, ctx->conn_port.filter_almac);
					   return;
					}
				}
			}
			return;
		}
		disc_port = tpg_db->eth_port;
		if (disc_port == rsp_port) {
			/*receive response & discovery from same eth port, need mark this port
			 *as controller-connect port. need drop all agents' MC message.
			 */
			debug(DEBUG_TRACE, TOPO_PREX "recv rsp & discovery from the same eth_port=%d\n", rsp_port);
			/*check if need set controller-conncet port */
			debug(DEBUG_OFF, TOPO_PREX "set conn_port=%d\n", rsp_port);
			ctx->conn_port.is_set = 1;
			ctx->conn_port.port_num = rsp_port;
			os_memcpy(ctx->conn_port.filter_almac, tpgr_db->al_mac_addr, ETH_ALEN);
			/*delete existing neighbor info except for controller */
			delete_topo_disc_db_by_port(ctx, ctx->conn_port.port_num, ctx->conn_port.filter_almac);
		} else {
			debug(DEBUG_ERROR,
			      TOPO_PREX "port different!!! recv sp from port(%d) receive discovery from port(%d)\n",
			      rsp_port, disc_port);
		}
	}
}

void unmask_control_conn_port(struct p1905_managerd_ctx *ctx, int port)
{
	if (ctx->conn_port.is_set && (port == ctx->conn_port.port_num)) {
		ctx->conn_port.is_set = 0;
		debug(DEBUG_ERROR, TOPO_PREX "[GPON]clear conn_port(%d)\n", port);
	}
}

void report_own_topology_rsp(struct p1905_managerd_ctx *ctx,
	unsigned char *al_mac, struct bridge_capabiltiy *br_cap_list,
	struct p1905_neighbor *p1905_dev, struct non_p1905_neighbor *non_p1905_dev,
	unsigned char service, struct list_head_oper_bss *opbss_head,
    struct list_head_assoc_clients *asscli_head, unsigned int cnt)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;
	int i = 0;
	unsigned char separate = 0;

    length = append_device_info_type_tlv(tlv_temp_buf, al_mac, ctx);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    length = append_device_bridge_capability_type_tlv(tlv_temp_buf, br_cap_list);
    total_tlvs_length += length;
    tlv_temp_buf += length;

	for (i = 0; i < ctx->itf_number; i++) {
		do {
			length = append_p1905_neighbor_device_type_tlv(tlv_temp_buf, p1905_dev, i, &separate);
			total_tlvs_length += length;
			tlv_temp_buf += length;
		} while (separate);
	}

	separate = 0;
	/*append non-p1905.1 device tlv*/
	for (i = 0; i < ctx->itf_number; i++) {
		do {
			length = append_non_p1905_neighbor_device_type_tlv(tlv_temp_buf,
				non_p1905_dev, i, &separate);
			total_tlvs_length += length;
			tlv_temp_buf += length;
		} while (separate);
	}

	length = append_supported_service_tlv(tlv_temp_buf, service);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_operational_bss_tlv(ctx, tlv_temp_buf, opbss_head);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_associated_clients_tlv(tlv_temp_buf, asscli_head);
	total_tlvs_length += length;
	tlv_temp_buf += length;

#ifdef MAP_R4_SPT
	if (ctx->map_version >= DEV_TYPE_R3) {
		length = append_map_version_tlv(tlv_temp_buf, ctx->map_version);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}
#endif

#if MAP_R3
	if ((ctx->map_version == (unsigned char)MAP_PROFILE_R3)) {
		debug(DEBUG_TRACE, "append bss config report tlv\n");
		length = append_bss_config_report_tlv(tlv_temp_buf, ctx);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}
#endif // MAP_R3
#ifdef MAP_R6
	{
		struct assoc_client *client = NULL;

		for (i = 0; i < HASH_TABLE_SIZE; i++) {
			if (dl_list_empty(&ctx->clients_table[i]))
				continue;
			dl_list_for_each(client, &ctx->clients_table[i], struct assoc_client, entry) {
				if (dl_list_empty(&client->sta_mld.mlo_sta_list))
					continue;
				length = append_assoc_sta_mld_cfg_rpt_tlv(&client->sta_mld, tlv_temp_buf);
				total_tlvs_length += length;
				tlv_temp_buf += length;
			}
		}
	}
#endif


	if (total_tlvs_length > 10240) {
		debug(DEBUG_ERROR, "send length(%d) exceeds max revd_tlv len\n",
			total_tlvs_length);
		return;
	}
	reset_stored_tlv(ctx);
	store_revd_tlvs(ctx, ctx->tlv_buf.buf, total_tlvs_length);
	os_get_time(&ctx->own_topo_rsp_update_time);
	_1905_notify_topology_rsp_event(ctx, ctx->p1905_al_mac_addr, ctx->p1905_al_mac_addr);

}

void discovery_at_interface_link_up(void *eloop_data, void *user_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_data;
	unsigned char *if_name = (unsigned char *)user_ctx;
	static int i = 3, j = 10;

	/*send multicast cmdu to all the ethenet interface */
	insert_cmdu_txq(p1905_multicast_address, ctx->p1905_al_mac_addr,
		e_topology_discovery_with_vendor_ie, ++ctx->mid, if_name, 0);
	debug(DEBUG_ERROR, TOPO_PREX"tx multicast discovery(mid-%04x) with vs tlv on %s\n",
		ctx->mid, if_name);

	/*in certification mode, cover TB Mar* issue
	* send more discovery to it and wait for it response
	*/
	if (ctx->MAP_Cer) {
		j--;
		if (j == 0) {
			j = 10;
			return;
		}
		eloop_register_timeout(3, 0, discovery_at_interface_link_up, (void *)ctx, (void *)if_name);
	} else {
		i--;
		if (i == 0) {
			i = 3;
			return;
		}
		eloop_register_timeout(3, 0, discovery_at_interface_link_up, (void *)ctx, (void *)if_name);
	}

	return;
}

void mark_valid_topo_rsp_node(struct p1905_managerd_ctx *ctx)
{
    struct p1905_neighbor_info *p1905_neigbor = NULL;
    struct topology_response_db *tpgr = NULL;
	int i = 0;

	SLIST_FOREACH(tpgr, &ctx->topology_entry.tprdb_head, tprdb_entry) {
		debug(DEBUG_ERROR, TOPO_PREX"mark dev("MACSTR") invalid\n",
			PRINT_MAC(tpgr->al_mac_addr));
		tpgr->valid = 0;
	}

	for(i = 0; i < ctx->itf_number; i++) {
		LIST_FOREACH(p1905_neigbor, &(ctx->p1905_neighbor_dev[i].p1905nbr_head), p1905nbr_entry) {
			tpgr = find_topology_rsp_by_almac(ctx, p1905_neigbor->al_mac_addr);
			if (tpgr && !tpgr->valid) {
				tpgr->valid = 1;
				debug(DEBUG_ERROR, TOPO_PREX"mark dev("MACSTR") valid\n",
					PRINT_MAC(tpgr->al_mac_addr));
				update_topology_info(ctx, tpgr);
			}
		}
	}
}

void update_topology_info(
	struct p1905_managerd_ctx *ctx, struct topology_response_db *tpgr)
{
	struct device_info_db *dev_info = NULL;
	struct p1905_neighbor_device_db *p1905_neighbor = NULL;
    struct topology_response_db *tpgr_child = NULL;

	SLIST_FOREACH(dev_info, &tpgr->devinfo_head, devinfo_entry) {
		SLIST_FOREACH(p1905_neighbor, &dev_info->p1905_nbrdb_head, p1905_nbrdb_entry) {
			tpgr_child = find_topology_rsp_by_almac(ctx,
							p1905_neighbor->p1905_neighbor_al_mac);
			if (tpgr_child && !tpgr_child->valid) {
				tpgr_child->valid = 1;
				debug(DEBUG_ERROR, TOPO_PREX"mark dev("MACSTR") valid\n",
					PRINT_MAC(tpgr_child->al_mac_addr));
				update_topology_info(ctx, tpgr_child);
			}
		}
	}
}

struct topology_response_db *find_topology_rsp_by_almac(
	struct p1905_managerd_ctx *ctx, unsigned char *almac)
{
    struct topology_response_db *tpgr_db = NULL;

	SLIST_FOREACH(tpgr_db, &ctx->topology_entry.tprdb_head, tprdb_entry) {
		if (!os_memcmp(tpgr_db->al_mac_addr, almac, ETH_ALEN))
			return tpgr_db;
	}

	return tpgr_db;
}

int check_C_and_A_concurrent_by_topology_rsp(struct p1905_managerd_ctx *ctx, struct topology_response_db *tpgr_db)
{
	struct topology_discovery_db *ctpg_db = NULL, *atpg_db = NULL, *tpg_db = NULL;
	int controller = 0;
	int i = 0;

	for (i = 0; i < tpgr_db->support_service_cnt; i++) {
		if (tpgr_db->support_service[i] == 0)
			controller = 1;
	}
	if (controller) {
		ctpg_db = find_discovery_by_almac(ctx, tpgr_db->al_mac_addr);
		if (ctpg_db) {
			LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry)
			{
				if (!os_memcmp(ctpg_db->itf_mac, tpg_db->itf_mac, ETH_ALEN) &&
					os_memcmp(ctpg_db->al_mac, tpg_db->al_mac, ETH_ALEN)) {
					debug(DEBUG_ERROR, "BCM case!!! C("MACSTR") & A("MACSTR") almac different but same intf_mac("MACSTR")!!! del discovery("MACSTR")\n",
						MAC2STR(ctpg_db->al_mac), MAC2STR(tpg_db->al_mac),
						MAC2STR(tpg_db->itf_mac), MAC2STR(tpg_db->al_mac));
					delete_exist_topology_discovery_database(ctx, tpg_db->al_mac, tpg_db->itf_mac);
					delete_exist_topology_response_database(ctx, tpg_db->al_mac);
					/*report own topology rsp to update db in mapd*/
					report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
						ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
						ctx->service, &ctx->ap_cap_entry.oper_bss_head,
						&ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);
				}
			}
		}
	} else {
		atpg_db = find_discovery_by_almac(ctx, tpgr_db->al_mac_addr);
		if (atpg_db) {
			LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry)
			{
				if (!os_memcmp(atpg_db->itf_mac, tpg_db->itf_mac, ETH_ALEN) &&
					os_memcmp(atpg_db->al_mac, tpg_db->al_mac, ETH_ALEN)) {
					debug(DEBUG_ERROR, "BCM case!!! C("MACSTR") & A("MACSTR") almac different but same intf_mac("MACSTR")!!! del discovery("MACSTR")\n",
						MAC2STR(tpg_db->al_mac), MAC2STR(atpg_db->al_mac),
						MAC2STR(tpg_db->itf_mac), MAC2STR(atpg_db->al_mac));
					delete_exist_topology_discovery_database(ctx, atpg_db->al_mac, atpg_db->itf_mac);
					delete_exist_topology_response_database(ctx, atpg_db->al_mac);
					/*report own topology rsp to update db in mapd*/
					report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
						ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
						ctx->service, &ctx->ap_cap_entry.oper_bss_head,
						&ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);
					return -1;
				}
			}
		}
		if (!os_memcmp(tpgr_db->al_mac_addr, gw_agent_almac, ETH_ALEN)) {
			debug(DEBUG_ERROR, "BCM case!!! A("MACSTR") drop Topology Resp\n", MAC2STR(tpgr_db->al_mac_addr));
			return -1;
		}
	}

	return 0;
}

int check_C_and_A_concurrent_by_discovery(struct p1905_managerd_ctx *ctx, unsigned char *al_mac_addr, unsigned char *mac_addr)
{
	struct topology_response_db *tpgr_db = NULL, *ctpgr_db = NULL;
	struct device_info_db *dev_info = NULL;
	int controller = 0;
	int i = 0;

	SLIST_FOREACH(tpgr_db, &ctx->topology_entry.tprdb_head, tprdb_entry) {
		for (i = 0; i < tpgr_db->support_service_cnt; i++) {
			if (tpgr_db->support_service[i] == 0) {
				controller = 1;
				break;
			}
		}
		if (controller == 1) {
			ctpgr_db = tpgr_db;
			break;
		}
	}
	if (ctpgr_db == NULL)
		return 0;

	SLIST_FOREACH(dev_info, &ctpgr_db->devinfo_head, devinfo_entry) {
		if (!os_memcmp(dev_info->mac_addr, mac_addr, ETH_ALEN) &&
			os_memcmp(ctpgr_db->al_mac_addr, al_mac_addr, ETH_ALEN)) {
				debug(DEBUG_ERROR, "C("MACSTR") & A("MACSTR") almac different but same intf_mac("MACSTR") drop A\n",
					MAC2STR(ctpgr_db->al_mac_addr), MAC2STR(al_mac_addr),
					MAC2STR(mac_addr));
				/*Store Agent ALMAC of BCM Device*/
				os_memcpy(gw_agent_almac, al_mac_addr, ETH_ALEN);
				return -1;
		}
	}

	return 0;
}

unsigned char delete_non_p1905_neighbor_dev_info_byport(struct non_p1905_neighbor *non_p1905_dev, unsigned char port)
{
    int i = 0;
	unsigned char changed = 0;
    struct non_p1905_neighbor_info *dev_info, *dev_info_temp;

    for (i = 0; i < ITF_NUM; i++) {
        if (!LIST_EMPTY(&(non_p1905_dev->non_p1905nbr_head))) {
            dev_info = LIST_FIRST(&(non_p1905_dev->non_p1905nbr_head));
            while (dev_info) {
                dev_info_temp = LIST_NEXT(dev_info, non_p1905nbr_entry);
				if (dev_info->port_index == port) {
                	LIST_REMOVE(dev_info, non_p1905nbr_entry);
                	free(dev_info);
					changed = 1;
				}
                dev_info = dev_info_temp;
            }
        }
    }
	return changed;
}

unsigned char delete_non_p1905_neighbor_dev_info_bymac(struct non_p1905_neighbor *non_p1905_dev, unsigned char *mac)
{
    int i = 0;
	unsigned char changed = 0;
    struct non_p1905_neighbor_info *dev_info, *dev_info_temp;

    for (i = 0; i < ITF_NUM; i++) {
        if (!LIST_EMPTY(&(non_p1905_dev->non_p1905nbr_head))) {
            dev_info = LIST_FIRST(&(non_p1905_dev->non_p1905nbr_head));
            while (dev_info) {
                dev_info_temp = LIST_NEXT(dev_info, non_p1905nbr_entry);
				if (!os_memcmp(dev_info->itf_mac_addr, mac, ETH_ALEN)) {
                	LIST_REMOVE(dev_info, non_p1905nbr_entry);
                	free(dev_info);
					changed = 1;
				}
                dev_info = dev_info_temp;
            }
        }
    }
	return changed;
}

struct non_p1905_neighbor_info *get_non_p1905_neighbor_dev_info_bymac(struct non_p1905_neighbor *non_p1905_dev,
	unsigned char *mac, unsigned char port)
{
    struct non_p1905_neighbor_info *dev_info;

	LIST_FOREACH(dev_info, &(non_p1905_dev->non_p1905nbr_head), non_p1905nbr_entry) {
		if (!os_memcmp(dev_info->itf_mac_addr, mac, ETH_ALEN) && dev_info->port_index == port) {
			break;
		}
	}
    return dev_info;
}

unsigned int get_eth_itf_num(struct p1905_managerd_ctx *ctx)
{
	unsigned int i = 0, num_itf = 0;

	for (i = 0; i < ctx->itf_number; i++) {
		if (ctx->itf[i].media_type == IEEE802_3_GROUP)
			num_itf++;
	}

	debug(DEBUG_TRACE, TOPO_PREX"total lan interface num %d\n", num_itf);
	return num_itf;
}


unsigned char non_1905_neighbor_update_per_itf(struct p1905_managerd_ctx *ctx, unsigned int itf_id, unsigned int port)
{
	struct topology_discovery_db *discovery_db = NULL;
	struct topology_response_db *rsp_db = NULL;
	struct ethernet_client_entry *client_entry = NULL;
	struct non_p1905_neighbor *non_1905_neighbor_list = NULL;
	struct non_p1905_neighbor_info *info = NULL;
	unsigned char topo_changed = 0;
	struct ethernet_port *peth_data = NULL;
	struct non_p1905_neighbor_info *dev_info = NULL, *dev_info_temp = NULL;

	debug(DEBUG_TRACE, "itf idx %d %s, port %d\n", itf_id, ctx->itf[itf_id].if_name,  port);

	non_1905_neighbor_list = &ctx->non_p1905_neighbor_dev[itf_id];

	discovery_db = NULL;
	peth_data = eth_layer_get_eth_data_by_port_num(port);
	if (peth_data == NULL) {
		debug(DEBUG_ERROR, "peth_data null\n");
		goto RETURN;
	}

	if (ctx->role == CONTROLLER && peth_data->wan_port)
		goto RETURN;

	dl_list_for_each(client_entry, &peth_data->clients, struct ethernet_client_entry, entry) {
		discovery_db = get_tpd_db_by_mac(ctx, client_entry->mac);

		/*to check any 1905 device exist*/
		if (discovery_db != NULL) {
			/*delete all non-1905 neighbor device belongs to this port*/
			debug(DEBUG_TRACE, TOPO_PREX"delete all non 1905.1 neighbors for 1905 topology discovery on port %d\n",
				peth_data->port_index);
			topo_changed = delete_non_p1905_neighbor_dev_info_byport(non_1905_neighbor_list, peth_data->port_index);
			break;
		}
	}

	/*if no direct 1905 device found with current port*/
	if (discovery_db == NULL) {
		dl_list_for_each(client_entry, &peth_data->clients, struct ethernet_client_entry, entry) {
			rsp_db = get_trsp_db_by_mac(ctx, client_entry->mac);
			if (rsp_db != NULL) {
				debug(DEBUG_TRACE, "rsp_db != NULL\n");
				break;
			}
		}

		/*if this almac is found in topology response db, should not add it into non 1905 neighbor list*/
		if (rsp_db == NULL) {
			dl_list_for_each(client_entry, &peth_data->clients, struct ethernet_client_entry, entry) {
				debug(DEBUG_TRACE, "port %d client "MACSTR"\n",
					client_entry->port_index, MAC2STR(client_entry->mac));
				info = get_non_p1905_neighbor_dev_info_bymac(non_1905_neighbor_list,
					client_entry->mac, peth_data->port_index);
				if (info == NULL) {
					info = (struct non_p1905_neighbor_info *)os_malloc(sizeof(struct non_p1905_neighbor_info));
					if (info == NULL)
						continue;

					info->port_index = peth_data->port_index;
					os_memcpy(info->itf_mac_addr, client_entry->mac, ETH_ALEN);
					debug(DEBUG_TRACE, TOPO_PREX"insert non 1905.1 dev("MACSTR") on inf("MACSTR") port(%d)\n",
						PRINT_MAC(info->itf_mac_addr), PRINT_MAC(non_1905_neighbor_list->local_mac_addr),
						peth_data->port_index);
					LIST_INSERT_HEAD(&non_1905_neighbor_list->non_p1905nbr_head, info, non_p1905nbr_entry);
					topo_changed = 1;
				}
			}
		} else
			topo_changed = delete_non_p1905_neighbor_dev_info_bymac(non_1905_neighbor_list, rsp_db->al_mac_addr);

		/*delete the non 1905 neighbor from list by checking the switch port data list*/
		dev_info = LIST_FIRST(&(non_1905_neighbor_list->non_p1905nbr_head));
		while (dev_info) {
			dev_info_temp = LIST_NEXT(dev_info, non_p1905nbr_entry);
			if (dev_info->port_index == peth_data->port_index) {
				if (!eth_layer_get_client_by_mac(peth_data, dev_info->itf_mac_addr)) {
					LIST_REMOVE(dev_info, non_p1905nbr_entry);
					debug(DEBUG_TRACE, TOPO_PREX"delete non 1905.1 dev("MACSTR") on inf("MACSTR") port(%d)\n",
						PRINT_MAC(dev_info->itf_mac_addr), PRINT_MAC(non_1905_neighbor_list->local_mac_addr),
						dev_info->port_index);
					os_free(dev_info);
					topo_changed = 1;
				}
			}
			dev_info = dev_info_temp;
		}
	}

RETURN:

	return topo_changed;
}

void non_1905_neighbor_update(void *eloop_data, void *user_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)eloop_data;
	unsigned int i = 0, j = 0;
	unsigned char topo_changed = 0;
	unsigned int num_eth_itf = 0;

	num_eth_itf = get_eth_itf_num(ctx);

	if (eth_layer_port_client_update() < 0)
		return;

	for (j = 0; j < ctx->itf_number; j++) {
		if (ctx->itf[j].media_type != IEEE802_3_GROUP)
			continue;

		debug(DEBUG_TRACE, TOPO_PREX"itf idx %d, %s\n", j, ctx->itf[j].if_name);

		/* ext phy used as lan to be extended
		 * eagle:		eth1 <-> ext phy0
		 *				eth2 <-> ext phy8
		 * Panther:		eth1 <-> ext phy6
		 * Cheetah:		eth1 <-> inter phy0 or ext phy5
		 */
		if (strncmp((char *)ctx->itf[j].if_name, "eth2", IFNAMSIZ-1) == 0 ||
			strncmp((char *)ctx->itf[j].if_name, "eth1", IFNAMSIZ-1) == 0)
			continue;

		if (num_eth_itf > 2) {
			/* DSA: port id equal to lan itf id
			 * lan0 <-> port0
			 * lan1 <-> port1
			 * lan2 <-> port2
			 * lan3 <-> port3
			 */
			topo_changed |= non_1905_neighbor_update_per_itf(ctx, j, j);
		} else {
			/* GSW: lan = eth0 <-> port 0 1 2 3 */
			for (i = 0; i < MAX_LAN_PORT_NUM; i++)
				topo_changed |= non_1905_neighbor_update_per_itf(ctx, j, i);
		}
	}

	if (topo_changed) {
		report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
							ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
							ctx->service, &ctx->ap_cap_entry.oper_bss_head,
							&ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);
		ctx->mid++;
		debug(DEBUG_ERROR, TOPO_PREX"topo change! tx multicast notification(mid-%04x) on all intf\n", ctx->mid);
		for (j = 0; j < ctx->itf_number; j++) {
			/*send multicast cmdu to all the interface */
			insert_cmdu_txq(p1905_multicast_address, ctx->p1905_al_mac_addr,
				e_topology_notification, ctx->mid, ctx->itf[j].if_name, 0);
#ifdef SUPPORT_CMDU_RELIABLE
			cmdu_reliable_send(ctx, e_topology_notification, ctx->mid, j);
#endif
		}
	}

	eloop_register_timeout(SWITCH_TABLE_DUMP_TIME, 0, non_1905_neighbor_update, (void *)ctx, NULL);
}

void discovery_at_boot_up(void *eloop_data, void *user_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx*)eloop_data;
	static int i = DISC_RETRY_TIME;
	int j = 0;

	ctx->mid++;
	for (j = 0; j < ctx->itf_number; j++) {
		/*send multicast cmdu to all the ethenet interface */
		if (ctx->itf[j].media_type == IEEE802_3_GROUP) {
			insert_cmdu_txq(p1905_multicast_address, ctx->p1905_al_mac_addr,
				e_topology_discovery_with_vendor_ie, ctx->mid, ctx->itf[j].if_name, 0);
			debug(DEBUG_ERROR, TOPO_PREX"tx multicast discovery(mid-%04x) with vs tlv on %s\n",
				ctx->mid, ctx->itf[j].if_name);
		}
	}
	i--;

	if (i == 0) {
		i = DISC_RETRY_TIME;
		return;
	}

	eloop_register_timeout(3, 0, discovery_at_boot_up, (void *)ctx, NULL);

	return;
}

void check_topology_rsp_expired(struct p1905_managerd_ctx *ctx)
{
	struct os_time now;
	struct topology_response_db *rsp, *rsp_tmp = NULL;
	struct topology_discovery_db *disc = NULL, *disc_tmp = NULL;
	char query = 0, del = 0, del_rsp_cnt = 0;
	unsigned int i = 0;
	unsigned char *ifname = NULL;

	os_get_time(&now);

	/*fistly,  check whether it is necessary query all devices in topology response database*/
	disc = LIST_FIRST(&ctx->topology_entry.tpddb_head);
	while (disc) {
		query = 0;
		del = 0;
		disc_tmp = LIST_NEXT(disc, tpddb_entry);
		rsp = find_response_by_almac(ctx, disc->al_mac);
		if (rsp) {
			if ((now.sec - rsp->last_seen.sec) > NEIGHBOR_TOPOLOGY_EXPIRE_TIME) {
				del = 1;
			} else if ((now.sec - rsp->last_seen.sec) > NEIGHBOR_TOPOLOGY_QUERY_TIME) {
				query = 1;
			}
		} else {
			query = 1;
		}

		if (query) {
			/*get ifname by discovery*/
			for (i = 0; i < ctx->itf_number; i++) {
				if (!os_memcmp(ctx->itf[i].mac_addr, disc->receive_itf_mac, ETH_ALEN))
					break;
			}
			if (i < ctx->itf_number)
				ifname = ctx->itf[i].if_name;
			else
				ifname = ctx->br_name;
			insert_cmdu_txq(disc->al_mac, ctx->p1905_al_mac_addr,
					e_topology_query, ++ctx->mid, ifname, 0);
			debug(DEBUG_TRACE, TOPO_PREX"tx query(mid-%04x) to neighbor"MACSTR" on %s\n",
				ctx->mid, MAC2STR(disc->al_mac), ifname);
		}
		if (del) {
			debug(DEBUG_ERROR, TOPO_PREX"timeout!!! del neighbor("MACSTR")\n",
				PRINT_MAC(disc->al_mac));
			delete_p1905_neighbor_dev_info(ctx, disc->al_mac, disc->receive_itf_mac);
			report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
				ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
				ctx->service, &ctx->ap_cap_entry.oper_bss_head,
				&ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);
			LIST_REMOVE(disc, tpddb_entry);
			if (find_discovery_by_almac(ctx, disc->al_mac) == NULL) {
				delete_exist_topology_response_database(ctx, disc->al_mac);
				del_rsp_cnt++;
				debug(DEBUG_ERROR, TOPO_PREX"timeout!!! no discovery in db; del rsp("MACSTR")\n",
					PRINT_MAC(disc->al_mac));
			}
			unmask_control_conn_port(ctx, disc->eth_port);
			free(disc);
		}
		disc = disc_tmp;
	}

	rsp = SLIST_FIRST(&ctx->topology_entry.tprdb_head);
	while (rsp) {
		query = 0;
		del = 0;
		rsp_tmp = SLIST_NEXT(rsp, tprdb_entry);
		if (find_discovery_by_almac(ctx, rsp->al_mac_addr) == NULL) {
			if ((now.sec - rsp->last_seen.sec > TOPOLOGY_EXPIRE_TIME) &&
				(now.sec - rsp->last_seen.sec < TOPOLOGY_EXPIRE_DEL_TIME) ) {
				query = 1;
			} else if (now.sec - rsp->last_seen.sec > TOPOLOGY_EXPIRE_DEL_TIME) {
				del = 1;
			}
		}

		if (query) {
			ifname = ctx->itf[rsp->recv_ifid].if_name;
			insert_cmdu_txq(rsp->al_mac_addr, ctx->p1905_al_mac_addr,
					e_topology_query, ++ctx->mid, ifname, 0);
			debug(DEBUG_TRACE, TOPO_PREX"tx query(mid-%04x) to non neighbor dev("MACSTR") on %s\n",
				ctx->mid, PRINT_MAC(rsp->al_mac_addr), ifname);
		}
		if (del) {
			delete_exist_topology_response_database(ctx, rsp->al_mac_addr);
			debug(DEBUG_ERROR, TOPO_PREX"timeout!!! del non neighbor dev("MACSTR")\n", PRINT_MAC(rsp->al_mac_addr));
			del_rsp_cnt++;
		}
		rsp = rsp_tmp;
	}

	/*secondly, check whether it is necessary to update my own topology response*/
	if (now.sec - ctx->own_topo_rsp_update_time.sec > TOPOLOGY_EXPIRE_TIME) {
		debug(DEBUG_TRACE, TOPO_PREX"update my own topology rsp to mapd\n");
		report_own_topology_rsp(ctx, ctx->p1905_al_mac_addr, ctx->br_cap,
			ctx->p1905_neighbor_dev, ctx->non_p1905_neighbor_dev,
			ctx->service, &ctx->ap_cap_entry.oper_bss_head,
			&ctx->ap_cap_entry.assoc_clients_head, ctx->cnt);
	}

	if (del_rsp_cnt)
		mark_valid_topo_rsp_node(ctx);
}

void send_discovery_periodic(void *eloop_data, void *user_ctx)
{
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)eloop_data;
	int i = 0;
	struct buf_info *buf = &ctx->trx_buf;

	ctx->mid++;
	debug(DEBUG_TRACE, TOPO_PREX"periodically! tx multicast discovery(mid-%04x) on all intf\n",
		ctx->mid);
	for (i = 0; i < ctx->itf_number; i++)
		insert_cmdu_txq(p1905_multicast_address, ctx->p1905_al_mac_addr,
			e_topology_discovery, ctx->mid, ctx->itf[i].if_name, 0);

     /*according to IEEE P1905.1 spec, we need to send 802.1 bridge
         *detection message after sending topology discovery message
         *so we implement this functionality here
         */
	for (i = 0; i < ctx->itf_number; i++) {
		if (0 > send_802_1_bridge_discovery_msg(ctx,
			nearest_bridge_group_address, ctx->itf[i].mac_addr, buf->buf, i))
			debug(DEBUG_ERROR, "send lldpdu fail on %s\n", ctx->itf[i].if_name);
	}

	common_process(ctx, buf);
	eloop_register_timeout(ctx->discovery_cnt * PERIODIC_TIMER_SEC, 0,
		send_discovery_periodic, (void *)ctx, NULL);
}

void clear_topology_db(struct p1905_topology_db *topo_entry)
{
	struct topology_discovery_db *pddb = NULL, *pddb_tmp = NULL;
	struct topology_response_db *prdb = NULL, *prdb_tmp = NULL;
	struct device_info_db *pdev_info_db = NULL, *pdev_info_db_tmp = NULL;
	struct p1905_neighbor_device_db *neighbor_dev_db = NULL, *neighbor_dev_db_tmp = NULL;
	struct non_p1905_neighbor_device_list_db *non_neighbor_dev_db = NULL;
	struct non_p1905_neighbor_device_list_db *non_neighbor_dev_db_tmp = NULL;
	struct device_bridge_capability_db *pbrcap_db = NULL, *pbrcap_db_tmp = NULL;

	/*free list tpddb_head*/
	pddb = LIST_FIRST(&topo_entry->tpddb_head);
	while (pddb != NULL) {
		pddb_tmp = LIST_NEXT(pddb, tpddb_entry);
		debug(DEBUG_TRACE, "free topology_discovery_db(al="MACSTR")\n",
			PRINT_MAC(pddb->al_mac));
		free(pddb);
		pddb = pddb_tmp;
	}
	LIST_INIT(&topo_entry->tpddb_head);

	/*free list tprdb_head*/
	prdb = SLIST_FIRST(&topo_entry->tprdb_head);
	while (prdb != NULL) {
		prdb_tmp = SLIST_NEXT(prdb, tprdb_entry);
		debug(DEBUG_TRACE, "[%s]free topology_response_db(al="MACSTR")\n",
			__func__, PRINT_MAC(prdb->al_mac_addr));

		/*free devinfo_head*/
		pdev_info_db = SLIST_FIRST(&prdb->devinfo_head);
		while (pdev_info_db != NULL) {
			pdev_info_db_tmp = SLIST_NEXT(pdev_info_db, devinfo_entry);
			debug(DEBUG_TRACE, "[%s]free device_info_db(mac="MACSTR")\n",
				__func__, PRINT_MAC(pdev_info_db->mac_addr));

			/*free p1905_neighbor_device_db*/
			neighbor_dev_db = SLIST_FIRST(&pdev_info_db->p1905_nbrdb_head);
			while (neighbor_dev_db != NULL) {
				neighbor_dev_db_tmp = SLIST_NEXT(neighbor_dev_db, p1905_nbrdb_entry);
				debug(DEBUG_TRACE, "[%s]free neighbor_dev_db(al="MACSTR")\n",
					__func__, PRINT_MAC(neighbor_dev_db->p1905_neighbor_al_mac));
				free(neighbor_dev_db);
				neighbor_dev_db = neighbor_dev_db_tmp;
			}
			SLIST_INIT(&pdev_info_db->p1905_nbrdb_head);

			/*free non_p1905_neighbor_device_list_db*/
			non_neighbor_dev_db = SLIST_FIRST(&pdev_info_db->non_p1905_nbrdb_head);
			while (non_neighbor_dev_db != NULL) {
				non_neighbor_dev_db_tmp = SLIST_NEXT(non_neighbor_dev_db, non_p1905_nbrdb_entry);
				debug(DEBUG_TRACE, "[%s]free non neighbor_dev_db(al="MACSTR")\n",
					__func__, PRINT_MAC(non_neighbor_dev_db->non_p1905_device_interface_mac));
				free(non_neighbor_dev_db);
				non_neighbor_dev_db = non_neighbor_dev_db_tmp;
			}
			SLIST_INIT(&(pdev_info_db->non_p1905_nbrdb_head));

			if(pdev_info_db->vs_info_len)
				free(pdev_info_db->vs_info);

			free(pdev_info_db);
			pdev_info_db = pdev_info_db_tmp;
		}
		SLIST_INIT(&prdb->devinfo_head);

		/*free device_bridge_capability_db*/
		pbrcap_db = LIST_FIRST(&prdb->brcap_head);
		while (pbrcap_db != NULL) {
			pbrcap_db_tmp = LIST_NEXT(pbrcap_db, brcap_entry);
			if(pbrcap_db->interface_amount != 0)
				free(pbrcap_db->interface_mac_tuple);
			free(pbrcap_db);
			pbrcap_db = pbrcap_db_tmp;
		}
		LIST_INIT(&(prdb->brcap_head));

		free(prdb);
		prdb = prdb_tmp;
	}
	SLIST_INIT(&topo_entry->tprdb_head);

}

void clear_topology_neighbor_db(struct p1905_neighbor *neighbor, unsigned char itf_number)
{
	struct p1905_neighbor_info *pinfo = NULL, *pinfo_tmp = NULL;
	int i = 0;

	for(i = 0; i < itf_number; i++) {
		pinfo = LIST_FIRST(&neighbor[i].p1905nbr_head);
		while (pinfo != NULL) {
			pinfo_tmp = LIST_NEXT(pinfo, p1905nbr_entry);
			debug(DEBUG_TRACE, "[%s]neighbor[%d]free p1905_neighbor_info(al="MACSTR")\n",
				__func__,i, PRINT_MAC(pinfo->al_mac_addr));
			free(pinfo);
			pinfo = pinfo_tmp;
		}
		LIST_INIT(&neighbor[i].p1905nbr_head);
	}
}

void clear_topology_device_db(struct p1905_topodevice_db *topodev_entry)
{
	struct topology_device_db *pdev = NULL, *pdev_tmp = NULL;

	pdev = SLIST_FIRST(&topodev_entry->tpdevdb_head);
	while (pdev != NULL) {
		pdev_tmp = SLIST_NEXT(pdev, tpdev_entry);
		debug(DEBUG_TRACE, "[%s]free topology device(al="MACSTR")\n",
			__func__, PRINT_MAC(pdev->aldev_mac));
		free(pdev);
		pdev = pdev_tmp;
	}
	SLIST_INIT(&topodev_entry->tpdevdb_head);
}

void dump_topology_info(struct p1905_managerd_ctx *ctx)
{
	struct topology_discovery_db *tpg_db;
	struct topology_response_db  *tpr_db;
	struct device_info_db *dev_info;
	struct p1905_neighbor_device_db *p1905_dev;
	struct non_p1905_neighbor_device_list_db *non_p1905_dev;
	struct device_bridge_capability_db *br_cap;
	unsigned char *mac = NULL;
	struct agent_list_db *agent_info = NULL;
	int i = 0;
	int j = 0;
	int z = 0;
	int a = 0, b = 0;
	int service_num = 0;

	debug(DEBUG_OFF, "====================topology discovery====================\n");
	if (!LIST_EMPTY(&ctx->topology_entry.tpddb_head)) {
	    LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry)
	    {
	        i++;
	        debug(DEBUG_OFF, "neighbor%d AL MAC: "MACSTR"\n", i, PRINT_MAC(tpg_db->al_mac));
	       	debug(DEBUG_OFF, "neighbor%d con-intf MAC: "MACSTR"\n", i, PRINT_MAC(tpg_db->itf_mac));
	        debug(DEBUG_OFF, "neighbor%d recv_intf MAC: "MACSTR" eth_port[%d]\n",
				i, PRINT_MAC(tpg_db->receive_itf_mac), tpg_db->eth_port);
	    }
	} else {
	    debug(DEBUG_OFF, "!!!no topology discovery\n");
	}

	debug(DEBUG_OFF, "====================topology response====================\n");
	if (!SLIST_EMPTY(&ctx->topology_entry.tprdb_head)) {
	    i = 0;
	    SLIST_FOREACH(tpr_db, &ctx->topology_entry.tprdb_head, tprdb_entry)
	    {
	        i++;
			debug(DEBUG_OFF, "-------------------------------\n");
			for (service_num = 0; service_num < tpr_db->support_service_cnt; service_num++) {
				debug(DEBUG_OFF, "device%d AL MAC("MACSTR") service(%d)\n",
					i, PRINT_MAC(tpr_db->al_mac_addr), tpr_db->support_service[service_num]);
			}
#ifdef MAP_R2
			debug(DEBUG_OFF, "multi-ap profile=%02x\n", tpr_db->profile);
#endif
	        if (!SLIST_EMPTY(&tpr_db->devinfo_head)) {
	            SLIST_FOREACH(dev_info, &tpr_db->devinfo_head, devinfo_entry)
	            {
	                j++;
					debug(DEBUG_OFF, "-------------------------------\n");
					debug(DEBUG_OFF, "interface%d("MACSTR") media type(0x%04x)\n",
						j, PRINT_MAC(dev_info->mac_addr), dev_info->media_type);
	                if (dev_info->vs_info_len > 0)
						hex_dump_all("media specific info", dev_info->vs_info, dev_info->vs_info_len);
					debug(DEBUG_OFF, "-------------------------------\n");
					debug(DEBUG_OFF, "p1905 neighbor device:\n");
	                if (!SLIST_EMPTY(&dev_info->p1905_nbrdb_head)) {
	                    SLIST_FOREACH(p1905_dev, &dev_info->p1905_nbrdb_head, p1905_nbrdb_entry)
	                    {
	                        z++;
							debug(DEBUG_OFF, "neighbor%d("MACSTR") 802.1 bridge exist(%d)\n",
								z, PRINT_MAC(p1905_dev->p1905_neighbor_al_mac),
								p1905_dev->ieee_802_1_bridge_exist);
	                    }
	                    z = 0;

	                }
					debug(DEBUG_OFF, "-------------------------------\n");
					debug(DEBUG_OFF, "p1905 non neighbor device:\n");
	                if (!SLIST_EMPTY(&dev_info->non_p1905_nbrdb_head)) {
	                    SLIST_FOREACH(non_p1905_dev, &dev_info->non_p1905_nbrdb_head, non_p1905_nbrdb_entry)
	                    {
	                        z++;
							debug(DEBUG_OFF, "non neighbor%d("MACSTR")\n",
								z, PRINT_MAC(non_p1905_dev->non_p1905_device_interface_mac));
	                    }
	                    z = 0;
	                }
	            }
	            j = 0;

	        }
			debug(DEBUG_OFF, "-------------------------------\n");
	        if (!LIST_EMPTY(&tpr_db->brcap_head)) {
	            LIST_FOREACH(br_cap, &tpr_db->brcap_head, brcap_entry)
	            {
	                a++;
	                debug(DEBUG_OFF, "bridge%d interface amount(%d)\n", a, br_cap->interface_amount);
	                if (br_cap->interface_amount > 0) {
	                    for(b = 0; b < br_cap->interface_amount; b++) {
							mac = br_cap->interface_mac_tuple + b * ETH_ALEN;
							debug(DEBUG_OFF, "interface_mac%d("MACSTR")\n",b, MAC2STR(mac));
	                    }
	                }
	            }
#ifdef MAP_R2
				debug(DEBUG_OFF, "multi-ap profile=%02x\n", tpr_db->profile);
#endif
	        }
	    }
	} else {
	    debug(DEBUG_OFF, "!!!no topology response\n");
	}
	debug(DEBUG_OFF, "====================agent list db====================\n");
	SLIST_FOREACH(agent_info, &(ctx->agent_head), agent_entry)
	{
		debug(DEBUG_OFF, "AL MAC: "MACSTR", profile:%02x, radio number:%d\n",
			PRINT_MAC(agent_info->almac), agent_info->profile, agent_info->radio_num);
		for (i = 0; i < agent_info->radio_num; i++) {
			debug(DEBUG_OFF, "\tradio[%d]:"MACSTR", band:%02x, conf_state:%d, max_bss_num=%d,"
				" opclass_number:%d, doing_wsc=%d\n", i, PRINT_MAC(agent_info->ra_info[i].identifier),
				agent_info->ra_info[i].band, agent_info->ra_info[i].conf_ctx.config_status,
				agent_info->ra_info[i].max_bss_num, agent_info->ra_info[i].op_class_num,
				agent_info->ra_info[i].doing_wsc);
		}
	}
	debug(DEBUG_OFF, "\n\n");
}


void print_tree_leaf_handler(void *context, void* parent_leaf, void *current_leaf, void *data)
{
	struct leaf *parent = (struct leaf*)parent_leaf;
	struct leaf *current = (struct leaf*)current_leaf;
	struct p1905_managerd_ctx *ctx = (struct p1905_managerd_ctx *)context;

	if (ctx->role == CONTROLLER) {
		 debug(DEBUG_OFF, "\t\033[1m\033[40;31m (%p)("MACSTR")------>[current](%p)("MACSTR")\033[0m\n",
		 	parent, PRINT_MAC(parent->al_mac), current, PRINT_MAC(current->al_mac));

	} else {
		debug(DEBUG_OFF, "\t\033[1m\033[40;31m (%p)("MACSTR")------>(%p)("MACSTR")\033[0m\n",
			parent, PRINT_MAC(parent->al_mac), current, PRINT_MAC(current->al_mac));
	}
}

void dump_topology_tree(struct p1905_managerd_ctx *ctx)
{
	trace_topology_tree_cb(ctx,ctx->root_leaf, print_tree_leaf_handler, NULL);
}

void dump_radio_info(struct p1905_managerd_ctx *ctx)
{
	unsigned char radio_index = 0, bss_index = 0, if_index = 0, ch_index = 0;
	struct radio_info *r = NULL;
	struct p1905_interface *itf = NULL;
	struct operating_class *opc = NULL;

	debug(DEBUG_OFF, "====================ALMAC====================\n");
	debug(DEBUG_OFF, "My almac "MACSTR"\n", PRINT_MAC(ctx->p1905_al_mac_addr));
	debug(DEBUG_OFF, "\n\n");


	debug(DEBUG_OFF, "====================RADIO INFO====================\n");
	debug(DEBUG_OFF, "total radio number: %d\n", ctx->radio_number);
	for (radio_index = 0; radio_index < ctx->radio_number; radio_index++) {
		r = &ctx->rinfo[radio_index];
		debug(DEBUG_OFF, "radio%d:      "MACSTR"\n",radio_index, PRINT_MAC(r->identifier));
		debug(DEBUG_OFF, "----------attribut:\n");
		debug(DEBUG_OFF, "teared_down: %d   trrigerd_autoconf: %d\n", r->teared_down, r->trrigerd_autoconf);
		debug(DEBUG_OFF, "band: %d   config_status: %d   bss_number: %d\n", r->band, r->config_status, r->bss_number);
		debug(DEBUG_OFF, "----------bss list:\n");
		for (bss_index = 0; bss_index < r->bss_number; bss_index++) {
			debug(DEBUG_OFF, "name: %s   mac: "MACSTR"   config_status(%d)   priority(%d)\n",
				r->bss[bss_index].ifname,
				PRINT_MAC(r->bss[bss_index].mac),
				r->bss[bss_index].config_status,
				r->bss[bss_index].priority
				);
#ifdef MAP_R2
			debug(DEBUG_OFF, "ssid: %s   AuthMode: %d   EncrypType: %d\n",
				r->bss[bss_index].config.Ssid,
				r->bss[bss_index].config.AuthMode,
				r->bss[bss_index].config.EncrypType
			);
			debug(DEBUG_OFF, "WPAKey: %s role: %02x   hidden_ssid: %d\n",
				r->bss[bss_index].config.WPAKey,
				r->bss[bss_index].config.map_vendor_extension,
				r->bss[bss_index].config.hidden_ssid
			);
#endif
		}
		debug(DEBUG_OFF, "----------radio basic capability: max bss number:%d operating class number:%d\n",
			r->basic_cap.max_bss_num, r->basic_cap.op_class_num);
		dl_list_for_each(opc, &r->basic_cap.op_class_list, struct operating_class, entry) {
			debug(DEBUG_OFF, "opclass:%d   max_tx_pwr=%d   non_operch_num=%d\n",
				opc->class_number, opc->max_tx_pwr, opc->non_operch_num);
			debug(DEBUG_OFF, "\tnon_operch_list:\n");
			for (ch_index = 0; ch_index < opc->non_operch_num; ch_index++)
				debugbyte(DEBUG_OFF, "%d \n", opc->non_operch_list[ch_index]);
			debug(DEBUG_OFF, "\n");
		}
	}
	debug(DEBUG_OFF, "\n\n");
	debug(DEBUG_OFF, "====================INTERFACE INFO====================\n");
	debug(DEBUG_OFF, "total interface number: %d\n", ctx->itf_number);
	for (if_index = 0; if_index < ctx->itf_number; if_index++) {
		itf = &ctx->itf[if_index];
		debug(DEBUG_OFF, "interface%d:   mac_addr: "MACSTR"   if_name: %s   media_type: %04x\n",
			if_index, PRINT_MAC(itf->mac_addr), itf->if_name, itf->media_type);
		if (itf->is_wifi_ap || itf->is_wifi_sta) {
			debug(DEBUG_OFF, "channel_freq: %d   channel_bw: %d\n",
				itf->channel_freq, itf->channel_bw);
		}
		if (itf->is_wifi_sta) {
			debug(DEBUG_OFF, "BSSID: "MACSTR"\n", PRINT_MAC(itf->vs_info));
		}
		if (itf->is_wan) {
			debug(DEBUG_OFF, "WAN interface\n");
		}
		if (itf->is_veth) {
			debug(DEBUG_OFF, "VETH interface\n");
		}
	}
	debug(DEBUG_OFF, "\n\n");
	debug(DEBUG_OFF, "====================DESCRIPTION====================\n");
	debug(DEBUG_OFF, "----------total radio cap:\n");
	debug(DEBUG_OFF, "#define RADIO_2G_CAP         0x01\n");
	debug(DEBUG_OFF, "#define RADIO_5GL_CAP        0x02\n");
	debug(DEBUG_OFF, "#define RADIO_5GH_CAP        0x04\n");
	debug(DEBUG_OFF, "#define RADIO_5G_CAP         0x08\n");

	debug(DEBUG_OFF, "----------AuthMode:\n");
	debug(DEBUG_OFF, "#define AUTH_OPEN            0x0001\n");
	debug(DEBUG_OFF, "#define AUTH_WPA_PERSONAL    0x0002\n");
	debug(DEBUG_OFF, "#define AUTH_WPA2_PERSONAL   0x0020\n");
	debug(DEBUG_OFF, "#define AUTH_SAE_PERSONAL    0x0040\n");

	debug(DEBUG_OFF, "----------EncrypType:\n");
	debug(DEBUG_OFF, "#define ENCRYP_NONE          0x0001\n");
	debug(DEBUG_OFF, "#define ENCRYP_TKIP          0x0004\n");
	debug(DEBUG_OFF, "#define ENCRYP_AES           0x0008\n");

	debug(DEBUG_OFF, "----------role:\n");
	debug(DEBUG_OFF, "#define BIT_BH_STA           BIT(7)\n");
	debug(DEBUG_OFF, "#define BIT_BH_BSS           BIT(6)\n");
	debug(DEBUG_OFF, "#define BIT_FH_BSS           BIT(5)\n");
	debug(DEBUG_OFF, "#define BIT_TEAR_DOWN        BIT(4)\n");

	debug(DEBUG_OFF, "----------media_type:\n");
	debug(DEBUG_OFF, "#define IEEE802_3_GROUP      0x0000\n");
	debug(DEBUG_OFF, "#define IEEE802_11_GROUP     0x0100\n");
}




int is_in_exclude_port_list(int port, int *exclude_port, int num)
{
	int i = 0;

	for (i =0; i < num; i++) {
		if (port == exclude_port[i])
			return 1;
	}

	return 0;
}

/*debug cmd.*/
void show_PON_dev(struct p1905_managerd_ctx *ctx)
{
	struct topology_discovery_db *tpg_db = NULL;
	struct topology_discovery_db *tpg_db_tmp = NULL, *ntpg_db_tmp = NULL;
	int i = 0, j = 0;
	int exclude_port[7] = {-1};

	if (ctx->role != CONTROLLER) {
		debug(DEBUG_OFF, "need input this cmd on controller\n");
		return;
	}

    LIST_FOREACH(tpg_db, &ctx->topology_entry.tpddb_head, tpddb_entry)
    {
		i = 0;
		if (tpg_db->eth_port != -1 &&
			!is_in_exclude_port_list(tpg_db->eth_port, exclude_port, 7)) {
			tpg_db_tmp = LIST_NEXT(tpg_db, tpddb_entry);
			while(tpg_db_tmp) {
				ntpg_db_tmp = LIST_NEXT(tpg_db_tmp, tpddb_entry);
				if (tpg_db_tmp->eth_port == tpg_db->eth_port)
					i++;
				tpg_db_tmp = ntpg_db_tmp;
			}
			if (i >= 1) {
				exclude_port[j++] = tpg_db->eth_port;
				tpg_db_tmp = LIST_FIRST(&ctx->topology_entry.tpddb_head);
				while(tpg_db_tmp) {
					ntpg_db_tmp = LIST_NEXT(tpg_db_tmp, tpddb_entry);
					if (tpg_db_tmp->eth_port == tpg_db->eth_port) {
						 debug(DEBUG_OFF, "DEV("MACSTR")"
						 	"conncet to PON\n", PRINT_MAC(tpg_db_tmp->al_mac));
					}
					tpg_db_tmp = ntpg_db_tmp;
				}
				debug(DEBUG_OFF, "DEV("MACSTR")"
						 	"conncet to PON\n", PRINT_MAC(ctx->p1905_al_mac_addr));
				debug(DEBUG_OFF, "controller conncet port(%d)\n", tpg_db->eth_port);
			}
		}
    }
}

int calculate_and_dump_controller_num_in_topo(struct p1905_managerd_ctx *ctx)
{
	struct topology_response_db *tpgr_db = NULL;
	int service_num = 0;
	int controller_num = 0;

	debug(DEBUG_OFF, "====================Controller Count Info====================\n");
	debug(DEBUG_OFF, "\n");

	if (!SLIST_EMPTY(&ctx->topology_entry.tprdb_head)) {
		SLIST_FOREACH(tpgr_db, &ctx->topology_entry.tprdb_head, tprdb_entry)
		{
			for (service_num = 0; service_num < tpgr_db->support_service_cnt; service_num++) {
				if (tpgr_db->support_service[service_num] == SERVICE_CONTROLLER) {
					controller_num++;
					debug(DEBUG_ERROR, "====controller exist"MACSTR"\n", MAC2STR(tpgr_db->al_mac_addr));
				}
			}
		}
	}
	debug(DEBUG_ERROR, "====the number of controller in the topology:%d\n", controller_num);
	debug(DEBUG_OFF, "============================================================\n");
	return controller_num;
}
