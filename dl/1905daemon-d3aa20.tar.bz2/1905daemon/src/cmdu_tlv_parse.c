/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <syslog.h>
#include <assert.h>
#include <linux/if_ether.h>
#include <asm/byteorder.h>

#include "cmdu_tlv_parse.h"
#include "wsc_attr_tlv.h"
#include "debug.h"
#include "cmdu_tlv.h"
#include "multi_ap.h"
#include "cmdu_message.h"
#ifdef MAP_R3
#include "json.h"
#endif



extern WSC_ATTR_STATUS parse_wsc_msg(
    struct p1905_managerd_ctx *ctx, unsigned char *pkt, unsigned short length);

unsigned char mtk_oui[3] = {0x00, 0x0C, 0xE7};

#define TOTAL_AL_MAC_ADDR_TLV_LENGTH 9
#define TOTAL_MAC_ADDR_TLV_LENGTH 9

int get_tlv_len(unsigned char *buf)
{
	unsigned char *temp_buf = buf;
	unsigned short length = 0;

	temp_buf += 1; /* shift to length field */

	length = *(unsigned short *)temp_buf;
	length = be_to_host16(length);

	return length;
}

int get_cmdu_tlv_length(unsigned char *buf)
{
	unsigned char *temp_buf = buf;
	unsigned short length = 0;

	temp_buf += 1; /* shift to length field */

	length = *(unsigned short *)temp_buf;
	length = be_to_host16(length);

	return (length+3);
}

/* sanity check TLV length, if sum TLV length is not equal with buffer length, drop it*/
int cmdu_sanity_check(unsigned char *buf, int len)
{
	unsigned char *pos = buf;
	unsigned int tlv_total_len = 0;

	while (1) {
		/* end tlv */
		if (*(pos + tlv_total_len) == END_OF_TLV_TYPE) {
			tlv_total_len += get_cmdu_tlv_length(pos + tlv_total_len);
			if (tlv_total_len == len || (tlv_total_len < MIN_TLVS_LENGTH && len == MIN_TLVS_LENGTH))
				return 0;
			else
				return -1;
		}
		tlv_total_len += get_cmdu_tlv_length(pos + tlv_total_len);
		/* not found end tlv */
		if (tlv_total_len >= len)
			return -2;
	}
}

int parse_al_mac_addr_type_tlv(unsigned char *al_mac, unsigned short len, unsigned char *value)
{
	if (len != ETH_ALEN)
		return -1;

	memcpy(al_mac, value, ETH_ALEN);

	return 0;
}


int parse_mac_addr_type_tlv(unsigned char *mac, unsigned short len, unsigned char *value)
{
	if (len != 0x6)
		return -1;

	memcpy(mac, value, ETH_ALEN);

	return 0;
}

int parse_vs_tlv(struct vs_value *vs_info, unsigned short len, unsigned char *value)
{
	int left = len;
	unsigned char *temp_buf = NULL;
	unsigned short sublen = 0;
	unsigned char func_type = 0, sub_type = 0;
	unsigned char suboui[3] = {0x00, 0x0C, 0xE7};

	if (left < sizeof(mtk_oui) + 1) {
		debug(DEBUG_ERROR, "%d: left %d less than %d\n", __LINE__,
			left, (unsigned int)(sizeof(mtk_oui) + 1));
		return -1;
	}
	left -= (sizeof(mtk_oui) + 1);

	temp_buf = value;

	if (os_memcmp(temp_buf, mtk_oui, 3)) {
		debug(DEBUG_ERROR, "OUI not mtk_oui; do not handle!\n");
		return 0;
	}
	temp_buf += 3;

	func_type = *temp_buf++;

	switch(func_type) {
		case 0: /*mac sub type*/
			if (left != ETH_ALEN + 2) {
				debug(DEBUG_ERROR, "error vs mac tlv(%d)!\n", len);
				return -1;
			}
			sublen = *(unsigned short *)temp_buf;
			sublen = be_to_host16(sublen);
			if (sublen != ETH_ALEN) {
				debug(DEBUG_ERROR, "error mac len!\n");
				return -1;
			}
			temp_buf += 2;
			memcpy(vs_info->itf_mac, temp_buf, ETH_ALEN);
			debug(DEBUG_TRACE, "mac("MACSTR")!\n",
				PRINT_MAC(vs_info->itf_mac));
			break;
		case MLO_CAP_ANNOUNCE_TYPE:
			if (left != 8) {
				debug(DEBUG_ERROR, "MLO_CAP_ANNOUNCE vendor tlv len check fail\n");
				return -1;
			}
			memcpy(vs_info->mlo_data.mlo_cap.identifier, temp_buf, ETH_ALEN);
			temp_buf += ETH_ALEN;
			vs_info->mlo_data.mlo_cap.ap_mlo_cap = *temp_buf++;
			vs_info->mlo_data.mlo_cap.sta_mlo_cap = *temp_buf++;
			vs_info->mlo_cap_valid = 1;
			break;
		case 0xff:
			if (left < sizeof(suboui) + 1) {
				debug(DEBUG_ERROR, "%d: left %d less than %d\n", __LINE__,
					left, (unsigned int)(sizeof(suboui) + 1));
				return -1;
			}
			left -= sizeof(suboui) + 1;

			if (os_memcmp(suboui, temp_buf, sizeof(suboui))) {
				debug(DEBUG_ERROR, "error vendor specific tlv charactor_value\n");
				return -1;
			}
			temp_buf += sizeof(suboui);
			sub_type = *temp_buf++;

			switch (sub_type) {
				case internal_vendor_discovery_message_subtype:
					if (left != 0) {
						debug(DEBUG_ERROR, "error vs discovery tlv(%d)!\n", len);
						return -1;
					}
					vs_info->discovery = 1;
					break;
				case internal_vendor_notification_message_subtype:
					if (left != ETH_ALEN + 2) {
						debug(DEBUG_ERROR, "error vs notification tlv(%d)!\n", len);
						return -1;
					}
					sublen = *(unsigned short *)temp_buf;
					sublen = be_to_host16(sublen);
					temp_buf += 2;
					if (sublen != ETH_ALEN) {
						debug(DEBUG_ERROR, "error almac len!\n");
						return -1;
					}
					os_memcpy(vs_info->neth_almac, temp_buf, ETH_ALEN);
					break;
#ifdef MAP_R2
				case transparent_vlan_message_subtype:
				{
					unsigned char i = 0, num = 0;

					if (!vs_info->parse_ts)
						break;
					if (left < 1) {
						debug(DEBUG_ERROR, "%d: left %d less than %d\n", __LINE__, left, 1);
						return -1;
					}
					left--;

					num = *temp_buf++;
					if (num > MAX_NUM_TRANSPARENT_VID) {
						debug(DEBUG_TRACE, "num(%d) is larger than MAX_NUM_TRANSPARENT_VID\n", num);
						return -1;
					}

					if (left < 2 * num) {
						debug(DEBUG_ERROR, "%d: left %d less than %d\n", __LINE__, left, 2 * num);
						return -1;
					}
					left -= 2 * num;

					vs_info->trans_vlan.num = num;
					debug(DEBUG_ERROR, "parse transparent vlan number=%d\n", num);
					for (i = 0; i < num; i++) {
						vs_info->trans_vlan.transparent_vids[i] =
							be_to_host16(*((unsigned short *)temp_buf));
						temp_buf += 2;
						debug(DEBUG_ERROR, "parse transparent vlan id(%d)\n",
							vs_info->trans_vlan.transparent_vids[i]);
					}
					vs_info->trans_vlan.updated = 1;
				}
				break;
#endif
				default:
					break;
			}
			break;
		default:
			break;
	}

	return 0;
}


int parse_device_info_type_tlv(struct p1905_managerd_ctx *ctx,
				struct list_head_devinfo *devinfo_head, unsigned short len, unsigned char *value)
{
	unsigned char *temp_buf = value;
	int left = len;
	unsigned char itfs_num = 0;
	unsigned char vs_info_len = 0;
	int i = 0;
	struct device_info_db *dev;
	unsigned char mac[ETH_ALEN];
	unsigned char almac[ETH_ALEN] = {0};
	unsigned char topo_bss_num = 0;
#ifdef MAP_R3
	unsigned char all_zero_mac[ETH_ALEN] = {0};
	struct bss_connector_item *bc_item = NULL, *bc_item_nxt = NULL;
	struct hash_value_item *hv_item = NULL, *hv_item_nxt = NULL;
#endif

	if (left < 7)
		return -1;
	left -= 7;

	/* skip AL MAC address field */
	memcpy(almac, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;

	/* get the amount of local interface */
	itfs_num = *temp_buf;
	temp_buf += 1;

	for (i = 0; i < itfs_num; i++) {
		if (left < 9) {
			debug(DEBUG_ERROR, "%d:error left %d less than %d\n", __LINE__, left, 9);
			return -1;
		}
		left -= 9;

		memcpy(mac, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;

#ifdef MAP_R3
		if (ctx->map_version == MAP_PROFILE_R3 && ctx->role == CONTROLLER) {
			dl_list_for_each_safe(bc_item, bc_item_nxt,
				&ctx->r3_dpp.bss_connector_list, struct bss_connector_item, member) {
				if (os_memcmp(bc_item->almac, all_zero_mac, ETH_ALEN))
					continue;
				if (!os_memcmp(bc_item->mac_apcli, mac, ETH_ALEN)) {
					debug(DEBUG_ERROR, "update almac "MACSTR" for bss connector\n", MAC2STR(almac));
					os_memcpy(bc_item->almac, almac, ETH_ALEN);

					map_dpp_save_bss_connector(bc_item);
					break;
				}
			}

			dl_list_for_each_safe(hv_item, hv_item_nxt,
				&ctx->r3_dpp.hash_value_list, struct hash_value_item, member) {
				if (os_memcmp(hv_item->almac, all_zero_mac, ETH_ALEN))
					continue;
				if (!os_memcmp(hv_item->mac_apcli, mac, ETH_ALEN)) {
					debug(DEBUG_ERROR, "update almac "MACSTR" for hash value\n", MAC2STR(almac));
					os_memcpy(hv_item->almac, almac, ETH_ALEN);
					break;
				}
			}
		}
#endif
		vs_info_len = *(temp_buf + 2);
		if (left < vs_info_len) {
			debug(DEBUG_ERROR, "%d: error left %d less than %d\n", __LINE__, left, vs_info_len);
			return -1;
		}
		left -= vs_info_len;

		dev = (struct device_info_db *)malloc(sizeof(struct device_info_db));
		if (dev == NULL)
			return -1;
		memcpy(dev->mac_addr, mac, ETH_ALEN);
		/*init the list head of p1905.1 neighbor device list*/
		SLIST_INIT(&(dev->p1905_nbrdb_head));
		/*init the list head of non-p1905.1 neighbor device list*/
		SLIST_INIT(&(dev->non_p1905_nbrdb_head));
		SLIST_INSERT_HEAD(devinfo_head, dev, devinfo_entry);

		dev->media_type = (*(unsigned short *)temp_buf);
		dev->media_type = host_to_be16(dev->media_type);
		temp_buf += 2;

		dev->vs_info_len = vs_info_len;
		temp_buf += 1;

		if (vs_info_len > 0) {
			dev->vs_info = (unsigned char *)malloc(vs_info_len);
			if (dev->vs_info == NULL)
				return -1;
			memcpy(dev->vs_info, temp_buf, vs_info_len);
			temp_buf += vs_info_len;

			if (vs_info_len == 10 && (*(dev->vs_info + 6) == 0x00))
				topo_bss_num++;
		}
	}

	return 0;
}

int parse_bridge_capability_type_tlv(struct list_head_brcap *brcap_head,
					unsigned short len, unsigned char *value)
{
	unsigned char *temp_buf = value;
	int left = len;
	unsigned char br_num = 0;
	int i = 0;
	unsigned char br_itfs_num = 0;
	struct device_bridge_capability_db *br;

	if (left < 1)
		return -1;
	left--;

	/* the field of total number of bridge tuple */
	br_num = *temp_buf;
	temp_buf++;

	/* loop br_num times to store the bridge tuple information */
	for (i = 0; i < br_num; i++) {
		if (left < 1) {
			debug(DEBUG_ERROR, "%d: left %d less than %d\n", __LINE__, left, 1);
			return -1;
		}
		left--;

		br_itfs_num = *temp_buf;
		temp_buf++;

		br = (struct device_bridge_capability_db *)malloc(sizeof(struct device_bridge_capability_db));
		if (br == NULL)
			return -1;
		br->interface_amount = br_itfs_num;

		if (br_itfs_num > 0) {
			if (left < br_itfs_num * ETH_ALEN) {
				debug(DEBUG_ERROR, "%d: left %d less than %d\n",
					__LINE__, left, br_itfs_num * ETH_ALEN);
				free(br);
				return -1;
			}
			left -= br_itfs_num * ETH_ALEN;

			br->interface_mac_tuple = (unsigned char *)malloc(br_itfs_num * ETH_ALEN);
			if (br->interface_mac_tuple == NULL) {
				free(br);
				return -1;
			}
			memcpy(br->interface_mac_tuple, temp_buf, (br_itfs_num * ETH_ALEN));
		}

		LIST_INSERT_HEAD(brcap_head, br, brcap_entry);

		temp_buf += br_itfs_num * ETH_ALEN;
	}

	return 0;
}

int parse_p1905_neighbor_device_type_tlv(struct list_head_devinfo *devinfo_head,
						unsigned short len, unsigned char *value)
{
	unsigned char *temp_buf = value;
	int left = len;
	struct p1905_neighbor_device_db *dev;
	struct device_info_db *dev_info;
	unsigned char local_mac[ETH_ALEN];
	unsigned char al_mac[ETH_ALEN];
	unsigned char exist = 0;
	unsigned char new_db = 1;
	int tuple_num = 0;
	int i = 0;

	if (left < ETH_ALEN)
		return -1;
	left -= ETH_ALEN;

	memcpy(local_mac, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;

	/* tlv value has one local mac address field(6 bytes) and several
	* (al mac address field(6 bytes) + 802.1 exist field(1 byte)),
	* so tlv (value length - 6 ) % 7 must be zero
	*/
	if ((left % 7) == 0)
		tuple_num = left / 7;
	else
		return -1;

	SLIST_FOREACH(dev_info, devinfo_head, devinfo_entry) {
		if (!memcmp(local_mac, dev_info->mac_addr, ETH_ALEN)) {
			exist = 1;
			break;
		}
	}

	if (!exist)
		return 0;

	if (left < 7 * tuple_num) {
		debug(DEBUG_ERROR, "%d: left %d less than %d\n", __LINE__, left, 7 * tuple_num);
		return -1;
	}
	left -= 7 * tuple_num;

	for (i = 0; i < tuple_num; i++) {
		memcpy(al_mac, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;

		new_db = 1;

		/* maybe we don't needt to do this check because the old topology
		 * response db will be deleted when we get a new topology response
		 * message.
		 */
		SLIST_FOREACH(dev, &(dev_info->p1905_nbrdb_head), p1905_nbrdb_entry) {
			if (!memcmp(al_mac, dev->p1905_neighbor_al_mac, ETH_ALEN)) {
				new_db = 0;
				break;
			}
		}

		if (new_db) {
			dev = (struct p1905_neighbor_device_db *)malloc(sizeof(struct p1905_neighbor_device_db));
			if (dev == NULL)
				return -1;
			memcpy(dev->p1905_neighbor_al_mac, al_mac, ETH_ALEN);
			SLIST_INSERT_HEAD(&(dev_info->p1905_nbrdb_head), dev, p1905_nbrdb_entry);
		}

		if (((*temp_buf) & 0x80) == 0x80)
			dev->ieee_802_1_bridge_exist = 1;
		else
			dev->ieee_802_1_bridge_exist = 0;

		temp_buf += 1;
	}
	return 0;
}

int parse_non_p1905_neighbor_device_type_tlv(struct list_head_devinfo *devinfo_head,
						unsigned short len, unsigned char *value)
{
	unsigned char *temp_buf = value;
	int left = len;
	int tuple_num = 0;
	unsigned char local_mac[ETH_ALEN];
	unsigned char neighbor_mac[ETH_ALEN];
	struct device_info_db *dev_info;
	struct non_p1905_neighbor_device_list_db *dev;

	unsigned char exist = 0;
	unsigned char new_db = 1;
	int i = 0;

	if (left < ETH_ALEN)
		return -1;
	left -= ETH_ALEN;

	/*get local interface field*/
	memcpy(local_mac, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;

	/*calculate how many non-1905.1 device*/
	if ((left % 6) == 0)
		tuple_num = left / 6;
	else
		return -1;

	SLIST_FOREACH(dev_info, devinfo_head, devinfo_entry) {
		if (!memcmp(local_mac, dev_info->mac_addr, ETH_ALEN)) {
			exist = 1;
			break;
		}
	}

	if (!exist)
		return 0;

	if (left < tuple_num * ETH_ALEN) {
		debug(DEBUG_ERROR, "%d: left %d less than %d\n", __LINE__, left, tuple_num * ETH_ALEN);
		return -1;
	}
	left -= tuple_num * ETH_ALEN;

	for (i = 0; i < tuple_num; i++) {
		memcpy(neighbor_mac, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;

		new_db = 1;
		/* maybe we don't need to do this check because the old topology
		* response db will be deleted when we get a new topology response
		* message.
		*/
		SLIST_FOREACH(dev, &(dev_info->non_p1905_nbrdb_head), non_p1905_nbrdb_entry) {
			if (!memcmp(neighbor_mac, dev->non_p1905_device_interface_mac, ETH_ALEN)) {
				new_db = 0;
				break;
			}
		}
		if (new_db) {
			dev = (struct non_p1905_neighbor_device_list_db *)
				malloc(sizeof(struct non_p1905_neighbor_device_list_db));
			if (dev == NULL)
				return -1;
			memcpy(dev->non_p1905_device_interface_mac, neighbor_mac, ETH_ALEN);
			SLIST_INSERT_HEAD(&(dev_info->non_p1905_nbrdb_head), dev, non_p1905_nbrdb_entry);
		}
	}
	return 0;
}

int parse_link_metric_query_type_tlv(unsigned char *target, unsigned char *type, unsigned short len, unsigned char *value)
{
	unsigned char *temp_buf = value;

	/* set target mac = 0 if query all neighbors */
	if (*temp_buf == QUERY_ALL_NEIGHBOR) {
		memset(target, 0, ETH_ALEN);
		temp_buf += 1;

		/* add for IOT issue with BRCM */
		if (len == 8)
			temp_buf += ETH_ALEN;
	} else if (*temp_buf == QUERY_SPECIFIC_NEIGHBOR) {
		temp_buf += 1;
		memcpy(target, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;
	} else {
		debug(DEBUG_ERROR, "reserve valus %d\n", *temp_buf);
		return -1;
	}

	if (*temp_buf == TX_METRICS_ONLY)
		*type = TX_METRICS_ONLY;
	else if (*temp_buf == RX_METRICS_ONLY)
		*type = RX_METRICS_ONLY;
	else if (*temp_buf == BOTH_TX_AND_RX_METRICS)
		*type = BOTH_TX_AND_RX_METRICS;

	return 0;
}

#ifdef SUPPORT_ALME
int parse_transmitter_link_metrics_type_tlv(unsigned char *buf,
            unsigned char *local_al_mac, ALME_GET_METRIC_RSP *metric_rsp)
{
    unsigned char *temp_buf;
    int length = 0;
    unsigned char response_al_mac[6];
    unsigned short link_tuple_num = 0;
    int i = 0;
    unsigned int value;


    temp_buf = buf;

    if((*temp_buf) == TRANSMITTER_LINK_METRIC_TYPE)
        temp_buf++;
    else
    {
        return -1;
    }

    /*calculate tlv length*/
    length = (*temp_buf);
    length = (length << 8) & 0xFF00;
    length = length |(*(temp_buf+1));
    /*shift to tlv value field*/
    temp_buf+=2;

    /*transmit device's al mac field*/
    memcpy(response_al_mac, temp_buf, 6);
    temp_buf += 6;

    /*shift to neighbor al mac field*/
    /*if the neighbor al mac is not local, return fail*/
    if(memcmp(local_al_mac, temp_buf, 6))
    {
        debug(DEBUG_ERROR, "got a wrong target tx link metrics tlv\n");
        return -1;
    }
    temp_buf += 6;

    if(((length - 12) % 29) != 0)
    {
        debug(DEBUG_ERROR, "got a wrong length tx link metrics tlv\n");
        return -1;
    }

    link_tuple_num = (length - 12) /29;

    if(link_tuple_num > MAX_1905_LINK_NUM)
    {
        debug(DEBUG_ERROR, "got a wrong link num tx link metrics tlv\n");
        return -1;
    }

    metric_rsp->descriptor_num = link_tuple_num;
    for(i=0;i<link_tuple_num;i++)
    {
        /*fill into neighbor al mac field first*/
        memcpy(metric_rsp->descriptorlist[i].neighbor_al_mac, response_al_mac, 6);

        /*shift to interface mac addr of neighbor field*/
        temp_buf += 6;
        /*fill into local interface field in alme*/
        memcpy(metric_rsp->descriptorlist[i].local_itf_mac, temp_buf, 6);
        temp_buf += 6;

        /*intf type*/
        value = *(temp_buf);
        value = ((value << 8) & 0x0000FF00)| (*(temp_buf + 1));
        metric_rsp->descriptorlist[i].link_metrics.itf_type = (unsigned short)value;
        temp_buf += 2;

        /*ieee802.1 bridge*/
        metric_rsp->descriptorlist[i].ieee802_1_bridge = *(temp_buf);
        temp_buf += 1;

        /*packet error*/
        value = *(temp_buf);
        value = ((value << 8) & 0x0000FF00)| (*(temp_buf + 1));
        value = ((value << 8) & 0x00FFFF00)| (*(temp_buf + 2));
        value = ((value << 8) & 0xFFFFFF00)| (*(temp_buf + 3));
        metric_rsp->descriptorlist[i].link_metrics.tx_packet_error = value;
        temp_buf += 4;

        /*transmitted packets*/
        value = *(temp_buf);
        value = ((value << 8) & 0x0000FF00)| (*(temp_buf + 1));
        value = ((value << 8) & 0x00FFFF00)| (*(temp_buf + 2));
        value = ((value << 8) & 0xFFFFFF00)| (*(temp_buf + 3));
        metric_rsp->descriptorlist[i].link_metrics.tx_total_packet = value;
        temp_buf += 4;

        /*mac throghput capacity*/
        value = *(temp_buf);
        value = ((value << 8) & 0x0000FF00)| (*(temp_buf + 1));
        metric_rsp->descriptorlist[i].link_metrics.max_throughput_capacity = (unsigned short)value;
        temp_buf += 2;

        /*link availability*/
        value = *(temp_buf);
        value = ((value << 8) & 0x0000FF00)| (*(temp_buf + 1));
        metric_rsp->descriptorlist[i].link_metrics.link_availability = (unsigned short)value;
        temp_buf += 2;

        /*phy rate*/
        value = *(temp_buf);
        value = ((value << 8) & 0x0000FF00)| (*(temp_buf + 1));
        metric_rsp->descriptorlist[i].link_metrics.phy_rate = (unsigned short)value;
        temp_buf += 2;
    }

    return (length+3);
}

int parse_receiver_link_metrics_type_tlv(unsigned char *buf,
                unsigned char *local_al_mac, ALME_GET_METRIC_RSP *metric_rsp)
{
    unsigned char *temp_buf;
    int length = 0;
    unsigned char response_al_mac[6];
    unsigned short link_tuple_num = 0;
    int i = 0, j = 0;
    unsigned int value;

    temp_buf = buf;

    if((*temp_buf) == RECEIVER_LINK_METRIC_TYPE)
        temp_buf++;
    else
    {
        return -1;
    }

    /*calculate tlv length*/
    length = (*temp_buf);
    length = (length << 8) & 0xFF00;
    length = length |(*(temp_buf+1));
    /*shift to tlv value field*/
    temp_buf+=2;

    /*transmit device's al mac field*/
    memcpy(response_al_mac, temp_buf, 6);
    temp_buf += 6;

    /*shift to neighbor al mac field*/
    /*if the neighbor al mac is not local, return fail*/
    if(memcmp(local_al_mac, temp_buf, 6))
    {
        debug(DEBUG_ERROR, "got a wrong target rx link metrics tlv\n");
        return -1;
    }
    temp_buf += 6;

    if(((length - 12) % 23) != 0)
    {
        debug(DEBUG_ERROR, "got a wrong length rx link metrics tlv\n");
        return -1;
    }

    link_tuple_num = (length - 12) /23;

    /*compare link tuple num with tx and max link number*/
    if((link_tuple_num > MAX_1905_LINK_NUM) || (link_tuple_num != metric_rsp->descriptor_num))
    {
        debug(DEBUG_ERROR, "got a wrong link num rx link metrics tlv %d\n",link_tuple_num);
        return -1;
    }

    for(i=0;i<link_tuple_num;i++)
    {
        /*shift to interface mac addr of neighbor field*/
        temp_buf += 6;
        /*get correct position in metric_rsp*/
        for(j=0;j<link_tuple_num;j++)
        {
            if(!memcmp(temp_buf, metric_rsp->descriptorlist[j].local_itf_mac, 6))
                break;
        }
        if(j == link_tuple_num)
        {
            debug(DEBUG_ERROR, "got un-matched neighbor interface in rx link metric tlv\n");
            return -1;
        }
        temp_buf += 6;
        /*ignore iftype field*/
        temp_buf += 2;
        /*packet error*/
        value = *(temp_buf);
        value = ((value << 8) & 0x0000FF00)| (*(temp_buf + 1));
        value = ((value << 8) & 0x00FFFF00)| (*(temp_buf + 2));
        value = ((value << 8) & 0xFFFFFF00)| (*(temp_buf + 3));
        metric_rsp->descriptorlist[j].link_metrics.rx_packet_error = value;
        temp_buf += 4;
        /*total packet*/
        value = *(temp_buf);
        value = ((value << 8) & 0x0000FF00)| (*(temp_buf + 1));
        value = ((value << 8) & 0x00FFFF00)| (*(temp_buf + 2));
        value = ((value << 8) & 0xFFFFFF00)| (*(temp_buf + 3));
        metric_rsp->descriptorlist[j].link_metrics.rx_total_packet = value;
        temp_buf += 4;
        /*RSSI*/
        metric_rsp->descriptorlist[i].link_metrics.rssi = *(temp_buf);
        temp_buf += 1;
    }

    return (length+3);
}

int parse_link_metrics_result_code_type_tlv(unsigned char *buf)
{
    unsigned char *temp_buf;
    int length = 0;

    temp_buf = buf;
    /*shift to length field*/
    temp_buf++;

    /*calculate tlv length*/
    length = (*temp_buf);
    length = (length << 8) & 0xFF00;
    length = length |(*(temp_buf+1));
    /*shift to tlv value field*/
    temp_buf+=2;

    /*get result of invalid neighbor*/
    if((*temp_buf) == 0)
        return -1;

    return (length + 3);
}
#endif

int parse_search_role_tlv(unsigned short len, unsigned char *value)
{
	if (len != SEARCH_ROLE_LENGTH)
		return -1;

	if ((*value) != ROLE_REGISTRAR)
		return -1;

	return 0;
}

int parse_auto_config_freq_band_tlv(unsigned char *band, unsigned short len, unsigned char *value)
{
	if (len != AUTOCONFIG_FREQ_BAND_LENGTH)
		return -1;

	*band = *value;

	return 0;
}

int parse_supported_role_tlv(unsigned short len, unsigned char *value)
{
	if (len != SUPPORTED_ROLE_LENGTH)
		return -1;

	if ((*value) != ROLE_REGISTRAR)
		return -1;
	debug(DEBUG_TRACE, "support ROLE_REGISTRAR\n");

	return 0;
}

int parse_supported_freq_band_tlv(unsigned char *band, unsigned short len, unsigned char *value)
{
	if (len != SUPPORTED_FREQ_BAND_LENGTH)
		return -1;

	*band = *value;
	debug(DEBUG_TRACE, "support band %s\n", (*band) ? "5g":"2g");

	return 0;
}

int parse_wsc_tlv(struct p1905_managerd_ctx *ctx, unsigned short len, unsigned char *value)
{
	if (wsc_attr_success != parse_wsc_msg(ctx, value, len))
		return -1;

	return 0;
}

/*MAP protocol defined TLV parsing*/
int parse_map_version_tlv(unsigned char *buf, unsigned char *almac, unsigned char *profile)
{
	unsigned char *temp_buf;
	unsigned short length = 0;

	temp_buf = buf;
	if ((*temp_buf) == MULTI_AP_VERSION_TYPE)
		temp_buf++;
	else
		return -1;

	/* calculate tlv length */
	length = *(unsigned short *)temp_buf;
	length = be_to_host16(length);
	/* shift to tlv value field */
	temp_buf += 2;
	*profile = *temp_buf;
	return (length+3);
}


int parse_supported_service_tlv(unsigned char *service, unsigned short len, unsigned char *value
				, unsigned char *service_cnt)
{
	unsigned char *temp_buf = value;
	int left = len;

	if (service == NULL) {
		debug(DEBUG_ERROR, "error:service is NULL\n");
		return -1;
	}

	/* 1 byte: list of supported service(s) */
	if (left < 1)
		return -1;
	left--;

	if (left == 1) {
		temp_buf++;
		service[0] = *temp_buf;
		*service_cnt = 1;
	} else if (left == 2) {
		temp_buf++;
		service[0] = *temp_buf;
		temp_buf++;
		service[1] = *temp_buf;
		*service_cnt = 2;
	} else {
		return -1;
	}

	return 0;
}

int parse_ap_radio_basic_cap_tlv(struct p1905_managerd_ctx *ctx, struct agent_radio_info *rinfo,
					unsigned short len, unsigned char *value)
{
	int left = len;
	unsigned char *temp_buf = value;
	unsigned char opnum = 0, i = 0, non_opch_num = 0;
	unsigned char opclass = 0;
	unsigned char cap = 0;

	if (left < ETH_ALEN + 2)
		return -1;
	left -= ETH_ALEN + 2;

	/*here only parse identifier of ap_radio_basic_cap_tlv*/
	os_memcpy(rinfo->identifier, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;
	debug(DEBUG_TRACE, "identifier "MACSTR"\n", MAC2STR(rinfo->identifier));

	rinfo->max_bss_num = *temp_buf++;
	debug(DEBUG_TRACE, "bss number %d\n", rinfo->max_bss_num);
	/*Number of operating classes*/
	opnum = *temp_buf++;
	rinfo->op_class_num = opnum;

	if (opnum > MAX_OP_CLASS_NUM) {
		debug(DEBUG_ERROR, "opnum (%d) is large than MAX_OP_CLASS_NU)\n", opnum);
		return -1;
	}

	for (i = 0; i < opnum; i++) {
		if (left < 3) {
			debug(DEBUG_ERROR, "%d: error left %d less than %d\n", __LINE__, left, 3);
			return -1;
		}
		left -= 3;

		opclass = *temp_buf;
		temp_buf += 2;
		non_opch_num = *temp_buf++;
		cap = get_bandcap(ctx, opclass, non_opch_num, temp_buf);
		rinfo->band |= cap;

		if (left < non_opch_num) {
			debug(DEBUG_ERROR, "%d: error left %d less than %d\n", __LINE__, left, non_opch_num);
			return -1;
		}
		left -= non_opch_num;

		temp_buf += non_opch_num;
	}
	debug(DEBUG_TRACE, "radio_id("MACSTR") bandcap=%02x\n", PRINT_MAC(rinfo->identifier),
		rinfo->band);

	return 0;
}

int parse_ap_radio_identifier_tlv(struct p1905_managerd_ctx *ctx,
			OUT unsigned char *radio_identifier
#ifdef MAP_R2
			, unsigned char need_store
#endif
			, unsigned short len, unsigned char *val)
{
	if (len != ETH_ALEN)
		return -1;

	os_memcpy(radio_identifier, val, ETH_ALEN);
#ifdef MAP_R2
	if (need_store)
		add_new_radio_identifier(ctx, val);
#endif
	return 0;
}

int parse_client_assoc_event_tlv(struct p1905_managerd_ctx *ctx, unsigned char *mac,
	unsigned char *bssid, unsigned char *event, unsigned char *al_mac, unsigned short len,
	unsigned char *value, struct dl_list *clients_table)
{
	unsigned char *temp_buf = NULL;
#ifdef MAP_R2
	struct assoc_client *client = NULL;
	struct assoc_client *client_tmp = NULL;
#endif

	if (len != 13)
		return -1;

	temp_buf = value;

	debug(DEBUG_TRACE, "client("MACSTR") ", PRINT_MAC(temp_buf));
	os_memcpy(mac, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;
	os_memcpy(bssid, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;
	*event = *temp_buf;

	debug(DEBUG_TRACE, "sta("MACSTR")\n", PRINT_MAC(mac));
	debug(DEBUG_TRACE, "%s the ", (*event) ? "join" : "left");
	debug(DEBUG_TRACE, "bss("MACSTR")\n", PRINT_MAC(bssid));
#ifdef MAP_R2
	client = get_assoc_cli_by_mac(ctx, mac);

	if (client && (*event) == 0) {
		client_tmp = get_cli_by_mac(clients_table, mac);
		if (!client_tmp) {
			client_tmp = add_new_assoc_cli(clients_table, mac, al_mac);
			if (!client_tmp)
				return -1;
		}
		client_tmp->disassoc = 1;
	} else if (!client && *event) {
		client = add_new_assoc_cli(clients_table, mac, al_mac);
		if (client) {
			os_memcpy(client->bssid, bssid, ETH_ALEN);
		}
		debug(DEBUG_ERROR, "add sta("MACSTR") bssid("MACSTR")\n",
			PRINT_MAC(mac), PRINT_MAC(bssid));
	}
#endif
	return 0;

}

int parse_client_info_tlv(struct p1905_managerd_ctx *ctx, unsigned char *bssid, unsigned char *sta_mac,
			unsigned short len, unsigned char *value)
{
	unsigned char *temp_buf = value;

	if (len != 12) {
		debug(DEBUG_ERROR, "length(%d) error\n", len);
		return -1;
	}

	debug(DEBUG_TRACE, "BSSID ("MACSTR") ", PRINT_MAC(temp_buf));
	memcpy(bssid, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;
	debug(DEBUG_TRACE, "client ("MACSTR")\n", PRINT_MAC(temp_buf));
	memcpy(sta_mac, temp_buf, ETH_ALEN);

	return 0;
}

int parse_channel_preference_tlv(struct p1905_managerd_ctx *ctx,
					struct list_head_ch_prefer *ch_prefer_head,
					unsigned short len, unsigned char *value)
{
	if (ctx->MAP_Cer) {
		/*insert new channel preference info*/
		if (insert_new_ch_prefer_info(ch_prefer_head, len, value) < 0) {
			debug(DEBUG_ERROR, "insert_new_ch_prefer_info fail\n");
			return -1;
		}
	}

	return 0;
}

int parse_transmit_power_limit_tlv(struct p1905_managerd_ctx *ctx, unsigned short len, unsigned char *value)
{
	if (len != 7) {
		debug(DEBUG_ERROR, "length error not eaqual 7\n");
		return -1;
	}

	return 0;
}

int parse_steering_request_tlv(struct p1905_managerd_ctx *ctx,
	unsigned short len, unsigned char *val, struct err_sta_db *err_sta)
{
#ifdef MAP_R2
	unsigned char *temp_buf = val;

	struct assoc_client *client = NULL;
	struct err_sta_mac_db *err_mac = NULL;
	unsigned char sta_count = 0;
	unsigned char assoc_bssid[ETH_ALEN];
	unsigned char req_mode = 0;
	int i = 0;
	int left = len;

	if (left - ETH_ALEN - 6 < 0) {
		debug(DEBUG_ERROR, "pre length check for steering request fail\n");
		return -1;
	}
	memcpy(assoc_bssid, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;

	req_mode = (*temp_buf & 0x80) ? 1 : 0;
	if (req_mode == 0)
		return 0;
	temp_buf += 1;

	/*skip Steering Opportunity window*/
	temp_buf += 2;

	/*skip BTM Disassociation Timer*/
	temp_buf += 2;

	sta_count = *temp_buf++;
	left -= (ETH_ALEN + 6);


	if (left - sta_count * ETH_ALEN < 0) {
		debug(DEBUG_ERROR, "pre length check for steering request fail\n");
		return -1;
	}
	for (i = 0; i < sta_count; i++) {
		client = get_assoc_cli_by_mac(ctx, temp_buf);
		if (!client || client->disassoc || os_memcmp(client->bssid, assoc_bssid, ETH_ALEN)) {
			err_mac = (struct err_sta_mac_db *)os_malloc(sizeof(struct err_sta_mac_db));
			if (!err_mac) {
				debug(DEBUG_ERROR, "alloc err_sta_mac_db fail\n");
				continue;
			}
			os_memset(err_mac, 0, sizeof(struct err_sta_mac_db));
			os_memcpy(err_mac->mac_addr, temp_buf, ETH_ALEN);
			debug(DEBUG_OFF,
				"mac("MACSTR") error in STEERING_REQUEST_TYPE tlv, need send error tlv in 1905 ack\n",
				PRINT_MAC(temp_buf));
			err_sta->err_sta_cnt++;
			SLIST_INSERT_HEAD(&err_sta->err_sta_head, err_mac, err_sta_mac_entry);
		}
		temp_buf += ETH_ALEN;
	}
#endif

	return 0;
}

int parse_steering_policy_tlv(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{
	unsigned char *temp_buf;
	unsigned short length = 0;

	temp_buf = buf;

	if((*temp_buf) == STEERING_POLICY_TYPE) {
		temp_buf++;
	}
	else {
		return -1;
	}

	//calculate tlv length
	length = *(unsigned short *)temp_buf;
	length = be_to_host16(length);

	return (length+3);
}

int parse_cli_assoc_control_request_tlv(struct p1905_managerd_ctx *ctx,
	unsigned short len, unsigned char *val, struct control_policy *steer_cntrl)
{
	unsigned char *temp_buf = val;
	struct control_policy_db *policy = NULL;
	struct sta_db *sta = NULL;
	unsigned int i = 0;
	int left = len;

	if (!steer_cntrl)
		goto err;
	if (left - ETH_ALEN - 4 < 0) {
		debug(DEBUG_ERROR, "pre length check for cli assoc control request fail\n");
		goto err;
	}
	policy = (struct control_policy_db *)malloc(sizeof(*policy));
	if (!policy) {
		debug(DEBUG_ERROR, "policy fail to alloc memory!\n");
		goto err;
	}
	memcpy(policy->bssid, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;
	policy->assoc_control = *temp_buf++;
	policy->valid_period = *(unsigned short *)temp_buf;
	policy->valid_period = be_to_host16(policy->valid_period);
	temp_buf += 2;
	policy->sta_list_count = *temp_buf++;
	SLIST_INSERT_HEAD(&steer_cntrl->policy_head, policy, policy_entry);
	steer_cntrl->policy_cnt++;
	left -= (ETH_ALEN + 4);

	SLIST_INIT(&policy->sta_head);
	if (left - policy->sta_list_count * ETH_ALEN < 0) {
		debug(DEBUG_ERROR, "pre length check for sta fail\n");
		goto err;
	}
	for(i = 0; i < policy->sta_list_count; i++) {
		sta = (struct sta_db *)malloc(sizeof(*sta));
		if (!sta) {
			debug(DEBUG_ERROR, "sta fail to alloc memory!\n");
			goto err;
		}
		memcpy(sta->mac, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;
		SLIST_INSERT_HEAD(&policy->sta_head, sta, sta_entry);
	}

	return 0;
err:
	return -1;

}

int parse_metric_reporting_policy_tlv(struct p1905_managerd_ctx *ctx,
	unsigned short len, unsigned char *val, struct metrics_policy *mpolicy)
{
	unsigned char *temp_buf = val;
	unsigned short i = 0;
	struct metric_policy_db *metric_policy = NULL;
	int left = len;

	if (left - 2 < 0) {
		debug(DEBUG_ERROR, "pre length check for metric report policy fail\n");
		return -1;
	}
	if (!mpolicy) {
		debug(DEBUG_ERROR, "input mpolicy is null\n");
		return -1;
	}
	mpolicy->report_interval = *temp_buf++;

	/* workaround for checking ap metrics response
	** ucc set report_interval as 5 sec
	** 1905 send ap metrics response after 5sec, sniffer fail to capture
	*/
	if (ctx->MAP_Cer &&
		(mpolicy->report_interval >= 5)) {
		/* ucc check ap metrics response in 5 sec */
		mpolicy->report_interval -= 1;
	}
	debug(DEBUG_TRACE, "report_interval(%d)\n", mpolicy->report_interval);

	mpolicy->radio_num = *temp_buf++;
	left -= 2;

	if (left - mpolicy->radio_num * 10 < 0) {
		debug(DEBUG_ERROR, "pre length check for radio fail\n");
		return -1;
	}
	for (i = 0; i < mpolicy->radio_num; i++) {
		metric_policy = (struct metric_policy_db *)malloc(sizeof(struct metric_policy_db));
		if (!metric_policy) {
			debug(DEBUG_ERROR, "alloc struct metric_policy_db fail\n");
			return -1;
		}
		memcpy(metric_policy->identifier, temp_buf, ETH_ALEN);

		debug(DEBUG_TRACE, "identifier("MACSTR")\n",
			PRINT_MAC(metric_policy->identifier));
		temp_buf += ETH_ALEN;
		metric_policy->rssi_thres = *temp_buf++;
		metric_policy->hysteresis_margin = *temp_buf++;
		metric_policy->ch_util_thres = *temp_buf++;
		metric_policy->sta_stats_inclusion = *temp_buf & 0x80;
		metric_policy->sta_metrics_inclusion = *temp_buf & 0x40;
#ifdef MAP_R3_WF6
		metric_policy->assoc_wf6_inclusion = *temp_buf & 0x20;
#endif
		debug(DEBUG_TRACE, "rssi_thres(%d) hysteresis_margin(%d) ch_util_thres(%d) "
			"sta_stats_inclusion(%d) sta_metrics_inclusion(%d)\n"
#ifdef MAP_R3_WF6
			"sta_wifi6_sta_status_inclusion(%d) "
#endif
			"\n",
			metric_policy->rssi_thres,
			metric_policy->hysteresis_margin,
			metric_policy->ch_util_thres,
			metric_policy->sta_stats_inclusion,
			metric_policy->sta_metrics_inclusion
#ifdef MAP_R3_WF6
			, metric_policy->assoc_wf6_inclusion
#endif
			);
		temp_buf += 1;
		SLIST_INSERT_HEAD(&mpolicy->policy_head, metric_policy, policy_entry);
	}

	return 0;
}

int parse_ap_metrics_query_tlv(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{
	unsigned char *temp_buf = NULL;
	unsigned short length = 0;

	temp_buf = buf;

	if((*temp_buf) == AP_METRICS_QUERY_TYPE) {
		temp_buf++;
	}
	else {
		return -1;
	}

	//calculate tlv length
	length = *(unsigned short *)temp_buf;
	length = be_to_host16(length);

	return (length+3);
}

int parse_associated_sta_link_metrics_query_tlv(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{
	unsigned char *temp_buf = NULL;
	unsigned short length = 0;

	temp_buf = buf;

	if((*temp_buf) == STA_MAC_ADDRESS_TYPE) {
		temp_buf++;
	}
	else {
		return -1;
	}

	//calculate tlv length
	length = *(unsigned short *)temp_buf;
	length = be_to_host16(length);

	return (length+3);
}

int parse_associated_sta_link_metrics_rsp_tlv(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{
	unsigned char *temp_buf = NULL;
	unsigned short length = 0;

	temp_buf = buf;

	if((*temp_buf) == ASSOC_STA_LINK_METRICS_TYPE)
		temp_buf++;
	else
		return -1;

	//calculate tlv length
	length = *(unsigned short *)temp_buf;
	length = be_to_host16(length);

	return (length+3);
}

int parse_error_code_tlv(struct p1905_managerd_ctx *ctx, unsigned short len, unsigned char *value)
{
	if (len != 7)
		return -1;

	return 0;
}

int parse_unassociated_sta_link_metrics_query_tlv(struct p1905_managerd_ctx *ctx,
	unsigned short len, unsigned char *val)
{
	unsigned char *temp_buf = val;
	unsigned short query_len = 0;
	unsigned char opclass = 0, num_sta = 0, num_ch = 0;
	unsigned char channels[MAX_CH_NUM] = { 0 };
	struct unlink_metrics_query *unlink_query = NULL;
	int left = len;

	if (left - 2 < 0) {
		debug(DEBUG_ERROR, "pre length check for opclass/ch num fail\n");
		goto err0;
	}
	opclass = *temp_buf++;
	num_ch = *temp_buf++;
	if (num_ch == 0 || num_ch > 13) {
		debug(DEBUG_ERROR, "invalid ch num(%d)\n", num_ch);
		goto err0;
	}
	left -= 2;

	if (left - num_ch < 0) {
		debug(DEBUG_ERROR, "pre length check for channels fail\n");
		goto err0;
	}
	memcpy(channels, temp_buf, num_ch);
	temp_buf += num_ch;
	left -= num_ch;

	if (left - 1 < 0) {
		debug(DEBUG_ERROR, "pre length check for sta num fail\n");
		goto err0;
	}
	num_sta = *temp_buf++;
	if (num_sta == 0) {
		debug(DEBUG_ERROR, "invalid sta num(0)\n");
		goto err0;
	}
	left -= 1;

	query_len = sizeof(struct unlink_metrics_query) + num_sta * ETH_ALEN;
	if (ctx->metric_entry.unlink_query) {
		free(ctx->metric_entry.unlink_query);
		ctx->metric_entry.unlink_query = NULL;
	}

	ctx->metric_entry.unlink_query = (struct unlink_metrics_query *)os_zalloc(query_len);
	if (!ctx->metric_entry.unlink_query) {
		debug(DEBUG_ERROR, "alloc ctx->metric_entry.unlink_query fail\n");
		goto err0;
	}
	unlink_query = ctx->metric_entry.unlink_query;
	unlink_query->oper_class = opclass;
	unlink_query->ch_num = num_ch;
	memcpy(unlink_query->ch_list, channels, num_ch);

	if (left - num_sta * ETH_ALEN < 0) {
		debug(DEBUG_ERROR, "pre length check for sta fail\n");
		goto err1;
	}
	unlink_query->sta_num = num_sta;
	memcpy(unlink_query->sta_list, temp_buf, unlink_query->sta_num * ETH_ALEN);

	return 0;

err1:
	if (ctx->metric_entry.unlink_query) {
		free(ctx->metric_entry.unlink_query);
		ctx->metric_entry.unlink_query = NULL;
	}
err0:
	return -1;
}

int parse_beacon_metrics_query_tlv(struct p1905_managerd_ctx *ctx,
	unsigned short len, unsigned char *val)
{
	unsigned char *temp_buf = val;
	unsigned short query_len = 0;
	struct beacon_metrics_query *bcn_query = NULL;
	unsigned char bssid[ETH_ALEN] = {0};
	unsigned char sta_mac[ETH_ALEN] = {0};
	unsigned char ssid[33] = {0};
	unsigned char opclass = 0, ch = 0, rpt_detail = 0;
	unsigned char ssid_len = 0, num_chrep = 0;
	unsigned char i = 0;
	struct ap_chn_rpt *chn_rpt = NULL;
	int left = len;

	if (left - ETH_ALEN - 2 - ETH_ALEN - 2 < 0) {
		debug(DEBUG_ERROR, "pre length check for beacon metrics query fail\n");
		goto err0;
	}

	memcpy(sta_mac, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;

	/*opclass*/
	opclass = *temp_buf++;
	/*channel number*/
	ch = *temp_buf++;
	/*bssid*/
	memcpy(bssid, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;
	/*Reporting Detail value*/
	rpt_detail = *temp_buf++;
	/*ssid len & ssid*/
	ssid_len = *temp_buf++;
	left -= (ETH_ALEN + 2 + ETH_ALEN + 2);

	if (left - ssid_len - 1 < 0) {
		debug(DEBUG_ERROR, "pre length check for ssid/ch report fail\n");
		goto err0;
	}
	memcpy(ssid, temp_buf, ssid_len);
	temp_buf += ssid_len;
	/*Number of AP Channel Reports*/
	num_chrep = *temp_buf++;
	left -= (ssid_len + 1);

	query_len = sizeof(struct beacon_metrics_query) +
		num_chrep * sizeof(struct ap_chn_rpt);
	if (ctx->metric_entry.bcn_query) {
		free(ctx->metric_entry.bcn_query);
		ctx->metric_entry.bcn_query = NULL;
	}
	ctx->metric_entry.bcn_query = (struct beacon_metrics_query *)malloc(query_len);
	if (!ctx->metric_entry.bcn_query) {
		debug(DEBUG_ERROR, "alloc struct beacon_metrics_query fail\n");
		goto err0;
	}
	bcn_query = ctx->metric_entry.bcn_query;

	memset(bcn_query, 0, query_len);
	memcpy(bcn_query->sta_mac, sta_mac, ETH_ALEN);
	bcn_query->oper_class = opclass;
	bcn_query->ch = ch;
	memcpy(bcn_query->bssid, bssid, ETH_ALEN);
	bcn_query->rpt_detail_val = rpt_detail;
	bcn_query->ssid_len = ssid_len;
	memcpy(bcn_query->ssid, ssid, ssid_len);
	bcn_query->ap_ch_rpt_num = num_chrep;
	chn_rpt = bcn_query->rpt;
	for (i = 0; i < num_chrep; i++) {
		if (left - 1 < 0) {
			debug(DEBUG_ERROR, "pre length check for ch_rpt len fail\n");
			goto err1;
		}
		/*ap channel report info*/
		chn_rpt->ch_rpt_len = *temp_buf++;
		if (chn_rpt->ch_rpt_len - 1 > MAX_CH_NUM) {
			debug(DEBUG_ERROR, "invalid ch count(%d)\n", chn_rpt->ch_rpt_len - 1);
			goto err1;
		}
		left -= 1;

		if (left - chn_rpt->ch_rpt_len < 0) {
			debug(DEBUG_ERROR, "pre length check for ch_rpt/opclass fail\n");
			goto err1;
		}
		chn_rpt->oper_class = *temp_buf++;
		memcpy(chn_rpt->ch_list, temp_buf, chn_rpt->ch_rpt_len - 1);
		temp_buf += chn_rpt->ch_rpt_len - 1;
		left -= chn_rpt->ch_rpt_len;
		chn_rpt++;
	}

	/*element IDs*/
	if (left - 1 < 0) {
		debug(DEBUG_ERROR, "pre length check for elemnt IDs fail\n");
		goto err1;
	}
	bcn_query->elemnt_num = *temp_buf++;
	left -= 1;

	if (left - bcn_query->elemnt_num < 0) {
		debug(DEBUG_ERROR, "pre length check for elemnt List fail\n");
		goto err1;
	}
	if (bcn_query->elemnt_num > MAX_ELEMNT_NUM)
		bcn_query->elemnt_num = MAX_ELEMNT_NUM;
	memcpy(bcn_query->elemnt_list, temp_buf, bcn_query->elemnt_num);

	return 0;
err1:
	if (ctx->metric_entry.bcn_query) {
		free(ctx->metric_entry.bcn_query);
		ctx->metric_entry.bcn_query = NULL;
	}
err0:
	return -1;
}

int parse_assoc_sta_link_metrics_tlv(struct p1905_managerd_ctx* ctx, unsigned char *buf)
{
    unsigned char *temp_buf;
    unsigned short length = 0;

    temp_buf = buf;

    if((*temp_buf) == ASSOC_STA_LINK_METRICS_TYPE) {
        temp_buf++;
    } else {
        return -1;
    }

    //calculate tlv length
    length = *(unsigned short *)temp_buf;
    length = be_to_host16(length);

    return (length+3);
}

int parse_assoc_sta_traffic_stats_tlv(struct p1905_managerd_ctx* ctx, unsigned char *buf)
{
    unsigned char *temp_buf;
    unsigned short length = 0;

    temp_buf = buf;

    if((*temp_buf) == ASSOC_STA_TRAFFIC_STATS_TYPE) {
        temp_buf++;
    } else {
        return -1;
    }

    //calculate tlv length
    length = *(unsigned short *)temp_buf;
    length = be_to_host16(length);

	temp_buf += ETH_ALEN + 2;
	*((unsigned int*)temp_buf) = be_to_host32(*((unsigned int*)temp_buf));
	temp_buf += sizeof(unsigned int);
	*((unsigned int*)temp_buf) = be_to_host32(*((unsigned int*)temp_buf));
	temp_buf += sizeof(unsigned int);
	*((unsigned int*)temp_buf) = be_to_host32(*((unsigned int*)temp_buf));
	temp_buf += sizeof(unsigned int);
	*((unsigned int*)temp_buf) = be_to_host32(*((unsigned int*)temp_buf));
	temp_buf += sizeof(unsigned int);
	*((unsigned int*)temp_buf) = be_to_host32(*((unsigned int*)temp_buf));
	temp_buf += sizeof(unsigned int);
	*((unsigned int*)temp_buf) = be_to_host32(*((unsigned int*)temp_buf));
	temp_buf += sizeof(unsigned int);
	*((unsigned int*)temp_buf) = be_to_host32(*((unsigned int*)temp_buf));
	temp_buf += sizeof(unsigned int);
    return (length+3);
}

int parse_tx_link_metrics_tlv(struct p1905_managerd_ctx* ctx, unsigned char *buf,
	struct list_head_tx_metrics_agent *tx_metrics_head)
{
    unsigned char *temp_buf;
    unsigned short length = 0;

    temp_buf = buf;

    if((*temp_buf) == TRANSMITTER_LINK_METRIC_TYPE)
        temp_buf++;
    else
        return -1;

    //calculate tlv length
    length = *(unsigned short *)temp_buf;
    length = be_to_host16(length);

    return (length+3);
}

int parse_rx_link_metrics_tlv(struct p1905_managerd_ctx* ctx, unsigned char *buf,
	struct list_head_rx_metrics_agent *rx_metrics_head)
{
    unsigned char *temp_buf;
    unsigned short length = 0;

    temp_buf = buf;

    if((*temp_buf) == RECEIVER_LINK_METRIC_TYPE)
        temp_buf++;
    else
        return -1;

    //calculate tlv length
    length = *(unsigned short *)temp_buf;
    length = be_to_host16(length);

    return (length+3);
}

int parse_ap_capability_tlv(struct p1905_managerd_ctx *ctx,
				unsigned short len, unsigned char *value, unsigned char *ap_cap)
{
	if (len != 1)
		return -1;

	*ap_cap = *value;

	return 0;
}

int parse_ap_ht_capability_tlv(struct p1905_managerd_ctx *ctx,
				unsigned short len, unsigned char *value)
{
	if (len != 7)
		return -1;

	/* mapd parse */

	return 0;
}

int parse_ap_vht_capability_tlv(struct p1905_managerd_ctx *ctx,
				unsigned short len, unsigned char *value)
{
	if (len != 12)
		return -1;

	/* mapd parse */

	return 0;
}


int parse_unassociated_sta_link_metrics_rsp_tlv(struct p1905_managerd_ctx *ctx,
	unsigned char *buf)
{
    unsigned char *temp_buf;
    unsigned short length = 0;

    temp_buf = buf;

    if((*temp_buf) == UNASSOC_STA_LINK_METRICS_RSP_TYPE) {
        temp_buf++;
    }
    else {
        return -1;
    }

    //calculate tlv length
    length = *(unsigned short *)temp_buf;
    length = be_to_host16(length);

    return (length+3);
}



int parse_beacon_metrics_rsp_tlv(struct p1905_managerd_ctx *ctx,
	unsigned char *buf)
{
    unsigned char *temp_buf;
    unsigned short length = 0;

    temp_buf = buf;

    if((*temp_buf) == BEACON_METRICS_RESPONSE_TYPE) {
        temp_buf++;
    }
    else {
        return -1;
    }

    //calculate tlv length
    length = *(unsigned short *)temp_buf;
    length = be_to_host16(length);

    return (length+3);
}

#ifdef MAP_R2
int parse_ap_operational_bss_tlv(struct p1905_managerd_ctx *ctx, unsigned char *almac,
		unsigned short len, unsigned char *value, struct dl_list *bss_list)
{
	unsigned char *temp_buf = value;
	int left = len;
	unsigned char radio_num = 0, bss_num = 0, ssid_len = 0;
	struct operational_bss *bss = NULL;
	unsigned char mac[ETH_ALEN] = {0x00};
	char ssid[33];

	if (left < 1)
		return -1;
	left--;

	radio_num = *temp_buf++;
	while (radio_num--) {
		if (left < 7) {
			debug(DEBUG_ERROR, "%d: error left %d less than %d\n", __LINE__, left, 7);
			return -1;
		}
		left -= 7;

		temp_buf += ETH_ALEN;

		bss_num = *temp_buf++;
		while(bss_num--) {
			if (left < 7) {
				debug(DEBUG_ERROR, "%d: error left %d less than %d\n", __LINE__, left, 7);
				return -1;
			}
			left -= 7;

			os_memset(ssid, 0, sizeof(ssid));
			os_memcpy(mac, temp_buf, ETH_ALEN);
			temp_buf += ETH_ALEN;

			ssid_len = *temp_buf++;
			if (ssid_len > SSID_MAX_LEN) {
				debug(DEBUG_ERROR, "fail to parse ssid because ssid_len (%d) is bigger than ssid buf \n", ssid_len);
				return -1;
			}
			if (left < ssid_len) {
				debug(DEBUG_ERROR, "%d: error left %d less than %d\n", __LINE__, left, ssid_len);
				return -1;
			}
			left -= ssid_len;

			os_memcpy(ssid, temp_buf, ssid_len);
			temp_buf += ssid_len;
			bss = get_bss_by_bssid(ctx, mac);
			if (!bss) {
				bss = create_oper_bss(ctx, mac, ssid, ssid_len, almac, bss_list);
				if (!bss) {
					debug(DEBUG_ERROR, "fail to allocate memory for opertational bss\n");
					continue;
				}
			} else {
				if (os_strncmp(bss->ssid, ssid, ssid_len) ||
					ssid_len != os_strlen(bss->ssid)) {
					os_memset(bss->ssid, 0, sizeof(bss->ssid));
					os_strncpy(bss->ssid, ssid, ssid_len);
				}
			}
		}
	}

	return 0;
}

int parse_assoc_clients_tlv(struct p1905_managerd_ctx *ctx, unsigned char *al_mac,
		unsigned short len, unsigned char *value, struct dl_list *clients_table)
{
	unsigned char *temp_buf = value;
	int left = len;
	unsigned char bss_num = 0;
	unsigned short client_num = 0;
	unsigned char mac[ETH_ALEN], bssid[ETH_ALEN];
	struct assoc_client *p_client = NULL;

	if (left < 1)
		return -1;
	left--;

	bss_num = *temp_buf++;

	while(bss_num--) {
		if (left < ETH_ALEN + 2) {
			debug(DEBUG_ERROR, "%d: error left %d less than %d\n", __LINE__, left, ETH_ALEN + 2);
			return -1;
		}
		left -= ETH_ALEN + 2;

		os_memcpy(bssid, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;

		client_num = be_to_host16(*(unsigned short*)temp_buf);
		temp_buf += 2;

		if (left < (ETH_ALEN + 2) * client_num) {
			debug(DEBUG_ERROR, "%d: error left %d less than %d\n", __LINE__, left, (ETH_ALEN + 2) * client_num);
			return -1;
		}
		left -= (ETH_ALEN + 2) * client_num;

		while (client_num--) {
			os_memcpy(mac, temp_buf, ETH_ALEN);
			temp_buf += ETH_ALEN;

			temp_buf += 2;
			p_client = get_cli_by_mac(clients_table, mac);
			if (!p_client) {
				p_client = add_new_assoc_cli(clients_table, mac, al_mac);

				if (!p_client) {
					debug(DEBUG_ERROR, "fail to allocate memory for assoc client("MACSTR")\n",
						PRINT_MAC(mac));
					continue;
				}
			}
			os_memcpy(p_client->bssid, bssid, ETH_ALEN);
		}
	}

	return 0;
}

int parse_traffic_separation_policy_tlv(
	struct traffics_policy *tpolicy,
	unsigned short len, unsigned char *val)
{
	unsigned char *temp_buf = val;
	unsigned short i = 0;
	struct traffic_separation_db *tpolicy_db = NULL;
	unsigned char ssidbuf[SSID_MAX_LEN + 1] = {0};
	int left = len;

	if (left - 1 < 0) {
		debug(DEBUG_ERROR, "pre length check for traffic separation policy fail\n");
		goto err0;
	}

	tpolicy->SSID_num = *temp_buf++;
	debug(DEBUG_ERROR, "SSID_num(%d)\n", tpolicy->SSID_num);
	left -= 1;

	for (i = 0; i < tpolicy->SSID_num; i++) {
		if (left - 1 < 0) {
			debug(DEBUG_ERROR, "pre length check for ssid len fail\n");
			goto err0;
		}
		tpolicy_db = (struct traffic_separation_db *)os_zalloc(sizeof(struct traffic_separation_db));
		if (!tpolicy_db) {
			debug(DEBUG_ERROR, "alloc struct traffic_separation_db fail\n");
			goto err0;
		}
		tpolicy_db->SSID_len = *temp_buf++;
		if (tpolicy_db->SSID_len > SSID_MAX_LEN) {
			debug(DEBUG_ERROR, "SSID_len(%d) is large than 32 bytes\n", tpolicy_db->SSID_len);
			goto err1;
		}
		debug(DEBUG_ERROR, "SSID_len(%d)\n", tpolicy_db->SSID_len);
		left -= 1;

		if (left - tpolicy_db->SSID_len < 0) {
			debug(DEBUG_ERROR, "pre length check for ssid fail\n");
			goto err1;
		}
		tpolicy_db->SSID = os_zalloc(tpolicy_db->SSID_len + 1);
		if (!tpolicy_db->SSID) {
			debug(DEBUG_ERROR, "kmalloc for trffic_policy->SSID fail\n");
			goto err1;
		}
		os_memset(tpolicy_db->SSID, 0, tpolicy_db->SSID_len + 1);
		os_memcpy(tpolicy_db->SSID, temp_buf, tpolicy_db->SSID_len);
		os_memset(ssidbuf, 0, SSID_MAX_LEN + 1);
		os_memcpy(ssidbuf, tpolicy_db->SSID, tpolicy_db->SSID_len);
		temp_buf += tpolicy_db->SSID_len;
		left -= tpolicy_db->SSID_len;

		if (left - 2 < 0) {
			debug(DEBUG_ERROR, "pre length check for vid fail\n");
			goto err1;
		}
		tpolicy_db->vid = *((unsigned short *)temp_buf);
		tpolicy_db->vid = be_to_host16(tpolicy_db->vid);
		temp_buf += 2;
		debug(DEBUG_ERROR, "parse:%s, %d\n", ssidbuf, tpolicy_db->vid);
		left -= 2;
		SLIST_INSERT_HEAD(&tpolicy->policy_head, tpolicy_db, policy_entry);
	}

	return 0;

err1:
	if (tpolicy_db) {
		if (tpolicy_db->SSID) {
			free(tpolicy_db->SSID);
			tpolicy_db->SSID = NULL;
		}
		free(tpolicy_db);
	}
err0:
	return -1;

}

int parse_default_802_1q_setting_tlv(
	struct def_8021q_setting *setting,
	unsigned short len, unsigned char *val)
{
	unsigned char *temp_buf = val;
	unsigned short left = len;

	if (left < (sizeof(*setting)-1)) {
		debug(DEBUG_ERROR, "pre length check for default 802_1q fail\n");
		return -1;
	}
	memcpy(setting, temp_buf, sizeof(*setting));
	setting->primary_vid = be_to_host16(setting->primary_vid);
	debug(DEBUG_ERROR, "primary_vid:%d pcp:%d, length=%d\n",
				setting->primary_vid, setting->dft.PCP, len);

	return 0;
}

int parse_ap_radio_advanced_capability_tlv(struct p1905_managerd_ctx *ctx,
		unsigned char *almac, struct ts_cap_db **ts_cap, unsigned short len, unsigned char *value)
{
	unsigned char *temp_buf = value;
	struct agent_list_db *agent_info = NULL;
	struct ts_cap_db *ts_cap_tmp = NULL;

	if (!temp_buf || !ctx || !almac || !ts_cap) {
		debug(DEBUG_ERROR, "params null!!! value(%p) ctx(%p) almac(%p) ts_cap(%p)\n",
			temp_buf, ctx, almac, ts_cap);
		return -1;
	}

	if (len != 7) {
		debug(DEBUG_ERROR, "tlv length error!!! length should be 7 but is %d\n", len);
		return -1;
	}

	/*fill in agent Profile-2 AP Capability*/
	find_agent_info(ctx, almac, &agent_info);
	if (!agent_info) {
		debug(DEBUG_ERROR, "error! no agent info exist try to insert a new.\n");
		agent_info = insert_agent_info(ctx, almac);
		if (!agent_info) {
			debug(DEBUG_ERROR, "insert new agent info failed.\n");
			return -1;
		}
	}

	SLIST_FOREACH(ts_cap_tmp, &agent_info->ts_cap_head, ts_cap_entry)
	{
		if (!os_memcmp(ts_cap_tmp->identifier, temp_buf, ETH_ALEN)) {
			temp_buf += ETH_ALEN;
			ts_cap_tmp->ts_combined_fh = *temp_buf & 0x80;
			ts_cap_tmp->ts_combined_bh = *temp_buf & 0x40;
			temp_buf++;
			break;
		}
	}
	if (!ts_cap_tmp) {
		ts_cap_tmp = (struct ts_cap_db *)os_zalloc(sizeof(struct ts_cap_db));
		if (!ts_cap_tmp) {
			debug(DEBUG_ERROR, "alloc struct ts_cap_db fail\n");
			return -1;
		}
		os_memcpy(ts_cap_tmp->identifier, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;
		ts_cap_tmp->ts_combined_fh = *temp_buf & 0x80;
		ts_cap_tmp->ts_combined_bh = *temp_buf & 0x40;
		temp_buf++;
		SLIST_INSERT_HEAD(&agent_info->ts_cap_head, ts_cap_tmp, ts_cap_entry);
	}

	*ts_cap=ts_cap_tmp;

	return 0;
}


int parse_r2_ap_capability_tlv(struct ap_r2_capability *r2_cap, unsigned char *almac,
				  unsigned short len, unsigned char *value)
{
#define R2_AP_CABABILITY_TLV_LEN 4
	unsigned char *temp_buf = value;

	if (len != R2_AP_CABABILITY_TLV_LEN)
		return -1;

	/*fill in agent Profile-2 AP Capability*/
	os_memset(r2_cap, 0, sizeof(struct ap_r2_capability));
	/* Max Total Number Service Prioritization Rules*/
	r2_cap->max_total_num_sp_rules = *temp_buf;
	temp_buf++;

	/*skip Reserved byte*/
	temp_buf++;

	/*parse capa bit map*/
	if (*temp_buf & 0x40)
		r2_cap->byte_counter_units = 1;
	else if (*temp_buf & 0x80)
		r2_cap->byte_counter_units = 2;

	if (*temp_buf & 0x20)
		r2_cap->sp_flag = 1;
	if (*temp_buf & 0x10)
		r2_cap->dpp_flag = 1;
	if (*temp_buf & 0x08)
		r2_cap->ts_flag = 1;
	temp_buf++;

	/*Max Total Number of VIDs.*/
	r2_cap->max_total_num_vid = *temp_buf;
	temp_buf++;

	debug(DEBUG_TRACE, "agent("MACSTR") sp_num: %d, dpp_flag:%d, sp_flag:%d, ts_flag:%d, byte_units:%d, num_vid:%d\n",
		PRINT_MAC(almac), r2_cap->max_total_num_sp_rules,
		r2_cap->dpp_flag, r2_cap->sp_flag, r2_cap->ts_flag,
		r2_cap->byte_counter_units, r2_cap->max_total_num_vid);

	return 0;
}
#endif

#ifdef MAP_R3
/*MAP dpp protocol defined TLV parsing*/
int parse_controller_cap_tlv(unsigned char *buf, struct controller_capability *contr_cap)
{
	unsigned char *temp_buf;
	unsigned short length = 0;

	temp_buf = buf;

	if ((*temp_buf) == CONTROLLER_CAPABILITY_TYPE)
		temp_buf++;
	else
		return -1;

	length = *(unsigned short *)temp_buf;
	length = be_to_host16(length);
	temp_buf += 2;

	if (*temp_buf & 0x80)
		contr_cap->kibmib = 1;
	else
		contr_cap->kibmib = 0;

	if (*temp_buf & 0x40)
		contr_cap->early_apcap = 1;
	else
		contr_cap->early_apcap = 0;

	return (length+3);
}

int parse_proxied_encap_dpp_type_tlv(unsigned char *buf, unsigned short len,
	unsigned char *frame_type, unsigned short *frame_offset, unsigned short *frame_len)
{
	unsigned short left = len;
	unsigned char *temp_buf;
	unsigned char *p_bitmap = NULL;
	unsigned char sta_mac[ETH_ALEN];

	temp_buf = buf;

	if (left < 1) {
		debug(DEBUG_ERROR, "[%d] Error left_tlv_length %d less than %d\n",
			  __LINE__, left, 1);
		return -1;
	}

	p_bitmap = temp_buf++;
	left -= 1;


	/* Enrollee MAC address.
	** (This field is present if the Final destination field is set to 0)
	*/
	if (*p_bitmap & 0x80) {
		if (left < ETH_ALEN) {
			debug(DEBUG_ERROR, "[%d] Error left_tlv_length %d less than %d\n",
				  __LINE__, left, ETH_ALEN);
			return -1;
		}
		memcpy(sta_mac, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;
		left -= ETH_ALEN;
	}

	if (left < 3) {
		debug(DEBUG_ERROR, "[%d] Error left_tlv_length %d less than %d\n",
			  __LINE__, left, 3);
		return -1;
	}
	*frame_type = *temp_buf++;
	*frame_len = *((unsigned short *)temp_buf);
	*frame_len = be_to_host16(*frame_len);
	temp_buf += 2;
	left -= 3;

	if (left < *frame_len) {
		debug(DEBUG_ERROR, "[%d] Error left_tlv_length %d less than %d\n",
			  __LINE__, left, *frame_len);
		return -1;
	}
	*frame_offset = temp_buf - buf;

	/*DPP Frame
	**
		0: DPP public action frame
		1: GAS frame
	*/
	if (*p_bitmap & 0x20 || *frame_type == 0xFF) {
		debug(DEBUG_OFF, "[dpp in 1905]GAS frame %s\n", GasFrame_actionNum2str(*temp_buf));
	} else {
		debug(DEBUG_OFF, "[dpp in 1905]Action Frame %s\n", actionFrame_typeNum2str(*(temp_buf+6)));
	}

	return 0;
}

int parse_dpp_chirp_value_tlv(
	unsigned char *buf, unsigned short len, struct chirp_tlv_info *chirp)
{
	unsigned short left = len;
	unsigned char *temp_buf;
	unsigned char bitmap = 0;

	temp_buf = buf;
	if (left < 1) {
		debug(DEBUG_ERROR, "[%d] Error left_tlv_length %d less than %d\n",
			  __LINE__, left, 1);
		return -1;
	}

	bitmap = *temp_buf++;
	left -= 1;

	/* Enrollee MAC Address Present field */
	if (bitmap & 0x80) {
		if (left < ETH_ALEN) {
			debug(DEBUG_ERROR, "[%d] Error left_tlv_length %d less than %d\n",
				  __LINE__, left, ETH_ALEN);
			return -1;
		}
		/* reconfiguration hash */
		chirp->enrollee_mac_address_present = 1;

		os_memcpy(chirp->enrollee_mac, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;
		left -= ETH_ALEN;
		debug(DEBUG_ERROR, "[dpp in 1905]enrollee mac present 1 \n");
		debug(DEBUG_ERROR, "[dpp in 1905]enrollee mac "MACSTR" \n", MAC2STR(chirp->enrollee_mac));
	} else {
		/* bootstrapping hash */
		chirp->enrollee_mac_address_present = 0;
		debug(DEBUG_ERROR, "[dpp in 1905]enrollee mac present 0\n");
	}

	/* hash len + hash value */
	if (left < 1+32) {
		debug(DEBUG_ERROR, "[%d] Error left_tlv_length %d less than %d\n",
			  __LINE__, left, 1+32);
		return -1;
	}
	/* Hash Validity Bit */
	if (bitmap & 0x40) {
		/* establish DPP authentication state pertaining to the hash value in this TLV */
		chirp->hash_validity = 1;
	} else {
		/* purge any DPP authentication state pertaining to the hash value in this TLV */
		chirp->hash_validity = 0;
	}
	debug(DEBUG_ERROR, "[dpp in 1905]hash_validity %d \n", chirp->hash_validity);

	chirp->hash_len = (unsigned short)(*(temp_buf++));

	os_memcpy(chirp->hash_payload, temp_buf, chirp->hash_len);

	return 0;
}

int parse_akm_suit_capability_tlv(
	unsigned char *buf,
	unsigned short len,
	struct akm_suite_cap *bh_akm,
	struct akm_suite_cap *fh_akm)
{
	int left = len;
	unsigned char *temp_buf;
	unsigned char i =0;
	struct akm_suit *akm = NULL;

	temp_buf = buf;

	/* Num BH BSS AKM Suite Selectors	*/
	if (left < 1) {
		debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
			__LINE__, left, 1);
		goto fail;
	}
	bh_akm->akm_suite_cnt = *temp_buf++;
	left--;
	if (bh_akm->akm_suite_cnt > AKM_CNT_MAX) {
		debug(DEBUG_ERROR, "BH AKM Suite cnt(%d) too big\n", bh_akm->akm_suite_cnt);
		goto fail;
	}
	bh_akm->akm_suite_info = os_zalloc(bh_akm->akm_suite_cnt * sizeof(struct akm_suit));
	if (!bh_akm->akm_suite_info) {
		debug(DEBUG_ERROR, "malloc buf for akm BH fail\n");
		goto fail;
	}
	akm = bh_akm->akm_suite_info;
	debug(DEBUG_TRACE, "Num BH AKM Suite %d\n", bh_akm->akm_suite_cnt);
	for (i = 0; i < bh_akm->akm_suite_cnt; i++) {
		if (left < sizeof(struct akm_suit)) {
			debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
				__LINE__, left, (int)sizeof(struct akm_suit));
			goto fail;
		}
		os_memcpy(akm->oui, temp_buf, 3);
		temp_buf += 3;
		akm->akm_suit_type = *temp_buf++;
		debug(DEBUG_TRACE, "suite type %d, oui %02x%02x%02x\n",
			akm->akm_suit_type, akm->oui[0], akm->oui[1], akm->oui[2]);

		akm ++;
		left -= sizeof(struct akm_suit);
	}

	/* Num FH BSS AKM Suite Selectors	*/
	if (left < 1) {
		debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
			__LINE__, left, 1);
		goto fail;
	}
	fh_akm->akm_suite_cnt = *temp_buf++;
	left--;
	if (fh_akm->akm_suite_cnt > AKM_CNT_MAX) {
		debug(DEBUG_ERROR, "FH AKM Suite cnt(%d) too big\n", fh_akm->akm_suite_cnt);
		goto fail;
	}
	fh_akm->akm_suite_info = os_zalloc(fh_akm->akm_suite_cnt * sizeof(struct akm_suit));
	if (!fh_akm->akm_suite_info) {
		debug(DEBUG_ERROR, "malloc buf for akm FH fail\n");
		goto fail;
	}
	akm = fh_akm->akm_suite_info;
	debug(DEBUG_TRACE, "Num FH AKM Suite %d\n", fh_akm->akm_suite_cnt);
	for (i = 0; i < fh_akm->akm_suite_cnt; i++) {
		if (left < sizeof(struct akm_suit)) {
			debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
				__LINE__, left, (int)sizeof(struct akm_suit));
			goto fail;
		}
		os_memcpy(akm->oui, temp_buf, 3);
		temp_buf += 3;
		akm->akm_suit_type = *temp_buf++;
		debug(DEBUG_TRACE, "suite type %d, oui %02x%02x%02x\n",
			akm->akm_suit_type, akm->oui[0], akm->oui[1], akm->oui[2]);

		akm ++;
		left -= sizeof(struct akm_suit);
	}

	return 0;
fail:
	if (bh_akm->akm_suite_info) {
		os_free(bh_akm->akm_suite_info);
		bh_akm->akm_suite_info = NULL;
	}

	if (fh_akm->akm_suite_info) {
		os_free(fh_akm->akm_suite_info);
		fh_akm->akm_suite_info = NULL;
	}

	return -1;
}


int parse_bh_sta_radio_cap_tlv(unsigned char *buf, unsigned short len)
{
	int left = len;
	unsigned char *temp_buf;
	unsigned char identifier[ETH_ALEN];
	unsigned char bh_mac[ETH_ALEN];
	temp_buf = buf;

	if (left < ETH_ALEN + 1) {
		debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
			__LINE__, left, ETH_ALEN + 1);
		return -1;
	}

	/* identifier */
	os_memcpy(identifier, temp_buf, ETH_ALEN);
	temp_buf += ETH_ALEN;
	left -= ETH_ALEN;

	if ((*(temp_buf++)) & 0x80) {
		left -= 1;
		if (left < ETH_ALEN) {
			debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
				__LINE__, left, ETH_ALEN);
			return -1;
		}
		os_memcpy(bh_mac, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;
	}

	return 0;
}


int parse_bss_configuration_request_tlv(struct p1905_managerd_ctx *ctx, unsigned char *buf, unsigned short len)
{
	unsigned char *temp_buf;
	unsigned short obj_len = 0;
	struct json_token *root, *token;
	const unsigned char *conf_rsp_obj = NULL;
	temp_buf = buf;

	if (dpp_check_attrs(temp_buf, len) < 0) {
		debug(DEBUG_ERROR, "Invalid attribute in bss configuration response\n");
		goto fail;
	}

	conf_rsp_obj = dpp_get_attr(temp_buf, len, DPP_ATTR_CONFIG_ATTR_OBJ, &obj_len);
	if (!conf_rsp_obj) {
		debug(DEBUG_ERROR,
			      "Missing or invalid required configuration object\n");
		goto fail;
	}

	/* parse dpp configuration request object */
	root = json_parse((const char *) conf_rsp_obj, obj_len);
	if (!root)
		return -1;
	if (root->type != JSON_OBJECT) {
		debug(DEBUG_ERROR, "JSON root is not an object\n");
		goto fail;
	}

	token = json_get_member(root, "netRole");
	if (!token || token->type != JSON_STRING) {
		debug(DEBUG_ERROR, "No netRole string value found\n");
		goto fail;
	}
    debug(DEBUG_ERROR, "netRole %s\n", token->string);

	token = json_get_member(root, "wi-fi_tech");
	if (!token || token->type != JSON_STRING) {
		debug(DEBUG_ERROR, "No wi-fi_tech string value found\n");
		goto fail;
	}
    debug(DEBUG_ERROR, "wi-fi_tech %s\n", token->string);

	return 0;
fail:
	return -1;
}

int parse_1905_layer_security_capability_tlv(struct p1905_managerd_ctx *ctx, unsigned char *buf,
	unsigned char *onboardingProto, unsigned char *msgIntAlg, unsigned char *msgEncAlg)
{
	unsigned char *temp_buf;
	unsigned short length = 0;
	temp_buf = buf;

	if((*temp_buf) == _1905_LAYER_SECURITY_CAPABILITY_TYPE) {
		temp_buf++;
	} else {
		return -1;
	}

	//calculate tlv length
	length = *(unsigned short *)temp_buf;
	length = be_to_host16(length);
	temp_buf += 2;

	*onboardingProto = *temp_buf++;

	*msgIntAlg = *temp_buf++;

	*msgEncAlg = *temp_buf++;

	return (length+3);
}

int parse_agent_list_tlv(unsigned char *buf, unsigned short len,
	unsigned char *agent_cnt, struct r3_member *peer)
{
	unsigned short left = len;
	unsigned char *temp_buf;
	unsigned char i = 0;

	temp_buf = buf;

	if (left < 1) {
		debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
			__LINE__, left, 1);
		return -1;
	}

	*agent_cnt = *temp_buf++;
	left -= 1;

	if (*agent_cnt > 10) {
		debug(DEBUG_ERROR, "%d: error agent_cnt %d more than 10\n",
			__LINE__, *agent_cnt);
		return -1;
	}

	for (i = 0; i < *agent_cnt; i++) {
		if (left < 8) {
			debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
				__LINE__, left, 8);
			return -1;
		}
		os_memcpy(peer[i].al_mac, temp_buf, ETH_ALEN);
		temp_buf += ETH_ALEN;

		peer[i].profile = *temp_buf++;
		peer[i].security_1905 = *temp_buf++;
		left -= 8;
    }

	return 0;
}

int parse_ap_wf6_capability_tlv(struct p1905_managerd_ctx *ctx,
	unsigned char *buf)
{
    unsigned char *temp_buf;
    unsigned short length = 0;

    temp_buf = buf;

    if((*temp_buf) == 0xAA) {
        temp_buf++;
    }
    else {
        return -1;
    }

    //calculate tlv length
    length = *(unsigned short *)temp_buf;
    length = be_to_host16(length);

    return (length+3);
}

int parse_bss_configuration_response_tlv(
	unsigned char *buf, unsigned short len,
	struct r3_onboarding_info *r3_ctx)
{
	unsigned short left = len;
	unsigned char *temp_buf;
	struct json_token *root = NULL, *token, *discovery, *cred;
	struct json_token *akm_token = NULL;
	struct json_token *ruid_token = NULL;
	struct json_token *ssid_token = NULL;
	struct json_token *wifi_tech_token = NULL;
	unsigned char map_vendor_extension[MAX_SET_BSS_INFO_NUM];
	unsigned char mac[ETH_ALEN] = {0x00};
	unsigned char ruid[ETH_ALEN] = {0x00};
	unsigned char index = r3_ctx->total_config_num;
	enum dpp_akm akm;
	struct dpp_authentication auth;
	/* Cross vendor with NXP */
	const unsigned char *conf_rsp_obj = NULL;
	unsigned short obj_len = 0;
	unsigned char tear_down = 0;

	temp_buf = buf;
	os_memset(&auth, 0, sizeof(auth));
	os_memset(map_vendor_extension, 0, sizeof(map_vendor_extension));

	if (dpp_check_attrs(temp_buf, len) < 0) {
		debug(DEBUG_ERROR, "Invalid attribute in bss configuration response\n");
		goto fail;
	}

	while (temp_buf - buf < len) {
		tear_down = 0;
		conf_rsp_obj = dpp_get_attr(temp_buf, left, DPP_ATTR_CONFIG_OBJ,
					    &obj_len);
		if (!conf_rsp_obj) {
			debug(DEBUG_ERROR,
				      "Missing or invalid required configuration object\n");
			goto fail;
		}
		debug(DEBUG_TRACE, "attribute type: 0x100C\n");
		debug(DEBUG_TRACE, "attribute length: %d\n", obj_len);
		root = json_parse((const char *) conf_rsp_obj, obj_len);
		if (!root) {
			debug(DEBUG_ERROR, "Could not parse Config Response Object\n");
			goto fail;
		}

		wifi_tech_token = json_get_member(root, "wi-fi_tech");
		if (!wifi_tech_token || wifi_tech_token->type != JSON_STRING) {
			debug(DEBUG_ERROR, "No Config Attributes - wi-fi_tech\n");
			goto fail;
		}
		debug(DEBUG_TRACE, "wi-fi_tech= '%s'\n", wifi_tech_token->string);


		discovery = json_get_member(root, "discovery");
		if (!discovery || discovery->type != JSON_OBJECT) {
			debug(DEBUG_ERROR, "No discovery object in JSON\n");
			goto fail;
		}


		ssid_token = json_get_member(discovery, "ssid");
		if (!ssid_token || ssid_token->type != JSON_STRING) {
			debug(DEBUG_ERROR, "No discovery::ssid string value found\n");
			goto fail;
		}
		debug(DEBUG_ERROR, "ssid %s\n", ssid_token->string);
		if (os_strlen(ssid_token->string) > 32) {
			debug(DEBUG_ERROR, "Too long discovery::ssid string value\n");
			goto fail;
		}

		ruid_token = json_get_member(discovery, "RUID");

		if (!ruid_token || ruid_token->type != JSON_STRING) {
			debug(DEBUG_ERROR, "No Config Attributes - RUID\n");
			goto fail;
		}
		hwaddr_compact_aton(ruid_token->string, ruid);
		os_memset(&r3_ctx->bss_config_data[index], 0, sizeof(struct r3_config_data));
		if (ssid_token && os_strlen(ssid_token->string) && index) {
			/* bss with FH and BH if both ssid and ruid are the same as last obj */
			/* TODO: how about the same ssid on all interface???*/
			if ((!os_strncmp((const char *)r3_ctx->bss_config_data[index - 1].config_data.Ssid,
				(const char *)ssid_token->string, MAX_SSID_LEN - 1)) &&
				(!os_memcmp((const char *)r3_ctx->bss_config_data[index - 1].radio_identifier,
				(const char *)ruid, ETH_ALEN))) {
				index -= 1;
				debug(DEBUG_ERROR, "SSID same as last bss, reset index to %d\n", index);
			}
		}

		os_memcpy(r3_ctx->bss_config_data[index].radio_identifier, ruid, ETH_ALEN);
		debug(DEBUG_ERROR, "bss(%d) RUID "MACSTR"\n", index, MAC2STR(ruid));

		/* decide FH or BH by wi-fi_tech */
		if (!os_strcmp(wifi_tech_token->string, "map")) {
			map_vendor_extension[index] |= BIT_BH_BSS;
			debug(DEBUG_ERROR, "bss(%d) with BIT_BH_BSS\n", index);
		}
		else if (!os_strcmp(wifi_tech_token->string, "inframap")) {
			map_vendor_extension[index] |= BIT_FH_BSS;
			debug(DEBUG_ERROR, "bss(%d) with BIT_FH_BSS\n", index);
		}
		else {
			debug(DEBUG_ERROR, "invalide wifi tech info\n");
			goto fail;
		}

		token = json_get_member(discovery, "RUID");

		if (!token || token->type != JSON_STRING) {
			debug(DEBUG_ERROR, "No Config Attributes - RUID\n");
			goto fail;
		}

		if (os_strlen(ssid_token->string) == 0) {
			map_vendor_extension[index] = BIT_TEAR_DOWN;
			tear_down = 1;
			debug(DEBUG_ERROR, "index(%d) tear down this bss\n", index);
		}
		else {
			os_memset(r3_ctx->bss_config_data[index].config_data.Ssid, 0, 33);
			os_memcpy(r3_ctx->bss_config_data[index].config_data.Ssid,
				ssid_token->string, os_strlen(ssid_token->string));
		}

		token = json_get_member(discovery, "BSSID");
		if (!token || token->type != JSON_STRING) {
			debug(DEBUG_ERROR, "No discovery::BSSID string value found\n");
			goto fail;
		}
		debug(DEBUG_ERROR, "bss(%d) BSSID %s\n",index, token->string);

		if(!hwaddr_aton(token->string, mac)) {
			os_memset(r3_ctx->bss_config_data[index].bssid, 0, ETH_ALEN);
			os_memcpy(r3_ctx->bss_config_data[index].bssid, mac, ETH_ALEN);
		}
		r3_ctx->bss_config_data[index].config_data.map_vendor_extension = map_vendor_extension[index];

#ifdef MAP_R6
		/* MLO Backhaul STA Configuration */
		/* TODO: parse MLOBackhaulSTAConfig*/
#endif

		if (!tear_down) {

			token = json_get_member(discovery, "hidden-ssid");

			if (!token || token->type != JSON_STRING) {
				debug(DEBUG_TRACE, "bss(%d) no hidden-ssid\n",index);
			}
			else {
				r3_ctx->bss_config_data[index].config_data.hidden_ssid = 1;
				debug(DEBUG_ERROR, "bss(%d) hidden-ssid\n",index);
			}


			cred = json_get_member(root, "cred");
			if (!cred || cred->type != JSON_OBJECT) {
				debug(DEBUG_ERROR, "No cred object in JSON\n");
				goto fail;
			}

			akm_token = json_get_member(cred, "akm");
			if (!akm_token || akm_token->type != JSON_STRING) {
				debug(DEBUG_ERROR, "No cred::akm string value found\n");
				goto fail;
			}

			debug(DEBUG_ERROR, "bss(%d) akm %s\n",index, akm_token->string);

			akm = dpp_akm_from_str(akm_token->string);

			if (dpp_akm_legacy(akm)) {
				if (dpp_parse_cred_legacy(&auth, cred) < 0)
					goto fail;

				if (akm == DPP_AKM_PSK_SAE)
					r3_ctx->bss_config_data[index].config_data.AuthMode = AUTH_WPA2_PERSONAL|AUTH_SAE_PERSONAL;
				else if (akm == DPP_AKM_PSK)
					r3_ctx->bss_config_data[index].config_data.AuthMode = AUTH_WPA2_PERSONAL;
				else if (dpp_akm_sae(akm))
					r3_ctx->bss_config_data[index].config_data.AuthMode = AUTH_SAE_PERSONAL;
#ifdef MAP_R6
				else if (akm == DPP_AKM_SAE24)
					r3_ctx->bss_config_data[index].config_data.AuthMode = AUTH_AKM_SAE24;
				else if (akm == DPP_AKM_SAE_SAE24)
					r3_ctx->bss_config_data[index].config_data.AuthMode = AUTH_AKM_SAE24|AUTH_SAE_PERSONAL;
				else if (akm == DPP_AKM_PSK_SAE24)
					r3_ctx->bss_config_data[index].config_data.AuthMode = AUTH_AKM_SAE24|AUTH_WPA2_PERSONAL;
				else if (akm == DPP_AKM_PSK_SAE_SAE24)
					r3_ctx->bss_config_data[index].config_data.AuthMode =
					AUTH_AKM_SAE24|AUTH_WPA2_PERSONAL|AUTH_SAE_PERSONAL;
#endif

				r3_ctx->bss_config_data[index].config_data.EncrypType = ENCRYP_AES;
			} else if (dpp_akm_dpp(akm)) {
				if(dpp_akm_ver2(akm)) {
					if (dpp_parse_cred_legacy(&auth, cred) < 0)
						goto fail;
				}
				if (akm == DPP_AKM_PSK_SAE_DPP)
					r3_ctx->bss_config_data[index].config_data.AuthMode = AUTH_DPP_ONLY|AUTH_WPA2_PERSONAL|AUTH_SAE_PERSONAL;
				else if (akm == DPP_AKM_SAE_DPP)
					r3_ctx->bss_config_data[index].config_data.AuthMode = AUTH_DPP_ONLY|AUTH_SAE_PERSONAL;
				else if (akm == DPP_AKM_PSK_DPP)
					r3_ctx->bss_config_data[index].config_data.AuthMode = AUTH_DPP_ONLY|AUTH_WPA2_PERSONAL;
#ifdef MAP_R6
				else if (akm == DPP_AKM_SAE24_DPP)
					r3_ctx->bss_config_data[index].config_data.AuthMode = AUTH_DPP_ONLY|AUTH_AKM_SAE24;
				else if (akm == DPP_AKM_SAE_SAE24_DPP)
					r3_ctx->bss_config_data[index].config_data.AuthMode =
					AUTH_DPP_ONLY|AUTH_AKM_SAE24|AUTH_SAE_PERSONAL;
				else if (akm == DPP_AKM_PSK_SAE24_DPP)
					r3_ctx->bss_config_data[index].config_data.AuthMode =
					AUTH_DPP_ONLY|AUTH_AKM_SAE24|AUTH_WPA2_PERSONAL;
				else if (akm == DPP_AKM_PSK_SAE_SAE24_DPP)
					r3_ctx->bss_config_data[index].config_data.AuthMode =
					AUTH_DPP_ONLY|AUTH_AKM_SAE24|AUTH_SAE_PERSONAL|AUTH_WPA2_PERSONAL;
#endif
				else
					r3_ctx->bss_config_data[index].config_data.AuthMode = AUTH_DPP_ONLY;

				r3_ctx->bss_config_data[index].config_data.EncrypType = ENCRYP_AES;

				if (obj_len > sizeof(r3_ctx->bss_config_data[index].config_data.cred)) {
					debug(DEBUG_ERROR, "obj len too big, obj_len = %d\n", obj_len);
					goto fail;
				}

				/* R3 ext Cred will be filled up while BSS is set to both BH and FH */
				if ((map_vendor_extension[index] & BIT_BH_BSS) &&
					(map_vendor_extension[index] & BIT_FH_BSS)) {
					debug(DEBUG_TRACE, "obj len %d\n", obj_len);

					os_memcpy(r3_ctx->bss_config_data[index].config_data.ext_cred,
						conf_rsp_obj, obj_len);
					r3_ctx->bss_config_data[index].config_data.ext_cred_len = obj_len;
					debug(DEBUG_TRACE, "map_vendor_extension are both FH and BH\n");
				}
				/* R3 Cred will be filled up while BSS is set to BH or FH */
				else {
					debug(DEBUG_TRACE, "map_vendor_extension is %s only\n",
						(r3_ctx->bss_config_data[index].config_data.map_vendor_extension & BIT_BH_BSS)?"BH":"FH");
					os_memcpy(r3_ctx->bss_config_data[index].config_data.cred, conf_rsp_obj, obj_len);
					r3_ctx->bss_config_data[index].config_data.cred_len = obj_len;
					debug(DEBUG_TRACE, "obj len %d\n", obj_len);
				}
			} else if (dpp_akm_owe(akm)) {
				if (akm == DPP_AKM_OWE) {
					r3_ctx->bss_config_data[index].config_data.AuthMode = AUTH_OWE;
					r3_ctx->bss_config_data[index].config_data.EncrypType = ENCRYP_AES;
				} else if (akm == DPP_AKM_OWE_TRANSITION) {
					r3_ctx->bss_config_data[index].config_data.AuthMode = AUTH_OWE_TRANSITION;
					r3_ctx->bss_config_data[index].config_data.EncrypType = ENCRYP_AES;
				}
				os_memcpy(r3_ctx->bss_config_data[index].config_data.cred, conf_rsp_obj, obj_len);
				r3_ctx->bss_config_data[index].config_data.cred_len = obj_len;
				debug(DEBUG_TRACE, "obj len %d\n", obj_len);
			} else {
				debug(DEBUG_ERROR, "Unsupported akm: %s", akm_token->string);
				goto fail;
			}

			if (dpp_akm_legacy(akm) || dpp_akm_ver2(akm)) {
				if (auth.psk_set) {
					if (wpa_snprintf_hex((char *)r3_ctx->bss_config_data[index].config_data.WPAKey, 65,
						auth.psk, PMK_LEN) != 64) {
						debug(DEBUG_ERROR, "bss(%d) fail to copy psk\n", index);
						goto fail;
					}
					debug(DEBUG_ERROR, "psk set to bss bss(%d)\n", index);
				} else
					os_memcpy(r3_ctx->bss_config_data[index].config_data.WPAKey,
					auth.passphrase, sizeof(auth.passphrase));
			}
			index++;
			if (index >= MAX_SET_BSS_INFO_NUM) {
				debug(DEBUG_ERROR, "bss index(%d) equal to or bigger than %d\n",
					index, MAX_SET_BSS_INFO_NUM);
				goto fail;
			}
		}

		left -= (obj_len + 4);
		temp_buf += (obj_len + 4);
	}
	r3_ctx->total_config_num = index;
	return 0;
fail:
	return -1;
}
#endif


int parse_agent_ap_mld_config_tlv(struct mld_bss_config_db *mld_bss, unsigned char *al_mac,
	unsigned char *buf, unsigned short len)
{
	int left = len;
	unsigned char *temp_buf = buf;
	struct mlo_config_db *mlo_cfg = NULL;
	struct affiliated_ap_db *aff_ap = NULL;
	unsigned int mld_idx = 0, aff_ap_idx = 0;

	if (!mld_bss) {
		debug(DEBUG_ERROR, "%d: mld_bss NULL pointer\n", __LINE__);
		return -1;
	}

	if (left < 1) {
		debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
			__LINE__, left, 1);
		return -1;
	}

	/* identifier */
	mld_bss->num_ap_mld = *temp_buf;
	os_memcpy(mld_bss->al_mac, al_mac, ETH_ALEN);
	left -= 1;
	temp_buf += 1;

	for (mld_idx = 0; mld_idx < mld_bss->num_ap_mld; mld_idx++) {
		mlo_cfg = (struct mlo_config_db *)os_zalloc(sizeof(struct mlo_config_db));
		if (!mlo_cfg) {
			debug(DEBUG_ERROR, "%d: fail to malloc\n", __LINE__);
			goto fail;
		}
		dl_list_add_tail(&mld_bss->mlo_cfg_list, &mlo_cfg->list);
		dl_list_init(&mlo_cfg->aff_ap_list);
		dl_list_init(&mlo_cfg->free_aff_ap_list);

		if (left < 2) {
			debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
				__LINE__, left, 2);
			goto fail;
		}

		mlo_cfg->mld_mac_valid = *temp_buf & 0x80;

		mlo_cfg->ssid_len = *(temp_buf+1);
		left -= 2;
		temp_buf += 2;

		if (left < mlo_cfg->ssid_len + 27) {
			debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
				__LINE__, left, mlo_cfg->ssid_len + 27);
			goto fail;
		}
		os_memcpy(mlo_cfg->ssid, temp_buf, mlo_cfg->ssid_len);
		mlo_cfg->ssid[MAX_SSID_LEN - 1] = '\0';

		debug(DEBUG_TRACE, "ssid %s\n", mlo_cfg->ssid);
		left -= mlo_cfg->ssid_len;
		temp_buf += mlo_cfg->ssid_len;

		os_memcpy(mlo_cfg->mld_mac, temp_buf, ETH_ALEN);
		debug(DEBUG_TRACE, "mld mac "MACSTR"\n", MAC2STR(mlo_cfg->mld_mac));
		left -= ETH_ALEN;
		temp_buf += ETH_ALEN;

		if (*temp_buf & 0x80)
			mlo_cfg->ap_str_support = 1;
		if (*temp_buf & 0x40)
			mlo_cfg->ap_nstr_support = 1;
		if (*temp_buf & 0x20)
			mlo_cfg->ap_emlsr_support = 1;
		if (*temp_buf & 0x10)
			mlo_cfg->ap_emlmr_support = 1;
		debug(DEBUG_TRACE, "sr bit %x\n", *temp_buf);
		left -= 1;
		temp_buf += 1;

		/* reserved 20 bytes */
		left -= 20;
		temp_buf += 20;

		if (left < 1) {
			debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
				__LINE__, left, 1);
			return -1;
		}
		mlo_cfg->num_affiliated_ap = *temp_buf;
		debug(DEBUG_TRACE, "num_affiliated_ap %d\n", mlo_cfg->num_affiliated_ap);
		left -= 1;
		temp_buf += 1;

		for (aff_ap_idx = 0; aff_ap_idx < mlo_cfg->num_affiliated_ap; aff_ap_idx++) {
			aff_ap = (struct affiliated_ap_db *)os_zalloc(sizeof(struct affiliated_ap_db));
			if (!aff_ap) {
				debug(DEBUG_ERROR, "%d: fail to malloc\n", __LINE__);
				goto fail;
			}
			dl_list_add_tail(&mlo_cfg->aff_ap_list, &aff_ap->list);

			if (left < 32) {
				debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
					__LINE__, left, 32);
				goto fail;
			}

			aff_ap->affiliated_ap_valid = (*temp_buf) & 0x80;
			left -= 1;
			temp_buf += 1;

			os_memcpy(aff_ap->ruid, temp_buf, ETH_ALEN);
			left -= ETH_ALEN;
			temp_buf += ETH_ALEN;
			debug(DEBUG_TRACE, "ruid "MACSTR"\n", MAC2STR(aff_ap->ruid));

			os_memcpy(aff_ap->affiliated_ap_bssid, temp_buf, ETH_ALEN);
			debug(DEBUG_TRACE, "affiliated_ap_bssid "MACSTR"\n", MAC2STR(aff_ap->affiliated_ap_bssid));
			left -= ETH_ALEN;
			temp_buf += ETH_ALEN;

			aff_ap->link_id = *temp_buf;
			debug(DEBUG_TRACE, "link_id %d\n", aff_ap->link_id);
			left -= 1;
			temp_buf += 1;

			/* 18 reserved bytes */
			left -= 18;
			temp_buf += 18;
		}
	}

	return 0;

fail:
	return -1;

}

#ifdef MAP_R6

int parse_wifi7_cap_tlv(struct p1905_managerd_ctx *ctx,
unsigned char *al_mac, struct dl_list *cap_list, unsigned char *buf, unsigned short len)
{
	int left = len;
	unsigned char *temp_buf = buf;
	struct wifi7_mlo_cap_db *cap = NULL;
	unsigned char radio_num = 0, radio_idx = 0;
	unsigned char max_num_mld = 0;
	unsigned char ap_max_link = 0;
	unsigned char bsta_max_link = 0;
	unsigned char tid_to_link_map = 0;
	unsigned char num_record = 0;
	unsigned char idx = 0;

	if (left < 12) {
		debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
			__LINE__, left, 12);
		return -1;
	}

	/* MaxNumMLDs */
	max_num_mld = *temp_buf;
	debug(DEBUG_TRACE, "max_num_mld %d\n", max_num_mld);
	left -= 1;
	temp_buf += 1;

	/* AP Maximum Links	bits 7-4
	 * bSTA Maximum Links	bits 3-0
	*/
	ap_max_link = ((*temp_buf) & 0xf0) >> 4;
	bsta_max_link = (*temp_buf) & 0x0f;
	left -= 1;
	temp_buf += 1;

	/* TID-To-Link Mapping  */
	tid_to_link_map = *temp_buf;
	left -= 1;
	temp_buf += 1;

	/* reserved 13 bytes */
	temp_buf += 13;
	left -= 13;

	/* numRadios */
	radio_num = *temp_buf;
	debug(DEBUG_TRACE, "radio_num %d\n", radio_num);
	left -= 1;
	temp_buf += 1;

	for (radio_idx = 0; radio_idx < radio_num; radio_idx++) {

		cap = (struct wifi7_mlo_cap_db *)os_zalloc(sizeof(struct wifi7_mlo_cap_db));
		if (!cap) {
			debug(DEBUG_ERROR, "error malloc for wifi7 capability\n");
			goto fail;
		}

		dl_list_add(cap_list, &cap->list);

		cap->max_num_mld = max_num_mld;
		cap->ap_max_link = ap_max_link;
		cap->bsta_max_link = bsta_max_link;
		cap->tid_to_link_map = tid_to_link_map;

		/* RUID */
		os_memcpy(cap->identifier, temp_buf, ETH_ALEN);
		left -= ETH_ALEN;
		temp_buf += ETH_ALEN;
		debug(DEBUG_TRACE, "ruid "MACSTR"\n", MAC2STR(cap->identifier));

		/* reserved 24 bytes */
		temp_buf += 24;
		left -= 24;

		/* ap str, nstr, emlsr, emlmr support */
		if (*temp_buf & 0x80)
			cap->ap_str_support = 1;
		if (*temp_buf & 0x40)
			cap->ap_nstr_support = 1;
		if (*temp_buf & 0x20)
			cap->ap_emlsr_support = 1;
		if (*temp_buf & 0x10)
			cap->ap_emlmr_support = 1;
		left -= 1;
		temp_buf += 1;

		/* sta str, nstr, emlsr, emlmr support */
		if (*temp_buf & 0x80)
			cap->sta_str_support = 1;
		if (*temp_buf & 0x40)
			cap->sta_nstr_support = 1;
		if (*temp_buf & 0x20)
			cap->sta_emlsr_support = 1;
		if (*temp_buf & 0x10)
			cap->sta_emlmr_support = 1;
		left -= 1;
		temp_buf += 1;

		/* TODO: store ap sta str records??*/

		/* Num_AP_STR_Records */
		num_record = *temp_buf;
		debug(DEBUG_TRACE, "Num_AP_STR_Records %d\n", num_record);
		left -= 1;
		temp_buf += 1;
		for (idx = 0; idx < num_record; idx++) {
			/* AP_STR_RUID */
			left -= ETH_ALEN;
			temp_buf += ETH_ALEN;
			/* AP_STR_Freq_Separation */
			left -= 1;
			temp_buf += 1;
		}

		/* Num_AP_NSTR_Records */
		num_record = *temp_buf;
		debug(DEBUG_TRACE, "Num_AP_NSTR_Records %d\n", num_record);
		left -= 1;
		temp_buf += 1;
		for (idx = 0; idx < num_record; idx++) {
			/* AP_NSTR_RUID */
			left -= ETH_ALEN;
			temp_buf += ETH_ALEN;
			/* AP_NSTR_Freq_Separation */
			left -= 1;
			temp_buf += 1;
		}

		/* Num_AP_EMLSR_Records */
		num_record = *temp_buf;
		debug(DEBUG_TRACE, "Num_AP_EMLSR_Records %d\n", num_record);
		left -= 1;
		temp_buf += 1;
		for (idx = 0; idx < num_record; idx++) {
			/* AP_EMLSR_RUID */
			left -= ETH_ALEN;
			temp_buf += ETH_ALEN;
			/* AP_EMLSR_Freq_Separation */
			left -= 1;
			temp_buf += 1;
		}

		/* Num_AP_EMLMR_Records */
		num_record = *temp_buf;
		debug(DEBUG_TRACE, "Num_AP_EMLMR_Records %d\n", num_record);
		left -= 1;
		temp_buf += 1;
		for (idx = 0; idx < num_record; idx++) {
			/* AP_EMLMR_RUID */
			left -= ETH_ALEN;
			temp_buf += ETH_ALEN;
			/* AP_EMLMR_Freq_Separation */
			left -= 1;
			temp_buf += 1;
		}

		/* Num_STA_STR_Records */
		num_record = *temp_buf;
		debug(DEBUG_TRACE, "Num_STA_STR_Records %d\n", num_record);
		left -= 1;
		temp_buf += 1;
		for (idx = 0; idx < num_record; idx++) {
			/* STA_STR_RUID */
			left -= ETH_ALEN;
			temp_buf += ETH_ALEN;
			/* STA_STR_Freq_Separation */
			left -= 1;
			temp_buf += 1;
		}

		/* Num_STA_NSTR_Records */
		num_record = *temp_buf;
		debug(DEBUG_TRACE, "Num_STA_NSTR_Records %d\n", num_record);
		left -= 1;
		temp_buf += 1;
		for (idx = 0; idx < num_record; idx++) {
			/* STA_NSTR_RUID */
			left -= ETH_ALEN;
			temp_buf += ETH_ALEN;
			/* STA_NSTR_Freq_Separation */
			left -= 1;
			temp_buf += 1;
		}

		/* Num_STA_EMLSR_Records */
		num_record = *temp_buf;
		debug(DEBUG_TRACE, "Num_STA_EMLSR_Records %d\n", num_record);
		left -= 1;
		temp_buf += 1;
		for (idx = 0; idx < num_record; idx++) {
			/* STA_EMLSR_RUID */
			left -= ETH_ALEN;
			temp_buf += ETH_ALEN;
			/* STA_EMLSR_Freq_Separation */
			left -= 1;
			temp_buf += 1;
		}

		/* Num_STA_EMLMR_Records */
		num_record = *temp_buf;
		debug(DEBUG_TRACE, "Num_STA_EMLMR_Records %d\n", num_record);
		left -= 1;
		temp_buf += 1;
		for (idx = 0; idx < num_record; idx++) {
			/* STA_EMLMR_RUID */
			left -= ETH_ALEN;
			temp_buf += ETH_ALEN;
			/* STA_EMLMR_Freq_Separation */
			left -= 1;
			temp_buf += 1;
		}
	}

	return 0;
fail:
	return -1;
}


int parse_bsta_mld_config_tlv(struct mld_bsta_config_db *mld_bsta, unsigned char *buf, unsigned short len)
{
	int left = len;
	unsigned char *temp_buf = buf;
	struct affiliated_sta_db *aff_sta = NULL;
	unsigned int mld_idx = 0;

	if (left < 1) {
		debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
			__LINE__, left, 1);
		return -1;
	}

	/* MLD_MAC_Addr_Valid	bit 7
	 * BSS_MLD_MAC_Addr_valid	bit 6
	*/
	mld_bsta->mld_mac_bitmap = *temp_buf;
	debug(DEBUG_TRACE, "mld_mac_bitmap %x\n", mld_bsta->mld_mac_bitmap);
	left -= 1;
	temp_buf += 1;

	if (left < ETH_ALEN) {
		debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
			__LINE__, left, ETH_ALEN);
		return -1;
	}
	os_memcpy(mld_bsta->mld_mac, temp_buf, ETH_ALEN);
	left -= ETH_ALEN;
	temp_buf += ETH_ALEN;
	debug(DEBUG_TRACE, "mld_mac "MACSTR"\n", MAC2STR(mld_bsta->mld_mac));

	if (left < ETH_ALEN) {
		debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
			__LINE__, left, ETH_ALEN);
		return -1;
	}
	os_memcpy(mld_bsta->bss_mld_mac, temp_buf, ETH_ALEN);
	debug(DEBUG_TRACE, "bss_mld_mac "MACSTR"\n", MAC2STR(mld_bsta->bss_mld_mac));
	left -= ETH_ALEN;
	temp_buf += ETH_ALEN;

	if (left < 1) {
		debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
			__LINE__, left, 1);
		return -1;
	}
	mld_bsta->switch_bitmap = *temp_buf;
	debug(DEBUG_TRACE, "switch_bitmap %x\n", mld_bsta->switch_bitmap);
	left -= 1;
	temp_buf += 1;

	if (left < 17) {
		debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
			__LINE__, left, 17);
		return -1;
	}
	left -= 17;
	temp_buf += 17;

	/* numAffiliatedbSTAs */
	if (left < 1) {
		debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
			__LINE__, left, 1);
		return -1;
	}
	mld_bsta->num_affiliated_sta = *temp_buf;
	debug(DEBUG_TRACE, "num_affiliated_sta %d\n", mld_bsta->num_affiliated_sta);
	left -= 1;
	temp_buf += 1;

	for (mld_idx = 0; mld_idx < mld_bsta->num_affiliated_sta; mld_idx++) {
		if (left < ETH_ALEN+1) {
			debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
				__LINE__, left, ETH_ALEN+1);
			return -1;
		}

		aff_sta = os_zalloc(sizeof(struct affiliated_sta_db));
		if (!aff_sta) {
			debug(DEBUG_ERROR, "%d: malloc fail\n", __LINE__);
			return -1;
		}
		/* Affiliated_bSTA_MAC_Addr_Valid	bit 7 */
		aff_sta->bitmap = *temp_buf;
		debug(DEBUG_TRACE, "bitmap %x\n", aff_sta->bitmap);

		left -= 1;
		temp_buf += 1;

		os_memcpy(aff_sta->ruid, temp_buf, ETH_ALEN);
		debug(DEBUG_TRACE, "ruid "MACSTR"\n", MAC2STR(aff_sta->ruid));
		left -= ETH_ALEN;
		temp_buf += ETH_ALEN;

		os_memcpy(aff_sta->affiliated_sta_bssid, temp_buf, ETH_ALEN);
		debug(DEBUG_TRACE, "affiliated sta bssid "MACSTR"\n", MAC2STR(aff_sta->affiliated_sta_bssid));
		left -= ETH_ALEN;
		temp_buf += ETH_ALEN;

		left -= 19;
		temp_buf += 19;

		dl_list_add(&mld_bsta->affiliated_sta_list, &aff_sta->list);
	}

	return 0;
}


int parse_affiliated_sta_metrics_tlv(struct p1905_managerd_ctx *ctx, unsigned char *buf)
{
	unsigned char *temp_buf;
	unsigned short length = 0;

	temp_buf = buf;

	if ((*temp_buf) == AFFILIATED_STA_METRICS_TLV_TYPE)
		temp_buf++;
	else
		return -1;

	length = *(unsigned short *)temp_buf;
	length = be_to_host16(length);

	temp_buf += ETH_ALEN + 2;
	*((unsigned int *)temp_buf) = be_to_host32(*((unsigned int *)temp_buf));
	temp_buf += sizeof(unsigned int);
	*((unsigned int *)temp_buf) = be_to_host32(*((unsigned int *)temp_buf));
	temp_buf += sizeof(unsigned int);
	*((unsigned int *)temp_buf) = be_to_host32(*((unsigned int *)temp_buf));
	temp_buf += sizeof(unsigned int);
	*((unsigned int *)temp_buf) = be_to_host32(*((unsigned int *)temp_buf));
	temp_buf += sizeof(unsigned int);
	*((unsigned int *)temp_buf) = be_to_host32(*((unsigned int *)temp_buf));
	temp_buf += sizeof(unsigned int);

	return (length+3);
}

#endif
int parse_eht_operations_tlv(struct eht_operations_db *eth_op, unsigned char *buf, unsigned short len)
{
	int left = len;
	unsigned char *temp_buf = buf;
	struct eht_operations_info_db *db = NULL;
	unsigned char r_num = 0, bss_num = 0;
	unsigned char r_idx = 0, bss_idx = 0;
	unsigned char dscb_valid = 0;
	unsigned char eth_pe_duration = 0;
	unsigned char eht_op_info_valid = 0;
	unsigned char grp_addr_bu_ind_limit = 0;
	unsigned char grp_addr_bu_ind_exponent = 0;

	if (left < 32) {
		debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
			__LINE__, left, 32);
		return -1;
	}
	temp_buf += 32;
	left -= 32;

	if (left < 1) {
		debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
			__LINE__, left, 1);
		return -1;
	}

	/* numRadios */
	r_num = *temp_buf;
	debug(DEBUG_TRACE, "%d: r_num %d\n", __LINE__, r_num);
	temp_buf++;
	left--;
	if (r_num > MAX_RADIO_NUM) {
		debug(DEBUG_ERROR, "%d: error radio num %d\n", __LINE__, r_num);
		return -1;
	}
	for (r_idx = 0; r_idx < r_num; r_idx++) {
		if (left < ETH_ALEN) {
			debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
				__LINE__, left, ETH_ALEN);
			return -1;
		}
		/* RUID */
		os_memcpy(eth_op[r_idx].ruid, temp_buf, ETH_ALEN);
		debug(DEBUG_TRACE, "%d: ruid "MACSTR"\n", __LINE__, MAC2STR(eth_op[r_idx].ruid));

		temp_buf += ETH_ALEN;
		left -= ETH_ALEN;

		if (left < 1) {
			debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
				__LINE__, left, 1);
			return -1;
		}

		/* numBSSs */
		bss_num = *temp_buf;
		debug(DEBUG_TRACE, "%d: bss_num %d\n", __LINE__, bss_num);
		temp_buf++;
		left--;

		for (bss_idx = 0; bss_idx < bss_num; bss_idx++) {
			dscb_valid = 0;
			eth_pe_duration = 0;
			eht_op_info_valid = 0;
			grp_addr_bu_ind_limit = 0;
			grp_addr_bu_ind_exponent = 0;

			if (left < ETH_ALEN) {
				debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
					__LINE__, left, ETH_ALEN);
				return -1;
			}
			db = (struct eht_operations_info_db *)os_zalloc(sizeof(struct eht_operations_info_db));
			if (!db) {
				debug(DEBUG_ERROR, "%d: error alloc\n", __LINE__);
				return -1;
			}
			dl_list_add_tail(&eth_op[r_idx].eht_op_list, &db->list);

			/* BSSID */
			os_memcpy(db->bssid, temp_buf, ETH_ALEN);
			debug(DEBUG_TRACE, "%d: bssid "MACSTR"\n", __LINE__, MAC2STR(db->bssid));
			temp_buf += ETH_ALEN;
			left -= ETH_ALEN;

			if (left < 1) {
				debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
					__LINE__, left, 1);
				return -1;
			}
			/* EHT_Operation_Information_Valid bit 7
			 * Disabled_Subchannel_Valid	bit 6
			 * EHT Default PE Duration bit 5
			 * Group Addressed BU Indication Limit bit 4
			 * Group Addressed BU Indication Exponent	bits 3-2
			*/
			if (*temp_buf & 0x80)
				eht_op_info_valid = 1;
			if (*temp_buf & 0x40)
				dscb_valid = 1;
			if (*temp_buf & 0x20)
				eth_pe_duration = 1;
			if (*temp_buf & 0x10)
				grp_addr_bu_ind_limit = 1;
			if (*temp_buf & 0x04)
				grp_addr_bu_ind_exponent = 1;
			db->eht_operation_information_valid = eht_op_info_valid;
			temp_buf += 1;
			left -= 1;
			debug(DEBUG_TRACE, "%d: eht_op_info_valid %d dscb_valid %d eth_pe_duration %d\n",
				__LINE__, eht_op_info_valid, dscb_valid, eth_pe_duration);
			debug(DEBUG_TRACE, "%d: grp_addr_bu_ind_limit %d, grp_addr_bu_ind_exponent %d\n",
				__LINE__, grp_addr_bu_ind_limit, grp_addr_bu_ind_exponent);

			if (left < sizeof(struct eht_mcs_nss)) {
				debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
					__LINE__, left, (int)sizeof(struct eht_mcs_nss));
				return -1;
			}
			/* Basic EHT-MCS And Nss Set */
			os_memcpy(&db->eht_mcs_nss_set, temp_buf, sizeof(struct eht_mcs_nss));
			temp_buf += sizeof(struct eht_mcs_nss);
			left -= sizeof(struct eht_mcs_nss);

			if (left < 5) {
				debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
					__LINE__, left, 5);
				return -1;
			}
			/* control */
			db->control = *temp_buf++;
			left--;
			/* ccfs0 */
			db->ccfs0 = *temp_buf++;
			left--;
			/* ccfs1 */
			db->ccfs1 = *temp_buf++;
			left--;

			/* dscb */
			db->dscb_bitmap = *(unsigned short *)temp_buf;
			db->dscb_bitmap = be_to_host16(db->dscb_bitmap);
			debug(DEBUG_TRACE, "%d: dscb_bitmap %d\n", __LINE__, db->dscb_bitmap);
			temp_buf += 2;
			left -= 2;

			/* reserved 16 bytes */
			if (left < 16) {
				debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
					__LINE__, left, 16);
				return -1;
			}
			temp_buf += 16;
			left -= 16;
		}

		/* reserved 25 bytes */
		if (left < 25) {
			debug(DEBUG_ERROR, "%d: error left %d less than %d\n",
				__LINE__, left, 25);
			return -1;
		}
		temp_buf += 25;
		left -= 25;
	}

	return 0;
}

