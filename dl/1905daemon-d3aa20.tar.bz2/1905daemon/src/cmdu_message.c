
/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */

#include <stdio.h>
#include<stdlib.h>
#include <string.h>
#include <net/if.h>
#include <syslog.h>
#include <assert.h>
#include <linux/if_ether.h>
#include <asm/byteorder.h>
#include <pthread.h>
#include "cmdu_message.h"
#include "cmdu_tlv.h"
#include "debug.h"
#include "eloop.h"
#include "p1905_database.h"
#include "multi_ap.h"
#include "_1905_lib_io.h"
#include "wsc_attr_tlv.h"
#ifdef MAP_R3
#include "security_engine.h"
#endif
#ifdef EM_PLUS_SUPPORT
#include "emplus.h"
#endif

unsigned char *get_tlv_buffer(struct p1905_managerd_ctx *ctx)
{
	return ctx->tlv_buf.buf;
}

/**
 *  create topology discovery message.
 *
 * \param  buf  pointer to cmdu message header start position.
 * \param  al_mac  pointer of local abstraction layer mac address.
 * \param  itf_mac  pointer of transmitting ibterface mac address.
 * \return length of total tlvs included in this message
 */
unsigned short create_topology_discovery_message(
	struct p1905_managerd_ctx *ctx, unsigned char *buf,
	unsigned char *al_mac, unsigned char *itf_mac,
	unsigned short vs_len, unsigned char *vs_info)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;

    msg_hdr = (cmdu_message_header*)buf;

    /*fill into tlvs*/
    length = append_1905_al_mac_addr_type_tlv(tlv_temp_buf,al_mac);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    length = append_mac_addr_type_tlv(tlv_temp_buf,itf_mac);
    total_tlvs_length += length;
    tlv_temp_buf += length;

	/*add vendor specific info if necessary*/
	if (vs_len != 0 && vs_info != NULL) {
		os_memcpy(tlv_temp_buf, vs_info, vs_len);
		total_tlvs_length += vs_len;
    	tlv_temp_buf += vs_len;
	}

    length = append_end_of_tlv(tlv_temp_buf);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    /*tlvs size is less than (46(minimun ethernet frame payload size)
     *-8(cmdu header size)) ==>padding
     */
    if(total_tlvs_length < MIN_TLVS_LENGTH)
    {
	    memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
	    total_tlvs_length = MIN_TLVS_LENGTH;
    }

    //0x00: for this version of the specification
    //0x01~0xFF: Reserved Values
    msg_hdr->message_version = 0x0;

    //set reserve field to 0
    msg_hdr->reserved_field_0 = 0x0;
    msg_hdr->message_type = host_to_be16(TOPOLOGY_DISCOVERY);
    msg_hdr->relay_indicator = 0x0;
    //set reserve field to 0
    msg_hdr->reserve_field_1 = 0x0;

    return total_tlvs_length;
}

/**
 *  create topology discovery message.
 *
 * \param  buf  pointer to cmdu message header start position.
 * \param  al_mac  pointer of local abstraction layer mac address.
 * \param  itf_mac  pointer of transmitting ibterface mac address.
 * \return length of total tlvs included in this message
 */
unsigned short create_vendor_specific_topology_discovery_message(
	struct p1905_managerd_ctx *ctx, unsigned char *buf,
	unsigned char *al_mac, unsigned char *itf_mac,
	unsigned short vs_len, unsigned char *vs_info)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;

    msg_hdr = (cmdu_message_header*)buf;

	/*add vendor specific info if necessary*/
	if (vs_len != 0 && vs_info != NULL) {
		os_memcpy(tlv_temp_buf, vs_info, vs_len);
		total_tlvs_length += vs_len;
    	tlv_temp_buf += vs_len;
	} else {
		return 0;
	}

    /*fill into tlvs*/
    length = append_1905_al_mac_addr_type_tlv(tlv_temp_buf,al_mac);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    length = append_mac_addr_type_tlv(tlv_temp_buf,itf_mac);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    length = append_end_of_tlv(tlv_temp_buf);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    /*tlvs size is less than (46(minimun ethernet frame payload size)
     *-8(cmdu header size)) ==>padding
     */
    if(total_tlvs_length < MIN_TLVS_LENGTH)
    {
	    memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
	    total_tlvs_length = MIN_TLVS_LENGTH;
    }

    //0x00: for this version of the specification
    //0x01~0xFF: Reserved Values
    msg_hdr->message_version = 0x0;

    //set reserve field to 0
    msg_hdr->reserved_field_0 = 0x0;
    msg_hdr->message_type = host_to_be16(VENDOR_SPECIFIC);
    msg_hdr->relay_indicator = 0x0;
    //set reserve field to 0
    msg_hdr->reserve_field_1 = 0x0;

    return total_tlvs_length;
}

/**
 *  create topology query message.
 *
 * \param  buf  pointer to cmdu message header start position.
 * \return length of total tlvs included in this message
 */
unsigned short create_topology_query_message(unsigned char *buf,  struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;

	msg_hdr = (cmdu_message_header *)buf;
	if (ctx->map_version >= DEV_TYPE_R2) {
		length = append_map_version_tlv(tlv_temp_buf, ctx->map_version);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}

#ifdef MAP_R2
	length = append_r2_cap_tlv(tlv_temp_buf, &(ctx->ap_cap_entry.ap_r2_cap));
	total_tlvs_length += length;
	tlv_temp_buf += length;
#endif

    length = append_end_of_tlv(tlv_temp_buf);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    /*tlvs size is less than (46(minimun ethernet frame payload size)
     *-8(cmdu header size)) ==>padding
     */
    if(total_tlvs_length < MIN_TLVS_LENGTH)
    {
	    memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
	    total_tlvs_length = MIN_TLVS_LENGTH;
    }

    //0x00: for this version of the specification
    //0x01~0xFF: Reserved Values
    msg_hdr->message_version = 0x0;

    //set reserve field to 0
    msg_hdr->reserved_field_0 = 0x0;
    msg_hdr->message_type = host_to_be16(TOPOLOGY_QUERY);
    msg_hdr->relay_indicator = 0x0;
    //set reserve field to 0
    msg_hdr->reserve_field_1 = 0x0;

    return total_tlvs_length;
}

/**
 *  create topology response message.
 *
 * \param  buf  pointer to cmdu message header start position.
 * \param  al_mac  pointer of local abstraction layer mac address.
 * \param  itf_list  pointer of local interfaces information.
 * \param  br_cap_list  pointer of local internal bridge information.
 * \param  p1905_dev  pointer of 1905.1 neighbor devices information.
 * \param  non_p1905_dev poniter of non-1905.1 device information
 * \param  tpgr_list  list head of received topology response database
 * \return length of total tlvs included in this message
 */
unsigned short create_topology_response_message(unsigned char *buf,
    unsigned char *al_mac, struct p1905_managerd_ctx* ctx,
    struct bridge_capabiltiy *br_cap_list, struct p1905_neighbor *p1905_dev,
    struct non_p1905_neighbor *non_p1905_dev, struct list_head_tprdb *tpgr_head,
    unsigned char service, struct list_head_oper_bss *opbss_head,
    struct list_head_assoc_clients *asscli_head, unsigned int cnt)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
    cmdu_message_header *msg_hdr;
    unsigned short length = 0;
    unsigned short total_tlvs_length =0;
    int i = 0;
    unsigned char seperate = 0;
#ifdef MAP_R6
	struct assoc_client *client = NULL;
#endif

    msg_hdr = (cmdu_message_header*)buf;

    length = append_device_info_type_tlv(tlv_temp_buf, al_mac, ctx);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    length = append_device_bridge_capability_type_tlv(tlv_temp_buf,
                                                      br_cap_list);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    for (i=0; i<ctx->itf_number; i++) {
       do {
	       length = append_p1905_neighbor_device_type_tlv(tlv_temp_buf, p1905_dev,
	                    i, &seperate);
	        total_tlvs_length += length;
	        tlv_temp_buf += length;
	       } while(seperate);
    }

    seperate = 0;
    /*append non-p1905.1 device tlv*/
    for(i=0; i<ctx->itf_number; i++)
    {
        do
        {
            length = append_non_p1905_neighbor_device_type_tlv(tlv_temp_buf,
                     non_p1905_dev,i, &seperate);
            total_tlvs_length += length;
            tlv_temp_buf += length;
        }while(seperate);
    }

	length = append_supported_service_tlv(tlv_temp_buf, service);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_operational_bss_tlv(ctx, tlv_temp_buf, opbss_head);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_associated_clients_tlv(tlv_temp_buf, asscli_head);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	if (ctx->map_version >= MAP_PROFILE_R2) {
		length = append_map_version_tlv(tlv_temp_buf, ctx->map_version);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}

#ifdef MAP_R3
	if (ctx->map_version >= MAP_PROFILE_R3) {
		length = append_bss_config_report_tlv(tlv_temp_buf, ctx);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}
#endif // MAP_R3

#ifdef EM_PLUS_SUPPORT
	/*append non-p1905.1 device tlv*/
	length = append_emplus_non_1905_neighbor_device_type_tlv(ctx, tlv_temp_buf, non_p1905_dev);
	total_tlvs_length += length;
	tlv_temp_buf += length;
	/*append neighbor p1905.1 device tlv*/
	length = append_emplus_1905_neighbor_device_type_tlv(ctx, tlv_temp_buf, p1905_dev);
	total_tlvs_length += length;
	tlv_temp_buf += length;
	/*append emplus ethernet interface tlv*/
	length = append_emplus_eth_interface_tlv(ctx, tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;
#endif /*EM_PLUS_SUPPORT*/

	length = append_bss_mld_report_vendor_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/* Zero or one MLO Agent BSS Configuration TLV */
	length = append_own_ap_mld_config_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

#ifdef MAP_R6
	/* Zero or more Associated STA MLD Configuration Report TLV */
	for (i = 0; i < HASH_TABLE_SIZE; i++) {
		if (dl_list_empty(&ctx->clients_table[i]))
			continue;
		dl_list_for_each(client, &ctx->clients_table[i], struct assoc_client, entry) {
			if (dl_list_empty(&client->sta_mld.mlo_sta_list))
				continue;
			length = append_assoc_sta_mld_cfg_rpt_tlv(&client->sta_mld, tlv_temp_buf);
			total_tlvs_length += length;
			tlv_temp_buf += length;
		}
	}
#endif


	if (ctx->role == AGENT) {
#ifdef MAP_R6

		/* Zero or one MLO Backhaul STA Configuration TLV */
		length = append_bsta_mld_config_tlv(tlv_temp_buf, ctx, al_mac);
		total_tlvs_length += length;
		tlv_temp_buf += length;

		/* Zero or one Backhaul STA Radio Capabilities TLV format */
		for (i = 0; i < ctx->itf_number; i++) {
			if (ctx->itf[i].is_wifi_sta) {
				length = append_backhaul_sta_radio_cap_tlv(tlv_temp_buf, ctx->itf[i].identifier, ctx->itf[i].mac_addr);
				total_tlvs_length += length;
				tlv_temp_buf += length;
			}
		}
#endif
		/* Zero or more TID-to-Link Mapping TLVs */
		length = append_agent_t2lm_config_tlv(tlv_temp_buf, ctx);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}

#ifdef BR_IP_TLV_SUPPORT
	if (ctx->include_brinfo_tlv) {
		length = append_br_ip_vendor_tlv(tlv_temp_buf, ctx);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}
#endif  /* BR_IP_TLV_SUPPORT */

	reset_stored_tlv(ctx);
	store_revd_tlvs(ctx, ctx->tlv_buf.buf, total_tlvs_length);
	os_get_time(&ctx->own_topo_rsp_update_time);
	_1905_notify_topology_rsp_event(ctx, ctx->p1905_al_mac_addr, ctx->p1905_al_mac_addr);

    length = append_end_of_tlv(tlv_temp_buf);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    /*tlvs size is less than (46(minimun ethernet frame payload size)
     *-8(cmdu header size)) ==>padding
     */
    if(total_tlvs_length < MIN_TLVS_LENGTH)
    {
	    memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
	    total_tlvs_length = MIN_TLVS_LENGTH;
    }

    //0x00: for this version of the specification
    //0x01~0xFF: Reserved Values
    msg_hdr->message_version = 0x0;

    //set reserve field to 0
    msg_hdr->reserved_field_0 = 0x0;
    msg_hdr->message_type = host_to_be16(TOPOLOGY_RESPONSE);
    msg_hdr->relay_indicator = 0x0;
    //set reserve field to 0
    msg_hdr->reserve_field_1 = 0x0;

    return total_tlvs_length;
}

/**
 *  create topology notification message.
 *
 * \param  buf  pointer to cmdu message header start position.
 * \param  al_mac  pointer of local abstraction layer mac address.
 * \return length of total tlvs included in this message
 */
unsigned short create_topology_notification_message(
	struct p1905_managerd_ctx *ctx, unsigned char *buf,
	unsigned char *al_mac, struct map_client_association_event *assoc_evt,
	unsigned char notifier, unsigned short vs_len, unsigned char *vs_info)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;

    msg_hdr = (cmdu_message_header*)buf;

    length = append_1905_al_mac_addr_type_tlv(tlv_temp_buf,al_mac);
    total_tlvs_length += length;
    tlv_temp_buf += length;
	if (notifier) {
		length = append_client_assoc_event_tlv(tlv_temp_buf, assoc_evt);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}

	/*add vendor specific info if necessary*/
	if (vs_len != 0 && vs_info != NULL) {
		os_memcpy(tlv_temp_buf, vs_info, vs_len);
		total_tlvs_length += vs_len;
    	tlv_temp_buf += vs_len;
	}

    length = append_end_of_tlv(tlv_temp_buf);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    /*tlvs size is less than (46(minimun ethernet frame payload size)
     *-8(cmdu header size)) ==>padding
     */
    if(total_tlvs_length < MIN_TLVS_LENGTH)
    {
	    memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
	    total_tlvs_length = MIN_TLVS_LENGTH;
    }

    //0x00: for this version of the specification
    //0x01~0xFF: Reserved Values
    msg_hdr->message_version = 0x0;

    //set reserve field to 0
    msg_hdr->reserved_field_0 = 0x0;
    msg_hdr->message_type = host_to_be16(TOPOLOGY_NOTIFICATION);
    /* topology notification is a relay multicast message,
     * so set relay_indicator
     */
    msg_hdr->relay_indicator = 0x1;
    //set reserve field to 0
    msg_hdr->reserve_field_1 = 0x0;

    return total_tlvs_length;
}

/**
 *  create vendor specific message.
 *
 * \param  buf  pointer to cmdu message header start position.
 * \param  vs_info  vendor specific information.
 * \return length of total tlvs included in this message
 */
unsigned short create_vendor_specific_message(unsigned char *buf,
                        struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;

    msg_hdr = (cmdu_message_header*)buf;


	length = append_send_tlv(tlv_temp_buf, ctx);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    length = append_end_of_tlv(tlv_temp_buf);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    /*tlvs size is less than (46(minimun ethernet frame payload size)
     *-8(cmdu header size)) ==>padding
     */
    if(total_tlvs_length < MIN_TLVS_LENGTH)
    {
	    memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
	    total_tlvs_length = MIN_TLVS_LENGTH;
    }

    //0x00: for this version of the specification
    //0x01~0xFF: Reserved Values
    msg_hdr->message_version = 0x0;
    //set reserve field to 0
    msg_hdr->reserved_field_0 = 0x0;
    msg_hdr->message_type = host_to_be16(VENDOR_SPECIFIC);
    msg_hdr->relay_indicator = 0x0;
    //set reserve field to 0
    msg_hdr->reserve_field_1 = 0x0;

    return total_tlvs_length;
}

/**
 *  create link metric query message.
 *
 * \param  buf  pointer to cmdu message header start position.
 * \param  target_al_mac  0: all neighbors, otherwise, mac address of target.
 * \param  type  TX_METRICS_ONLY/RX_METRICS_ONLY/BOTH_TX_AND_RX_METRICS.
 * \return length of total tlvs included in this message
 */
unsigned short create_link_metrics_query_message(
	struct p1905_managerd_ctx *ctx, unsigned char *buf,
	unsigned char *target_al_mac, unsigned char type)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;

    msg_hdr = (cmdu_message_header*)buf;

    //fill into tlvs
    length = append_link_metrics_query_type_tlv(tlv_temp_buf, target_al_mac, type);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    length = append_end_of_tlv(tlv_temp_buf);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    /*tlvs size is less than (46(minimun ethernet frame payload size)
     *-8(cmdu header size)) ==>padding
     */
    if(total_tlvs_length < MIN_TLVS_LENGTH)
    {
	    memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
	    total_tlvs_length = MIN_TLVS_LENGTH;
    }

    //0x00: for this version of the specification
    //0x01~0xFF: Reserved Values
    msg_hdr->message_version = 0x0;

    //set reserve field to 0
    msg_hdr->reserved_field_0 = 0x0;
    msg_hdr->message_type = host_to_be16(LINK_METRICS_QUERY);
    msg_hdr->relay_indicator = 0x0;
    //set reserve field to 0
    msg_hdr->reserve_field_1 = 0x0;

    return total_tlvs_length;
}

/**
 *  create link metric response message.
 *
 * \param  buf  pointer to cmdu message header start position.
 * \param  target_al_mac  0: all neighbors, otherwise, mac address of target.
 * \param  type  TX_METRICS_ONLY/RX_METRICS_ONLY/BOTH_TX_AND_RX_METRICS.
 * \param  local_al_mac  local AL mac.
 * \param  itf_list  pointer of local interfaces information.
 * \param  tpd_head  list head of topology discovery database .
 * \return length of total tlvs included in this message
 */
unsigned short create_link_metrics_response_message(unsigned char *buf,
        unsigned char *target_al_mac, unsigned char type,
        unsigned char *local_al_mac, struct p1905_interface *itf_list,
        struct p1905_neighbor *devlist, struct list_head_tpddb *tpd_head,
        struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
    cmdu_message_header *msg_hdr;
    unsigned short length = 0;
    unsigned short total_tlvs_length =0;

    msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	tlv_temp_buf += length;
	total_tlvs_length += length;

    length = append_end_of_tlv(tlv_temp_buf);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    /*tlvs size is less than (46(minimun ethernet frame payload size)
     *-8(cmdu header size)) ==>padding
     */
    if(total_tlvs_length < MIN_TLVS_LENGTH)
    {
	    memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
	    total_tlvs_length = MIN_TLVS_LENGTH;
    }

    //0x00: for this version of the specification
    //0x01~0xFF: Reserved Values
    msg_hdr->message_version = 0x0;

    //set reserve field to 0
    msg_hdr->reserved_field_0 = 0x0;
    msg_hdr->message_type = host_to_be16(LINK_METRICS_RESPONSE);
    msg_hdr->relay_indicator = 0x0;
    //set reserve field to 0
    msg_hdr->reserve_field_1 = 0x0;

    return total_tlvs_length;
}

unsigned short ap_autoconfiguration_search_message(
        unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;
	unsigned char service = ctx->service;
	unsigned char band = IEEE802_11_band_5GL;
	unsigned char radio_index = 0;

    msg_hdr = (cmdu_message_header*)buf;

    length = append_1905_al_mac_addr_type_tlv(tlv_temp_buf, ctx->p1905_al_mac_addr);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    length = append_searched_role_tlv(tlv_temp_buf);
    total_tlvs_length += length;
    tlv_temp_buf += length;

	/*find controller state*/
	if (ctx->send_tlv_len != 0) {
		band = ctx->send_tlv[0];
	} else {
		if (ctx->current_autoconfig_info.radio_index == -1)
			band = os_random() % 2;
		else {
			radio_index = (unsigned char)ctx->current_autoconfig_info.radio_index;
			if (ctx->rinfo[radio_index].band & BAND_2G_CAP)
				band = IEEE802_11_band_2P4G;
			else if (ctx->rinfo[radio_index].band & BAND_5G_CAP)
				band = IEEE802_11_band_5GL;
			else if (ctx->rinfo[radio_index].band & BAND_6G_CAP)
				band = IEEE802_11_band_6G;
		}
	}
    length = append_autoconfig_freq_band_tlv(tlv_temp_buf, band);
    total_tlvs_length += length;
    tlv_temp_buf += length;

	length = append_supported_service_tlv(tlv_temp_buf, service);
    total_tlvs_length += length;
    tlv_temp_buf += length;

	length = append_searched_service_tlv(tlv_temp_buf);
    total_tlvs_length += length;
    tlv_temp_buf += length;

	if (ctx->map_version >= DEV_TYPE_R2) {
		length = append_map_version_tlv(tlv_temp_buf, ctx->map_version);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}

#ifdef MAP_R2
	length = append_r2_cap_tlv(tlv_temp_buf, &(ctx->ap_cap_entry.ap_r2_cap));
	total_tlvs_length += length;
	tlv_temp_buf += length;
#endif

#ifdef MAP_R3
	if ((ctx->map_version == (unsigned char)MAP_PROFILE_R3) && (!ctx->r3_dpp.onboarding_type)) {
		/* only append chirp tlv while eth case in R4 spec
		** but alwasy append chirp tlv in both eth and wifi case in R3 spec
		** workaround here to make sure R3 cert can pass
		** need add map_ver=R4 in future
		*/
		if (ctx->MAP_Cer || (ctx->r3_oboard_ctx.bh_type == MAP_BH_ETH)) {
			/* include a DPP Chirp Value TLV
			** Hash Validity bit to 1 and Enrollee MAC Address Present field to 0
			*/
			struct chirp_tlv_info chirp;
			struct hash_value_item *hv_item = NULL;

			hv_item = dl_list_first(&ctx->r3_dpp.hash_value_list, struct hash_value_item, member);
			if (hv_item && hv_item->hashLen > 0) {
				chirp.enrollee_mac_address_present = 0;
				chirp.hash_validity = 1;
				chirp.hash_len = hv_item->hashLen;
				os_memcpy(chirp.hash_payload, hv_item->hashValue, hv_item->hashLen);
				length = append_dpp_chirp_value_tlv(tlv_temp_buf, &chirp);
				total_tlvs_length += length;
				tlv_temp_buf += length;
			}
		}
	}
#endif // MAP_R3
#ifdef EM_PLUS_SUPPORT
	if (ctx->feature_prof.master_ver != 0) {
		length = append_emplus_feature_prof_tlv(tlv_temp_buf, &ctx->feature_prof);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}
#endif /*EM_PLUS_SUPPORT*/

	length = append_end_of_tlv(tlv_temp_buf);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    /*tlvs size is less than (46(minimun ethernet frame payload size)
     *-8(cmdu header size)) ==>padding
     */
    if(total_tlvs_length < MIN_TLVS_LENGTH)
    {
	    memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
	    total_tlvs_length = MIN_TLVS_LENGTH;
    }

    //0x00: for this version of the specification
    //0x01~0xFF: Reserved Values
    msg_hdr->message_version = 0x0;

    //set reserve field to 0
    msg_hdr->reserved_field_0 = 0x0;
    msg_hdr->message_type = host_to_be16(AP_AUTOCONFIG_SEARCH);
    /*AP autoconfiguration search message is a multicast relay message*/
    msg_hdr->relay_indicator = 0x1;
    //set reserve field to 0
    msg_hdr->reserve_field_1 = 0x0;

    return total_tlvs_length;
}

unsigned short ap_autoconfiguration_response_message(
        unsigned char *buf, unsigned char *dmac, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;
	unsigned char band = 0;
	unsigned char service = 0;
	struct controller_capability contr_cap = {1, 0};
	u8 map_ver = 0;
	struct agent_list_db *agent_info = NULL;

	find_agent_info(ctx, dmac, &agent_info);
	msg_hdr = (cmdu_message_header *)buf;

    length = append_supported_role_tlv(tlv_temp_buf);
    total_tlvs_length += length;
    tlv_temp_buf += length;

	band = ctx->peer_search_band;
	length = append_supported_freq_band_tlv(tlv_temp_buf, band);
	total_tlvs_length += length;
	tlv_temp_buf += length;

#ifdef EM_LUS_SUPPORT
	length = append_supported_service_tlv(tlv_temp_buf, ctx->role);
#else
	length = append_supported_service_tlv(tlv_temp_buf, service);
#endif
	total_tlvs_length += length;
	tlv_temp_buf += length;

#ifdef MAP_R6
	contr_cap.early_apcap = 1;
#endif
	length = append_controller_cap_tlv(tlv_temp_buf, contr_cap);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	if (agent_info) {
		if (agent_info->profile == MAP_PROFILE_R1 ||
			agent_info->profile == MAP_PROFILE_REVD) {
			map_ver = MAP_PROFILE_R1;
		} else if (agent_info->profile == MAP_PROFILE_R2) {
			map_ver = MAP_PROFILE_R2;
		} else if (agent_info->profile >= MAP_PROFILE_R3) {
			map_ver = MAP_PROFILE_R3;
		}

		if (map_ver >= DEV_TYPE_R2) {
			length = append_map_version_tlv(tlv_temp_buf, map_ver);
			total_tlvs_length += length;
			tlv_temp_buf += length;
		}
	}

#ifdef MAP_R3
	struct r3_member *peer = NULL;
	peer = get_r3_member(dmac);
	if (peer) {

		if ((ctx->map_version == (unsigned char)MAP_PROFILE_R3) && (!ctx->r3_dpp.onboarding_type)) {
	        /* Hash Validity bit to 1 and Enrollee MAC Address Present field to 0 */
	        struct chirp_tlv_info chirp;
			struct hash_value_item *hv_item = NULL, *hv_item_nxt = NULL;

			dl_list_for_each_safe(hv_item, hv_item_nxt,
				&ctx->r3_dpp.hash_value_list, struct hash_value_item, member) {
				if ((os_memcmp(hv_item->almac, peer->al_mac, ETH_ALEN) == 0)
					&& (hv_item->hashLen > 0)) {
					hex_dump_info("item hash", hv_item->hashValue, sizeof(hv_item->hashValue));
					debug(DEBUG_ERROR, "append dpp chirp value tlv\n");
					chirp.enrollee_mac_address_present = 0;
					chirp.hash_validity = 1;
					chirp.hash_len = hv_item->hashLen;
					os_memcpy(chirp.hash_payload, hv_item->hashValue, hv_item->hashLen);
					length = append_dpp_chirp_value_tlv(tlv_temp_buf, &chirp);
					total_tlvs_length += length;
					tlv_temp_buf += length;
					break;
				}
			}

			length = append_1905_layer_security_tlv(tlv_temp_buf);
			total_tlvs_length += length;
			tlv_temp_buf += length;
		}
	}
	else {
		debug(DEBUG_ERROR, "can't find r3 member by "MACSTR"\n", MAC2STR(dmac));
	}
#endif // MAP_R3

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/* tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	*/
	if (total_tlvs_length < MIN_TLVS_LENGTH) {
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	/* 0x00: for this version of the specification
	 * 0x01~0xFF: Reserved Values
	*/
	msg_hdr->message_version = 0x0;

	/* set reserve field to 0 */
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(AP_AUTOCONFIG_RESPONSE);
	msg_hdr->relay_indicator = 0x0;
	/* set reserve field to 0 */
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}

unsigned short ap_autoconfiguration_renew_message(
        unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;
	unsigned char band = 0;

    msg_hdr = (cmdu_message_header*)buf;

    length = append_1905_al_mac_addr_type_tlv(tlv_temp_buf, ctx->p1905_al_mac_addr);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    length = append_supported_role_tlv(tlv_temp_buf);
    total_tlvs_length += length;
    tlv_temp_buf += length;
	if(ctx->send_tlv_len != 0)
	{
		band = ctx->send_tlv[0];
		debug(DEBUG_TRACE, "insert renew message for band(%s)\n", band ? "5g" : "2g");
	}

    length = append_supported_freq_band_tlv(tlv_temp_buf, band);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    length = append_end_of_tlv(tlv_temp_buf);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    /*tlvs size is less than (46(minimun ethernet frame payload size)
     *-8(cmdu header size)) ==>padding
     */
    if(total_tlvs_length < MIN_TLVS_LENGTH)
    {
	    memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
	    total_tlvs_length = MIN_TLVS_LENGTH;
    }

    //0x00: for this version of the specification
    //0x01~0xFF: Reserved Values
    msg_hdr->message_version = 0x0;

    //set reserve field to 0
    msg_hdr->reserved_field_0 = 0x0;
    msg_hdr->message_type = host_to_be16(AP_AUTOCONFIG_RENEW);
    msg_hdr->relay_indicator = 0x1;
    //set reserve field to 0
    msg_hdr->reserve_field_1 = 0x0;

    return total_tlvs_length;
}


unsigned short ap_autoconfiguration_wsc_message(
        unsigned char *buf, struct p1905_managerd_ctx *ctx, unsigned char *al_mac, unsigned char wsc_type)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;
	unsigned char radio_index = 0;
	unsigned char total_bss_config_num = 0;
	struct radio_info *r = NULL;
	msg_hdr = (cmdu_message_header *)buf;
	struct ap_mlo_cap_db *mlo_entry = NULL;

	if (ctx->role == AGENT && wsc_type == MESSAGE_TYPE_M1) {
		/*1. WSC tlv*/
		length = append_WSC_tlv(tlv_temp_buf, ctx, wsc_type, NULL, 0);
		total_tlvs_length += length;
		tlv_temp_buf += length;

		/*2. AP radio basic capa tlv*/
		if (ctx->current_autoconfig_info.radio_index != -1) {
			radio_index = (unsigned char)ctx->current_autoconfig_info.radio_index;
			r = &ctx->rinfo[radio_index];
			length = append_ap_radio_basic_capability_tlv(ctx, tlv_temp_buf, r);
			total_tlvs_length += length;
			tlv_temp_buf += length;

#ifdef MAP_R2
			if (ctx->map_version >= DEV_TYPE_R2) {
				struct ap_radio_advan_cap cap;

				os_memcpy(cap.radioid, r->identifier, ETH_ALEN);
				cap.flag = 0;
				cap.flag |= (AP_CAPA_COMB_FRONTBACK | AP_CAPA_COMB_PROFILE1_PROFILE2);
#ifdef MAP_R5
				cap.flag |= (ctx->config_adv_capability & 0x3C);
#endif

				/*4. AP radio advanced tlv*/
				length = append_ap_radio_advan_tlv(tlv_temp_buf, &cap);
				total_tlvs_length += length;
				tlv_temp_buf += length;
			}
#endif
		} else {
			debug(DEBUG_ERROR, AUTO_CONFIG_PREX"error radio_index == -1!!!\n");
		}
#ifdef MAP_R2
		if (ctx->map_version >= DEV_TYPE_R2) {
			/*5. Map R2 capability tlv*/
			length = append_r2_cap_tlv(tlv_temp_buf, &(ctx->ap_cap_entry.ap_r2_cap));
			total_tlvs_length += length;
			tlv_temp_buf += length;
		}
#endif
		if (r) {
			SLIST_FOREACH(mlo_entry, &ctx->ap_cap_entry.ap_mlo_cap_head, entry) {
				if (memcmp(r->identifier, mlo_entry->identifier, ETH_ALEN))
					continue;
				length = append_mlo_cap_announce_vendor_tlv(tlv_temp_buf, mlo_entry);
				total_tlvs_length += length;
				tlv_temp_buf += length;
				break;
			}
		}
	} else if (ctx->role == CONTROLLER) {
		if (wsc_type == MESSAGE_TYPE_M2) {
			struct agent_list_db *agent = NULL;
			struct agent_radio_info *agent_radio = NULL;

			/*clear bss configed bitmap to prepare to determine bss config for each M2*/
			os_memset(ctx->bss_config_bitmap, 0, sizeof(ctx->bss_config_bitmap));
			find_agent_info(ctx, al_mac, &agent);
			if (agent)
				agent_radio = find_agent_wsc_doing_radio(agent);

			if (!agent_radio) {
				debug(DEBUG_ERROR, AUTO_CONFIG_PREX"!!!!!no wsc doing radio on agent"MACSTR"\n",
					PRINT_MAC(al_mac));
				return 0;
			}

			/*1. WSC tlv*/
			total_bss_config_num = agent_radio->max_bss_num < ctx->bss_config_num ?
				agent_radio->max_bss_num : ctx->bss_config_num;
			/*send tear down on this radio*/
			if (total_bss_config_num == 0)
				total_bss_config_num = 1;

			/*tear down all bss in block bss configuratiom mechanism case*/
			if (ctx->block_bss_info.block_bss_autoconfig && agent->is_block)
				total_bss_config_num = 1;

			create_all_m2s(ctx, tlv_temp_buf, total_bss_config_num, &length, agent_radio, agent->is_block);

			total_tlvs_length += length;
			tlv_temp_buf += length;

#ifdef MAP_R6
			/* Zero or one WSC TLV (containing M8) */
			if (ctx->cred_reconfig.wps_cred_reconfig_num) {
				unsigned char idx = 0;
				unsigned char wildcard_mac[ETH_ALEN] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff};
				struct _WSC_CONFIG wsc_m8 = {0};

				for (idx = 0; idx < ctx->cred_reconfig.wps_cred_reconfig_num; idx++) {
					if (os_memcmp(ctx->cred_reconfig.data[idx].al_mac, al_mac, ETH_ALEN) &&
						os_memcmp(ctx->cred_reconfig.data[idx].al_mac, wildcard_mac, ETH_ALEN))
						continue;

					if (!agent->bsta_wsc_reconfig) {
						debug(DEBUG_ERROR, "agent "MACSTR" not support bsta wsc reconfig\n", MAC2STR(al_mac));
						continue;
					}
					debug(DEBUG_ERROR, AUTO_CONFIG_PREX"append WSC M8 for "MACSTR"\n",
					    MAC2STR(al_mac));
					wsc_m8.AuthMode = ctx->cred_reconfig.data[idx].info.auth_mode;
					wsc_m8.EncrypType = ctx->cred_reconfig.data[idx].info.encr_type;
					os_memcpy(wsc_m8.Ssid, ctx->cred_reconfig.data[idx].info.ssid,
						ctx->cred_reconfig.data[idx].info.ssid_len);
					wsc_m8.Ssid[sizeof(wsc_m8.Ssid)-1] = '\0';
					os_memcpy(wsc_m8.WPAKey, ctx->cred_reconfig.data[idx].info.key,
						ctx->cred_reconfig.data[idx].info.key_len);
					wsc_m8.WPAKey[sizeof(wsc_m8.WPAKey)-1] = '\0';
					debug(DEBUG_ERROR, AUTO_CONFIG_PREX"ssid %s\n", (char *)wsc_m8.Ssid);
					debug(DEBUG_ERROR, AUTO_CONFIG_PREX"auth mode %04x\n", wsc_m8.AuthMode);
					debug(DEBUG_ERROR, AUTO_CONFIG_PREX"encryptype %04x\n", wsc_m8.EncrypType);
					debug(DEBUG_ERROR, AUTO_CONFIG_PREX"key %s\n", (char *)wsc_m8.WPAKey);

					length = append_WSC_tlv(tlv_temp_buf, ctx, MESSAGE_TYPE_M8, &wsc_m8, 0);
					total_tlvs_length += length;
					tlv_temp_buf += length;
					break;
				}
			}
#endif

			/*2. AP radio identifier tlv*/
			length = append_ap_radio_identifier_tlv(tlv_temp_buf, agent_radio->identifier);
			total_tlvs_length += length;
			tlv_temp_buf += length;

#ifdef MAP_R2
			if (ctx->map_version >= DEV_TYPE_R2) {
				/*3. 802Q TLV*/
				length = append_default_8021Q_tlv(ctx, tlv_temp_buf, al_mac,
					ctx->bss_config_num, ctx->bss_config);
				total_tlvs_length += length;
				tlv_temp_buf += length;

				/*4. traffic separation policy TLV*/
				length = append_traffic_separation_tlv(ctx, tlv_temp_buf, al_mac,
					ctx->bss_config_num, ctx->bss_config);
				total_tlvs_length += length;
				tlv_temp_buf += length;

				/*5. vendor specific transparent vlan TLV*/
				/*decide if we need to add transparent vlan tlv*/
				if (ctx->map_policy.trans_vlan.num > 0) {
					length = append_transparent_vlan_tlv(ctx, tlv_temp_buf);
					total_tlvs_length += length;
					tlv_temp_buf += length;
				}
			}
#endif

			if (agent->ra_info[0].ap_mlo_cap) {
				/* Zero or one MLO Agent BSS Configuration TLV */
				length = append_agent_ap_mld_config_tlv(tlv_temp_buf, ctx, al_mac);
				total_tlvs_length += length;
				tlv_temp_buf += length;
			}

#ifdef MAP_R6
			if (agent->ra_info[0].sta_mlo_cap) {
				length = append_bsta_mld_config_tlv(tlv_temp_buf, ctx, al_mac);
				total_tlvs_length += length;
				tlv_temp_buf += length;
			}

#endif

#ifdef EM_PLUS_SUPPORT
			if (is_dev_wf7(ctx)) {
#endif /* EM_PLUS_SUPPORT */
				/* Zero or one eht operations tlv */
				length = append_eht_operations_tlv(ctx, tlv_temp_buf);
				total_tlvs_length += length;
				tlv_temp_buf += length;
#ifdef EM_PLUS_SUPPORT
			}
#endif /* EM_PLUS_SUPPORT */
		}


	}

	if (ctx->map_version >= DEV_TYPE_R2) {
		length = append_map_version_tlv(tlv_temp_buf, ctx->map_version);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}

#ifdef EM_PLUS_SUPPORT
	if (ctx->feature_prof.master_ver != 0) {
		length = append_emplus_feature_prof_tlv(tlv_temp_buf, &ctx->feature_prof);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}
	length = append_emplus_dev_info_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;
#endif /* EM_PLUS_SUPPORT */

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if (total_tlvs_length < MIN_TLVS_LENGTH) {
		os_memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	/* 0x00: for this version of the specification */
	/* 0x01~0xFF: Reserved Values */
	msg_hdr->message_version = 0x0;

	/* set reserve field to 0*/
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(AP_AUTOCONFIG_WSC);
	msg_hdr->relay_indicator = 0x0;
	/* set reserve field to 0 */
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}

/*MAP defined message append*/
unsigned short channel_selection_response_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{

	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

#ifdef EM_PLUS_SUPPORT
	if (is_dev_wf7(ctx)) {
#endif /* EM_PLUS_SUPPORT */
		/* Zero or one eht operations tlv */
		length = append_eht_operations_tlv(ctx, tlv_temp_buf);
		total_tlvs_length += length;
		tlv_temp_buf += length;
#ifdef EM_PLUS_SUPPORT
	}
#endif /* EM_PLUS_SUPPORT */

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(CHANNEL_SELECTION_RESPONSE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}

unsigned short channel_selection_request_message(unsigned char *buf,
	struct agent_list_db *agent, struct p1905_managerd_ctx *ctx)

{

	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;
	struct ch_prefer_db *chcap = NULL;

	msg_hdr = (cmdu_message_header*)buf;

	if(!ctx->send_tlv_len)
	{
		SLIST_FOREACH(chcap, &agent->ch_prefer_head, ch_prefer_entry)
		{
			length = append_channel_preference_tlv(tlv_temp_buf, chcap);
			total_tlvs_length += length;
			tlv_temp_buf += length;
			if (chcap->tx_power_limit) {
				length = append_transmit_power_limit_tlv(tlv_temp_buf,
					chcap->identifier, chcap->tx_power_limit);
				total_tlvs_length += length;
				tlv_temp_buf += length;
			}
		}
	}
	else
	{
		length = append_send_tlv(tlv_temp_buf, ctx);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}
	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(CHANNEL_SELECTION_REQUEST);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}

unsigned short combined_infrastructure_metrics_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx, unsigned char *dalmac)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(COMBINED_INFRASTRUCTURE_METRICS);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}

unsigned short client_steering_request_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{

	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(CLIENT_STEERING_REQUEST);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}

unsigned short client_steering_btm_report_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{

	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_client_steering_btm_report_tlv(tlv_temp_buf, &ctx->sinfo.sbtm_evt);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(CLIENT_STEERING_BTM_REPORT);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}

unsigned short client_steering_completed_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{

	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(CLIENT_STEERING_COMPLETED);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}

unsigned short map_policy_config_request_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx, unsigned char *al_mac)
{

	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

#ifdef MAP_R2
	if (ctx->MAP_Cer) {
		/* append default 8021Q setting tlv and ts policy tlv */
		length = append_default_8021Q_tlv(ctx, tlv_temp_buf, al_mac,ctx->bss_config_num, ctx->bss_config);
		total_tlvs_length += length;
		tlv_temp_buf += length;

		length = append_traffic_separation_tlv(ctx, tlv_temp_buf, al_mac,ctx->bss_config_num, ctx->bss_config);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}
#endif

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(MAP_POLICY_CONFIG_REQUEST);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}

unsigned short client_association_control_request_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{

	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(CLIENT_ASSOC_CONTROL_REQUEST);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}

unsigned short channel_preference_report_message(
        unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;

    msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

#ifdef EM_PLUS_SUPPORT
	if (is_dev_wf7(ctx)) {
#endif /* EM_PLUS_SUPPORT */
		/* Zero or one eht operations tlv */
		length = append_eht_operations_tlv(ctx, tlv_temp_buf);
		total_tlvs_length += length;
		tlv_temp_buf += length;
#ifdef EM_PLUS_SUPPORT
	}
#endif /* EM_PLUS_SUPPORT */

    length = append_end_of_tlv(tlv_temp_buf);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    /*tlvs size is less than (46(minimun ethernet frame payload size)
     *-8(cmdu header size)) ==>padding
     */
    if(total_tlvs_length < MIN_TLVS_LENGTH)
    {
	    memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
	    total_tlvs_length = MIN_TLVS_LENGTH;
    }

    //0x00: for this version of the specification
    //0x01~0xFF: Reserved Values
    msg_hdr->message_version = 0x0;

    //set reserve field to 0
    msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(CHANNEL_PREFERENCE_REPORT);
    msg_hdr->relay_indicator = 0x0;
    //set reserve field to 0
    msg_hdr->reserve_field_1 = 0x0;

    return total_tlvs_length;
}

unsigned int is_valid_primary_ch_80M_160M(unsigned char ch,
	unsigned char center_ch, unsigned char op)
{
	int offset = 0;

	offset = ch - center_ch;
	if ((op == 128)
#ifdef MAP_6E_SUPPORT
		|| (op == 133)
#endif
		) {
		if ((abs(offset) == 6) || (abs(offset) == 2))
			return 1;
		else
			return 0;
	} else if ((op == 129)
#ifdef MAP_6E_SUPPORT
		|| (op == 134)
#endif
		) {
		if ((abs(offset) == 14) || (abs(offset) == 10) ||
			(abs(offset) == 6) || (abs(offset) == 2)) {
			return 1;
		} else {
			return 0;
		}
	}
	else if (op == 137) {
		if ((abs(offset) == 30) || (abs(offset) == 26) ||
				(abs(offset) == 22) || (abs(offset) == 18) || (abs(offset) == 14) ||
				(abs(offset) == 10) || (abs(offset) == 6) || (abs(offset) == 2)) {
			return 1;
		} else {
			return 0;
		}
	}
#ifdef MAP_6E_SUPPORT
	else if (op == 132) {/* for 40MHz special case in 6E*/
		if (abs(offset) == 2)
			return 1;
		else
			return 0;
	}
#endif

	return 0;
}


unsigned short operating_channel_report_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{

	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;
	int i = 0;

	msg_hdr = (cmdu_message_header*)buf;

	for (i = 0; i < ctx->ch_rep->ch_rep_num; i++) {
		if (ctx->ch_rep->info[i].channel) {
			if ((ctx->ch_rep->info[i].op_class == 128 || ctx->ch_rep->info[i].op_class == 129
#ifdef MAP_6E_SUPPORT
				|| ctx->ch_rep->info[i].op_class == 132
				|| ctx->ch_rep->info[i].op_class == 133
				|| ctx->ch_rep->info[i].op_class == 134
				|| ctx->ch_rep->info[i].op_class == 137
#endif
			)
				&& (i < ctx->ch_rep->ch_rep_num - 1)) {
				if (is_valid_primary_ch_80M_160M(ctx->ch_rep->info[i+1].channel, ctx->ch_rep->info[i].channel,
								ctx->ch_rep->info[i].op_class)) {
					/*operating channel report for bw 80 case*/
					length = append_operating_channel_report_tlv_bw80(tlv_temp_buf, &ctx->ch_rep->info[i]);
					i++;
				} else {
					length = append_operating_channel_report_tlv(tlv_temp_buf, &ctx->ch_rep->info[i]);
				}
			} else {
				length = append_operating_channel_report_tlv(tlv_temp_buf, &ctx->ch_rep->info[i]);
			}
			total_tlvs_length += length;
			tlv_temp_buf += length;
		}
	}
#ifdef MAP_R4_SPT
	if(ctx->spt_report) {
		for (i = 0; i < ctx->spt_report->spt_rep_num; i++) {

				length = append_spatial_report_tlv(tlv_temp_buf, &ctx->spt_report->spt_reuse_report[i]);
				total_tlvs_length += length;
				tlv_temp_buf += length;
			debug(DEBUG_TRACE, GRN("[1905 bm index %d]")"bitmap "
					"0x%2x:%2x:%2x:%2x:%2x:%2x:%2x:%2x\n",i,
					ctx->spt_report->spt_reuse_report[i].srg_bss_color_bitmap[0],
					ctx->spt_report->spt_reuse_report[i].srg_bss_color_bitmap[1],
					ctx->spt_report->spt_reuse_report[i].srg_bss_color_bitmap[2],
					ctx->spt_report->spt_reuse_report[i].srg_bss_color_bitmap[3],
					ctx->spt_report->spt_reuse_report[i].srg_bss_color_bitmap[4],
					ctx->spt_report->spt_reuse_report[i].srg_bss_color_bitmap[5],
					ctx->spt_report->spt_reuse_report[i].srg_bss_color_bitmap[6],
					ctx->spt_report->spt_reuse_report[i].srg_bss_color_bitmap[7]
			);
		}
		free(ctx->spt_report);
		ctx->spt_report = NULL;
	}
#endif
	free(ctx->ch_rep);
	ctx->ch_rep = NULL;

#ifdef EM_PLUS_SUPPORT
	if (is_dev_wf7(ctx)) {
#endif /* EM_PLUS_SUPPORT */
		/* Zero or one eht operations tlv */
		length = append_eht_operations_tlv(ctx, tlv_temp_buf);
		total_tlvs_length += length;
		tlv_temp_buf += length;
#ifdef EM_PLUS_SUPPORT
	}
#endif /* EM_PLUS_SUPPORT */

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(OPERATING_CHANNEL_REPORT);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}


unsigned short channel_preference_query_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{

	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(CHANNEL_PREFERENCE_QUERY);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}

unsigned short ap_capability_query_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;

	msg_hdr = (cmdu_message_header *)buf;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	*-8(cmdu header size)) ==>padding
	*/
	if (total_tlvs_length < MIN_TLVS_LENGTH) {
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	/*0x00: for this version of the specification*/
	/*0x01~0xFF: Reserved Values*/
	msg_hdr->message_version = 0x0;

	/*set reserve field to 0*/
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(AP_CAPABILITY_QUERY);
	msg_hdr->relay_indicator = 0x0;
	/*set reserve field to 0*/
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}

unsigned short ap_capability_report_message(
	unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;
	struct ap_ht_cap_db* pdb_ht = NULL;
	struct ap_vht_cap_db* pdb_vht = NULL;
	struct ap_he_cap_db* pdb_he = NULL;
#ifdef MAP_R3_WF6
	struct ap_wf6_role_db* pdb_wf6 = NULL;
#endif /*MAP_R3_WF6*/
	unsigned char radio_index = 0;
	struct radio_info *r = NULL;
	struct ap_mlo_cap_db *mlo_cap = NULL;
#ifdef MAP_R5
	struct ap_radio_advan_cap cap;
#endif

    msg_hdr = (cmdu_message_header*)buf;

    length = append_ap_capability_tlv(tlv_temp_buf, &ctx->ap_cap_entry.ap_cap);
    total_tlvs_length += length;
    tlv_temp_buf += length;


	/*One or more AP HT Capabilities TLV from spec 17.1.7*/
	for (radio_index = 0; radio_index < ctx->radio_number; radio_index++) {
		r = &ctx->rinfo[radio_index];
		if (ctx->disable_tear_down && (r->teared_down == 1))
			continue;
		debug(DEBUG_TRACE, "radio identifier="MACSTR"\n", PRINT_MAC(r->identifier));

		length = append_ap_radio_basic_capability_tlv(ctx, tlv_temp_buf, r);
		total_tlvs_length += length;
		tlv_temp_buf += length;
#ifdef MAP_R5
		ether_addr_copy(cap.radioid, r->identifier);
		cap.flag = 0;
		cap.flag |= (AP_CAPA_COMB_FRONTBACK | AP_CAPA_COMB_PROFILE1_PROFILE2);
		cap.flag |= (ctx->config_adv_capability & 0x3C);
		length = append_ap_radio_advan_tlv(tlv_temp_buf, &cap);
		total_tlvs_length += length;
		tlv_temp_buf += length;
#endif
	}
	/*Zero or more AP HT Capabilities TLV from spec 17.1.7*/
	SLIST_FOREACH(pdb_ht, &(ctx->ap_cap_entry.ap_ht_cap_head), ap_ht_cap_entry)
	{
		debug(DEBUG_TRACE, "pdb_ht->identifier="MACSTR"\n",
			PRINT_MAC(pdb_ht->identifier));
		if (ctx->disable_tear_down) {
			r = NULL;
			for (radio_index = 0; radio_index < ctx->radio_number; radio_index++) {
				r = &ctx->rinfo[radio_index];
				if (!(os_memcmp(r->identifier, pdb_ht->identifier, ETH_ALEN)))
					break;
			}
			if (r && r->teared_down == 1)
				continue;
		}
		length = append_ap_ht_capability_tlv(tlv_temp_buf, pdb_ht);
		total_tlvs_length += length;
		tlv_temp_buf += length;

	}
	/*Zero or more AP VHT Capabilities TLV from spec 17.1.7*/
	SLIST_FOREACH(pdb_vht, &(ctx->ap_cap_entry.ap_vht_cap_head), ap_vht_cap_entry)
	{
		debug(DEBUG_TRACE, "pdb_vht->identifier="MACSTR"\n", PRINT_MAC(pdb_vht->identifier));
		if (ctx->disable_tear_down) {
			r = NULL;
			for (radio_index = 0; radio_index < ctx->radio_number; radio_index++) {
				r = &ctx->rinfo[radio_index];
				if (!(os_memcmp(r->identifier, pdb_vht->identifier, ETH_ALEN)))
					break;
			}
			if (r && r->teared_down == 1)
				continue;
		}
		length = append_ap_vht_capability_tlv(tlv_temp_buf, pdb_vht);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}

	SLIST_FOREACH(pdb_he, &(ctx->ap_cap_entry.ap_he_cap_head), ap_he_cap_entry)
	{
#ifdef MAP_R2
		if (!(ctx->map_version == DEV_TYPE_R2 && ctx->MAP_Cer)) {
#endif
			debug(DEBUG_TRACE, "pdb_he->identifier="MACSTR"\n",
				PRINT_MAC(pdb_he->identifier));
			if (ctx->disable_tear_down) {
				r = NULL;
				for (radio_index = 0; radio_index < ctx->radio_number; radio_index++) {
					r = &ctx->rinfo[radio_index];
					if (!(os_memcmp(r->identifier, pdb_he->identifier, ETH_ALEN)))
						break;
				}
				if (r && r->teared_down == 1)
					continue;
			}
			length = append_ap_he_capability_tlv(tlv_temp_buf, pdb_he);
			total_tlvs_length += length;
			tlv_temp_buf += length;
#ifdef MAP_R2
		}
#endif
	}

#ifdef MAP_R2
	if (ctx->map_version >= DEV_TYPE_R2) {
		struct ap_r2_capability ap_r2_cap = {0};
		/*one channel scan capability tlv*/
		length = append_channel_scan_capability_tlv(tlv_temp_buf, &(ctx->ap_cap_entry.ch_scan_cap_head));
		total_tlvs_length += length;
		tlv_temp_buf += length;

		/* One CAC Capabilities TLV */
		length = append_cac_capability_tlv(tlv_temp_buf, &(ctx->ap_cap_entry.radio_cac_cap));
		total_tlvs_length += length;
		tlv_temp_buf += length;

		/* One R2 AP Capability TLV  */
		os_memset(&ap_r2_cap, 0, sizeof(ap_r2_cap));
		os_memcpy(&ap_r2_cap, &(ctx->ap_cap_entry.ap_r2_cap), sizeof(ap_r2_cap));

		if ((ctx->cinfo.profile == MAP_PROFILE_R1) && (!ctx->cinfo.kibmib)) {
			ap_r2_cap.byte_counter_units = 0;
			debug(DEBUG_ERROR, "Controller is R1 or Controller not support KIBMIB, byte_counter_units change to bytes\n");
		}
		length = append_r2_cap_tlv(tlv_temp_buf, &ap_r2_cap);
		total_tlvs_length += length;
		tlv_temp_buf += length;

		/* One Metric Collection Interval TLV */
		length = append_metric_collection_interval_tlv(tlv_temp_buf, ctx->metric_entry.metric_collection_interval);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}
#endif // #ifdef MAP_R2

#ifdef MAP_R3_WF6
	SLIST_FOREACH(pdb_wf6, &(ctx->ap_cap_entry.ap_wf6_cap_head), ap_wf6_role_entry) {
		debug(DEBUG_TRACE, "pdb_wf6->identifier="MACSTR"\n",
			PRINT_MAC(pdb_wf6->identifier));
		if (ctx->disable_tear_down) {
			r = NULL;
			for (radio_index = 0; radio_index < ctx->radio_number; radio_index++) {
				r = &ctx->rinfo[radio_index];
				if (!(os_memcmp(r->identifier, pdb_wf6->identifier, ETH_ALEN)))
					break;
			}
			if (r && r->teared_down == 1)
				continue;
		}
		length = append_ap_wf6_capability_tlv(tlv_temp_buf, pdb_wf6);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}
#endif
#ifdef MAP_R3
	length = append_1905_layer_security_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;
#endif
#ifdef MAP_R3_DE
	length = append_dev_inven_tlv(tlv_temp_buf, &(ctx->de));
	total_tlvs_length += length;
	tlv_temp_buf += length;
#endif
	length = append_ap_eht_capability_tlv(ctx, tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*Zero or more AP MLO Capabilities TLVS*/
	SLIST_FOREACH(mlo_cap, &ctx->ap_cap_entry.ap_mlo_cap_head, entry)
	{
		length = append_mlo_cap_vendor_tlv(tlv_temp_buf, mlo_cap);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}

#ifdef EM_PLUS_SUPPORT
	if (is_dev_wf7(ctx)) {
#endif /* EM_PLUS_SUPPORT */
		/* Zero or one eht operations tlv */
		length = append_eht_operations_tlv(ctx, tlv_temp_buf);
		total_tlvs_length += length;
		tlv_temp_buf += length;

#if defined(MAP_R6) || defined(EM_PLUS_SUPPORT)
		/* Zero or one Wi-Fi 7 Agent Capabilities TLV  */
		length = append_wifi7_cap_tlv(ctx, tlv_temp_buf);
		total_tlvs_length += length;
		tlv_temp_buf += length;
#endif
#ifdef EM_PLUS_SUPPORT
	}
#endif /* EM_PLUS_SUPPORT */

#ifdef EM_PLUS_SUPPORT
	if (ctx->feature_prof.master_ver != 0) {
		length = append_emplus_feature_prof_tlv(tlv_temp_buf, &ctx->feature_prof);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}
	/*added support for radio mode sharing feature*/
	for (radio_index = 0; radio_index < ctx->radio_number; radio_index++) {
		r = &ctx->rinfo[radio_index];
		if (ctx->disable_tear_down && (r->teared_down == 1))
			continue;
		debug(DEBUG_TRACE, "radio identifier="MACSTR"\n", PRINT_MAC(r->identifier));

		length = append_emplus_ap_radio_capability_tlv(ctx, tlv_temp_buf, r);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}
#endif /* EM_PLUS_SUPPORT */

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

    /*tlvs size is less than (46(minimun ethernet frame payload size)
     *-8(cmdu header size)) ==>padding
     */
    if(total_tlvs_length < MIN_TLVS_LENGTH)
    {
	    memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
	    total_tlvs_length = MIN_TLVS_LENGTH;
    }

    //0x00: for this version of the specification
    //0x01~0xFF: Reserved Values
    msg_hdr->message_version = 0x0;

    //set reserve field to 0
    msg_hdr->reserved_field_0 = 0x0;
    msg_hdr->message_type = host_to_be16(AP_CAPABILITY_REPORT);
    msg_hdr->relay_indicator = 0x0;
    //set reserve field to 0
    msg_hdr->reserve_field_1 = 0x0;

    return total_tlvs_length;
}

unsigned short cli_capability_report_message(
        unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;
	int error_code = 0;

    msg_hdr = (cmdu_message_header*)buf;

    length = append_cli_info_tlv(tlv_temp_buf, &ctx->sinfo.cinfo);
    total_tlvs_length += length;
    tlv_temp_buf += length;
	length = append_cli_capability_report_tlv(ctx, tlv_temp_buf, &error_code);
    total_tlvs_length += length;
    tlv_temp_buf += length;

	length = append_error_code_tlv(ctx, tlv_temp_buf, error_code, ctx->sinfo.cinfo.sta_mac);
	total_tlvs_length += length;
	tlv_temp_buf += length;


    length = append_end_of_tlv(tlv_temp_buf);
    total_tlvs_length += length;
    tlv_temp_buf += length;

    /*tlvs size is less than (46(minimun ethernet frame payload size)
     *-8(cmdu header size)) ==>padding
     */
    if(total_tlvs_length < MIN_TLVS_LENGTH)
    {
	    memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
	    total_tlvs_length = MIN_TLVS_LENGTH;
    }

    //0x00: for this version of the specification
    //0x01~0xFF: Reserved Values
    msg_hdr->message_version = 0x0;

    //set reserve field to 0
    msg_hdr->reserved_field_0 = 0x0;
    msg_hdr->message_type = host_to_be16(CLIENT_CAPABILITY_REPORT);
    msg_hdr->relay_indicator = 0x0;
    //set reserve field to 0
    msg_hdr->reserve_field_1 = 0x0;

    return total_tlvs_length;
}

unsigned short cli_capability_query_message(
        unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;
	struct client_info *cinfo = NULL;

	msg_hdr = (cmdu_message_header*)buf;
	if(ctx->send_tlv_len == 0)
	{
		return total_tlvs_length;
	}
	else
	{
		cinfo = (struct client_info*)ctx->send_tlv;
		reset_send_tlv(ctx);
	}
	length = append_cli_info_tlv(tlv_temp_buf, cinfo);
    total_tlvs_length += length;
    tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(CLIENT_CAPABILITY_QUERY);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

    return total_tlvs_length;
}

int _1905_ack_message(unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

#ifdef MAP_R2
	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;
#endif

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(e_1905_ack);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

    return total_tlvs_length;
}


int high_layer_data_message(unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(e_higher_layer_data);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

    return total_tlvs_length;
}

int dev_send_1905_msg(unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	memcpy(tlv_temp_buf, ctx->pcmdu_tx_buf, ctx->cmdu_tx_buf_len);
	length = ctx->cmdu_tx_buf_len;
	total_tlvs_length += length;
    tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(ctx->cmdu_tx_msg_type);
	if (ctx->cmdu_tx_msg_type == AP_AUTOCONFIG_RENEW || ctx->cmdu_tx_msg_type == TOPOLOGY_NOTIFICATION) {
		msg_hdr->relay_indicator = 0x1;
		debug(DEBUG_TRACE, "renew msg or notification msg,relay_indicator will be turn on\n");
	} else {
		msg_hdr->relay_indicator = 0x0;
	}
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

    return total_tlvs_length;
}

unsigned short failed_connection_message(unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(FAILED_CONNECTION_MESSAGE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}

unsigned short ap_metrics_query_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(AP_LINK_METRICS_QUERY);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}


unsigned short ap_metrics_response_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	/* one AP Metrics TLV  */
	if(ctx->send_tlv_len != 0)
	{
		length = append_send_tlv(tlv_temp_buf, ctx);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(AP_LINK_METRICS_RESPONSE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}

unsigned short associated_sta_link_metrics_query_message(
	unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(ASSOC_STA_LINK_METRICS_QUERY);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}

unsigned short associated_sta_link_metrics_response_message(
	unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;


	if(ctx->send_tlv_len != 0)
	{
		length = append_send_tlv(tlv_temp_buf, ctx);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}
#ifdef MAP_R6
	{
		struct assoc_client *client = NULL;
		int i = 0;

		/* Zero or more Associated STA MLD Configuration Report TLV */
		for (i = 0; i < HASH_TABLE_SIZE; i++) {
			if (dl_list_empty(&ctx->clients_table[i]))
				continue;
			dl_list_for_each(client, &ctx->clients_table[i], struct assoc_client, entry) {
				if (dl_list_empty(&client->sta_mld.mlo_sta_list))
					continue;
				length = append_assoc_sta_mld_cfg_rpt_tlv(&client->sta_mld, tlv_temp_buf);
				total_tlvs_length += length;
				tlv_temp_buf += length;
			}
		}
	}
#endif

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(ASSOC_STA_LINK_METRICS_RESPONSE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}

unsigned short unassociated_sta_link_metrics_query_message(
	unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(UNASSOC_STA_LINK_METRICS_QUERY);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}


unsigned short unassociated_sta_link_metrics_response_message(
	unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	if(ctx->send_tlv_len != 0)
	{
		length = append_send_tlv(tlv_temp_buf, ctx);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(UNASSOC_STA_LINK_METRICS_RESPONSE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}

unsigned short beacon_metrics_response_message(
	unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	if(ctx->send_tlv_len != 0)
	{
		length = append_send_tlv(tlv_temp_buf, ctx);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(BEACON_METRICS_RESPONSE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}

unsigned short beacon_metrics_query_message(
	unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(BEACON_METRICS_QUERY);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}


unsigned short backhaul_steering_response_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(BACKHAUL_STEERING_RESPONSE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}

unsigned short backhaul_steering_request_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(BACKHAUL_STEERING_REQUEST);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}

unsigned short create_vendor_specific_wts_content_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;
	int file_len = 0, i = 0;
	int file_cut_size = 1000;
	FILE *f;

	debug(DEBUG_TRACE, "==>\n");

	/*open file*/
	f = fopen(ctx->wts_bss_cfg_file, "r");
	if (f == NULL) {
		debug(DEBUG_ERROR, "open file %s fail\n", ctx->wts_bss_cfg_file);
		return 0;
	}

	/*get file size*/
	if (fseek(f, 0, SEEK_END) != 0) {
		debug(DEBUG_ERROR, "[%d]fseek fail!\n", __LINE__);
		(void)fclose(f);
		return 0;
	}
	file_len = ftell(f);
	if (file_len >= MAX_PKT_LEN - CMDU_HLEN - ETH_HLEN - 3) {
		debug(DEBUG_ERROR, "file %s too large to send(size-%d)\n",
			ctx->wts_bss_cfg_file, file_len);
		(void)fclose(f);
		return 0;
	}

	msg_hdr = (cmdu_message_header*)buf;

	/*fill wts content info*/

	for (i = 0; i <= file_len / file_cut_size; i++) {
		if (i < file_len / file_cut_size)
			length = append_wts_content_vendor_tlv(tlv_temp_buf, f, i * file_cut_size, file_cut_size);
		else
			length = append_wts_content_vendor_tlv(tlv_temp_buf, f, i * file_cut_size, file_len % file_cut_size);
		if (!length) {
			(void)fclose(f);
			return 0;
		}
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}

	(void)fclose(f);

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	*-8(cmdu header size)) ==>padding
	*/
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(VENDOR_SPECIFIC);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}

unsigned short create_vendor_specific_bss_prio_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr = NULL;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;

	msg_hdr = (cmdu_message_header *)buf;

	length = append_bss_prio_vendor_tlv(tlv_temp_buf,
		(unsigned char *)ctx->bss_priority_str,
		os_strlen(ctx->bss_priority_str));
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	*-8(cmdu header size)) ==>padding
	*/
	if (total_tlvs_length < MIN_TLVS_LENGTH) {
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	msg_hdr->message_version = 0x0;

	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(VENDOR_SPECIFIC);
	msg_hdr->relay_indicator = 0x0;
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}

unsigned short create_vendor_specific_bss_prio_ack_message(
	unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr = NULL;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;

	msg_hdr = (cmdu_message_header *)buf;

	length = append_bss_prio_ack_vendor_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	*-8(cmdu header size)) ==>padding
	*/
	if (total_tlvs_length < MIN_TLVS_LENGTH) {
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	msg_hdr->message_version = 0x0;

	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(VENDOR_SPECIFIC);
	msg_hdr->relay_indicator = 0x0;
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}


#ifdef MAP_R2
unsigned short channel_scan_request_message(unsigned char *buf,
 	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(CHANNEL_SCAN_REQUEST);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}

unsigned short channel_scan_report_message(unsigned char *buf,
 	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(CHANNEL_SCAN_REPORT);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}



unsigned short tunneled_message(unsigned char *buf,
 	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(TUNNELED_MESSAGE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}



unsigned short assoc_status_notification_message(unsigned char *buf,
 	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	/*for this kind of message, maybe we'll send more than one(for relayed multicast)
	*so we cannot call append_send_tlv which will set send_tlv_len to 0
	*/
	length = append_send_tlv_relayed(tlv_temp_buf, ctx);
		total_tlvs_length += length;
		tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(ASSOCIATION_STATUS_NOTIFICATION);
	msg_hdr->relay_indicator = 0x1;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}


unsigned short cac_request_message(unsigned char *buf,
 	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(CAC_REQUEST);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}


unsigned short cac_terminate_message(unsigned char *buf,
 	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(CAC_TERMINATION);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}


unsigned short client_disassciation_stats_message(unsigned char *buf,
 	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(CLIENT_DISASSOCIATION_STATS);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}



unsigned short backhual_sta_cap_query_message(unsigned char *buf,
 	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(BACKHAUL_STA_CAP_QUERY_MESSAGE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}

unsigned short backhual_sta_cap_report_message(unsigned char *buf,
 	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;
	int i = 0, r = 0;

	msg_hdr = (cmdu_message_header*)buf;


	for (r = 0; r < ctx->radio_number; r++) {
		for (i = 0; i < ctx->itf_number; i++) {
			if (ctx->itf[i].is_wifi_sta &&
				!os_memcmp(ctx->rinfo[r].identifier, ctx->itf[i].identifier, ETH_ALEN)) {
				length = append_backhaul_sta_radio_cap_tlv(tlv_temp_buf, ctx->itf[i].identifier, ctx->itf[i].mac_addr);
				total_tlvs_length += length;
				tlv_temp_buf += length;
				break;
			}
		}
		if (i >= ctx->itf_number) {
			length = append_backhaul_sta_radio_cap_tlv(tlv_temp_buf, ctx->rinfo[r].identifier, NULL);
			total_tlvs_length += length;
			tlv_temp_buf += length;
		}
	}

#ifdef MAP_R6
	length = append_cli_info_tlv(tlv_temp_buf, &ctx->sinfo.cinfo);
	total_tlvs_length += length;
	tlv_temp_buf += length;
#endif

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(BACKHAUL_STA_CAP_REPORT_MESSAGE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}


#endif

#ifdef MAP_R3
unsigned short bss_reconfiguration_trigger_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(BSS_RECONFIGURATION_TRIGGER_MESSAGE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}



unsigned short _1905_rekey_request_message(unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	/*no content*/

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	*-8(cmdu header size)) ==>padding
	*/
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(_1905_REKEY_REQUEST);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}

/* If a Decryption Failure Counter exceeds the threshold
** (configured by the Multi-AP Controller),
**the Multi-AP Agent shall send a Decryption Failure message to the Multi-AP Controller
*/
unsigned short _1905_decryption_failure_message(
	struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned char *al_mac)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	/*One 1905.1 AL MAC address type TLV*/

	length = append_1905_al_mac_addr_type_tlv(tlv_temp_buf, al_mac);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	*-8(cmdu header size)) ==>padding
	*/
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(_1905_DECRYPTION_FAILURE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}


unsigned short proxied_encap_dpp_message(unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = ctx->send_tlv_len;
	memcpy(tlv_temp_buf, ctx->send_tlv, ctx->send_tlv_len);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(PROXIED_ENCAP_DPP_MESSAGE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}



unsigned short direct_encap_dpp_message(unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = ctx->send_tlv_len;
	memcpy(tlv_temp_buf, ctx->send_tlv, ctx->send_tlv_len);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(DIRECT_ENCAP_DPP_MESSAGE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}

unsigned short dpp_uri_notification_message(struct p1905_managerd_ctx *ctx,
	unsigned char *buf, unsigned short reason)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_reason_code_tlv(tlv_temp_buf, reason);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(DPP_URI_NOTIFICATION_MESSAGE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}



unsigned short _1905_encap_eapol_message(unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_1905_encap_eapol_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(_1905_ENCAP_EAPOL);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}


unsigned short dpp_bootstrap_uri_notification_message(unsigned char *buf,
 	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_bootstrap_uri_notification_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(DPP_BOOTSTRAPING_URI_NOTIFICATION);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}

unsigned short dpp_bootstrap_uri_query_message(unsigned char *buf,
 	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(DPP_BOOTSTRAPING_URI_QUERY);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}


unsigned short dpp_cce_indication_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = ctx->send_tlv_len;
	memcpy(tlv_temp_buf, ctx->send_tlv, ctx->send_tlv_len);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(DPP_CCE_INDICATION_MESSAGE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}

/* Once an Enrollee Multi-AP Agent has established a PMK and PTK with the
** Controller at 1905 layer,it shall request configuration for its fBSSs
** and bBSSs by sending a 1905 BSS Configuration Request message to the Controller
*/
unsigned short bss_configuration_request_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;
	struct ap_radio_advan_cap cap;
	unsigned char radio_index = 0;
	int i = 0;
	struct radio_info *r = NULL;
	struct ap_mlo_cap_db *mlo_entry = NULL;

	msg_hdr = (cmdu_message_header*)buf;

	/* version */
	length = append_map_version_tlv(tlv_temp_buf, ctx->map_version);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/* one SupportedService TLV */
	length = append_supported_service_tlv(tlv_temp_buf, ctx->service);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/* One AKM Suite Capabilities TLV */
	length = append_akm_suite_cap_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	for (radio_index = 0; radio_index < ctx->radio_number; radio_index++) {
		r = &ctx->rinfo[radio_index];
		debug(DEBUG_ERROR, "identifier="MACSTR"\n", PRINT_MAC(r->identifier));
		length = append_ap_radio_basic_capability_tlv(ctx, tlv_temp_buf, r);
		total_tlvs_length += length;
		tlv_temp_buf += length;

		/* One or more AP Radio Advanced Capabilities TLV */
		os_memcpy(cap.radioid, r->identifier, ETH_ALEN);
		cap.flag = 0xc0;
		length = append_ap_radio_advan_tlv(tlv_temp_buf, &cap);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}

	/* Zero or more Backhaul STA Radio Capabilities TLV */
	for (i = 0; i < ctx->itf_number; i++) {
		if (ctx->itf[i].is_wifi_sta) {
			length = append_backhaul_sta_radio_cap_tlv(tlv_temp_buf, ctx->itf[i].identifier, ctx->itf[i].mac_addr);
			total_tlvs_length += length;
			tlv_temp_buf += length;
		}
	}

	/* One Profile-2 AP Capability TLV */
	length = append_r2_cap_tlv(tlv_temp_buf, &(ctx->ap_cap_entry.ap_r2_cap));
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_bss_configuration_request_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	SLIST_FOREACH(mlo_entry, &(ctx->ap_cap_entry.ap_mlo_cap_head), entry) {
		length = append_mlo_cap_announce_vendor_tlv(tlv_temp_buf, mlo_entry);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}

#ifdef MAP_R6
	/* Zero or one Wi-Fi 7 Agent Capabilities TLV */
	length = append_wifi7_cap_tlv(ctx, tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;
#endif

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		os_memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(BSS_CONFIGURATION_REQUEST_MESSAGE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}

unsigned short bss_configuration_response_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx, unsigned char *al_mac)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;
	struct bss_connector_item *bc_item = NULL, *bc_item_nxt = NULL;
	unsigned short found = 0;
	unsigned char bss_num = 0;
	unsigned int buf_size = 0;
	struct agent_list_db *agent = NULL;
	int current_bss_num = 0;

	dl_list_for_each_safe(bc_item, bc_item_nxt,
		&ctx->r3_dpp.bss_connector_list, struct bss_connector_item, member) {
		if (os_memcmp(bc_item->almac, al_mac, ETH_ALEN) == 0) {
			found = 1;
			debug(DEBUG_ERROR, "found bss connector by almac "MACSTR"\n", MAC2STR(al_mac));
			break;
		}
	}

	if (!found) {
		debug(DEBUG_ERROR, "not found bss connector by almac "MACSTR"\n", MAC2STR(al_mac));
		debug(DEBUG_ERROR, "wait for another turn\n");
		return 0;
	}
	find_agent_info(ctx, al_mac, &agent);
	if (!agent) {
		debug(DEBUG_ERROR, "error!agent not found"MACSTR"\n",
			PRINT_MAC(al_mac));
		return 0;
	}
	bss_num = precheck_obj_num(ctx, al_mac);
	debug(DEBUG_TRACE, "bss_num = %d\n", bss_num);
	if (ctx->block_bss_info.block_bss_autoconfig) {
		current_bss_num = get_current_bss_num(ctx, al_mac);
		if ((bss_num + current_bss_num) > ctx->block_bss_info.max_bss_count) {
			debug(DEBUG_ERROR, AUTO_CONFIG_PREX"The total bss number exceeds limit!! cur(%d) + agent(%d) > max(%d)\n",
				current_bss_num, bss_num, ctx->block_bss_info.max_bss_count);
			agent->is_block = 1;
			dump_bss_config_info(ctx);
			clear_agent_config_bss_num(agent);
		} else
			debug(DEBUG_ERROR, AUTO_CONFIG_PREX"The total bss number not exceeds limit!! cur(%d) + agent(%d)\n",
				current_bss_num, bss_num);
	}
	if (bss_num > BSSNUM_PER_BSS_RESPONSE_TLV) {
		/* 1 more kbytes for other NULL-SSID obj
		** and 8021Q, ts
		*/
		buf_size = (bss_num+1) * 1024 + CMDU_HLEN + ETH_HLEN;

		if ((buf_size > MAX_PKT_LEN) &&
			((ctx->encr_buf.buf_len < PKT_LEN_100K) ||
			(ctx->tlv_buf.buf_len < PKT_LEN_100K) ||
			(ctx->trx_buf.buf_len < PKT_LEN_100K))) {
			debug(DEBUG_ERROR, "realloc 100k buf for encr buf, tlv buf, ctx rx_buf\n");
			/* realloc 100k buf for encr buf, tlv buf, ctx rx_buf */
			buf_huge(&ctx->encr_buf, buf_size, 0);
			buf_huge(&ctx->tlv_buf, buf_size, 0);
			buf_huge(&ctx->trx_buf, buf_size, 0);
			sec_update_buf(ctx->encr_buf.buf, ctx->encr_buf.buf_len);

			eloop_cancel_timeout(tm_reset_buf_size, (void *)ctx, NULL);
			eloop_register_timeout(60, 0, tm_reset_buf_size, (void *)ctx, NULL);

			if ((ctx->encr_buf.buf_len < PKT_LEN_100K) || (ctx->tlv_buf.buf_len < PKT_LEN_100K) ||
				(ctx->trx_buf.buf_len < PKT_LEN_100K)) {
				debug(DEBUG_ERROR, "one of encr buf, tlv buf, ctx trx_buf less than 100k, skip\n");
				return 0;
			}
		}
	}
	tlv_temp_buf = ctx->tlv_buf.buf;
	msg_hdr = (cmdu_message_header *)(ctx->trx_buf.buf + ETH_HLEN);

	length = append_bss_config_response_tlv(tlv_temp_buf, ctx, al_mac);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/* Zero or one Default 802.1Q Settings TLV */
	length = append_default_8021Q_tlv(ctx, tlv_temp_buf, al_mac,
			ctx->bss_config_num, ctx->bss_config);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/* Zero or one Traffic Separation Policy TLV */
	length = append_traffic_separation_tlv(ctx, tlv_temp_buf, al_mac,
			ctx->bss_config_num, ctx->bss_config);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/* Zero or one MLO Agent BSS Configuration TLV */
	if (agent->ra_info[0].ap_mlo_cap) {
		length = append_agent_ap_mld_config_tlv(tlv_temp_buf, ctx, al_mac);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}
#ifdef MAP_R6
	if (agent->ra_info[0].sta_mlo_cap) {
		length = append_bsta_mld_config_tlv(tlv_temp_buf, ctx, al_mac);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}
	/* length = append_wsc_m8_tlv(tlv_temp_buf, ctx); */
#endif

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(BSS_CONFIGURATION_RESPONSE_MESSAGE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}

unsigned short bss_configuration_result_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx, unsigned char *al_mac)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

    debug(DEBUG_ERROR, "append bss config report\n");
	/* one BSS Configuration report TLV */
	length = append_bss_config_report_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/* Zero or one MLO Agent BSS Configuration TLV */
	length = append_own_ap_mld_config_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;
#ifdef MAP_R6
	length = append_bsta_mld_config_tlv(tlv_temp_buf, ctx, al_mac);
	total_tlvs_length += length;
	tlv_temp_buf += length;
	/* length = append_wsc_m8_tlv(tlv_temp_buf, ctx);*/
#endif

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(BSS_CONFIGURATION_RESULT_MESSAGE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}

unsigned short chirp_notification_message(
	unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	length = append_send_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(CHIRP_NOTIFICATION_MESSAGE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}
unsigned short agent_list_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx, unsigned char *al_mac)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length =0;

	msg_hdr = (cmdu_message_header*)buf;

	/* one or more BSS Configuration response TLV */
	length = append_agent_list_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if(total_tlvs_length < MIN_TLVS_LENGTH)
	{
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(AGENT_LIST_MESSAGE);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}
#endif

int create_t2lm_sp_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;

	msg_hdr = (cmdu_message_header *)buf;

	length = ctx->send_tlv_len;
	memcpy(tlv_temp_buf, ctx->send_tlv, ctx->send_tlv_len);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimum ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if (total_tlvs_length < MIN_TLVS_LENGTH) {
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	//0x00: for this version of the specification
	//0x01~0xFF: Reserved Values
	msg_hdr->message_version = 0x0;

	//set reserve field to 0
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(SERVICE_PRIORITIZATION_REQUEST);
	msg_hdr->relay_indicator = 0x0;
	//set reserve field to 0
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;

}

#ifdef MAP_R6
unsigned short early_ap_cap_report_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;
	int radio_index = 0;
	struct radio_info *r = NULL;
	struct ap_ht_cap_db *ht = NULL;
	struct ap_vht_cap_db *vht = NULL;
	struct ap_he_cap_db *he = NULL;
	struct ap_wf6_role_db *pdb_wf6 = NULL;
	struct ap_radio_advan_cap cap = {0};

	msg_hdr = (cmdu_message_header *)buf;

	/* One AP Capability TLV */
	length = append_ap_capability_tlv(tlv_temp_buf, &ctx->ap_cap_entry.ap_cap);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/* One AP Radio Basic Capabilities TLV for each radio it is operating */
	for (radio_index = 0; radio_index < ctx->radio_number; radio_index++) {
		r = &ctx->rinfo[radio_index];
		debug(DEBUG_TRACE, "radio identifier="MACSTR"\n", PRINT_MAC(r->identifier));

		length = append_ap_radio_basic_capability_tlv(ctx, tlv_temp_buf, r);
		total_tlvs_length += length;
		tlv_temp_buf += length;

		os_memset(&cap, 0, sizeof(struct ap_radio_advan_cap));
		os_memcpy(cap.radioid, r->identifier, ETH_ALEN);
		cap.flag = 0;
		cap.flag |= (AP_CAPA_COMB_FRONTBACK | AP_CAPA_COMB_PROFILE1_PROFILE2);
		cap.flag |= (ctx->config_adv_capability & 0x3C);

		/* One AP RadionAdvance Capabilities TLV */
		length = append_ap_radio_advan_tlv(tlv_temp_buf, &cap);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}

	/* One AP HT Capabilities TLV for each radio it is operating that is capable of HT operation */
	SLIST_FOREACH(ht, &(ctx->ap_cap_entry.ap_ht_cap_head), ap_ht_cap_entry)
	{
		debug(DEBUG_TRACE, "ht->identifier="MACSTR"\n",
			PRINT_MAC(ht->identifier));
		length = append_ap_ht_capability_tlv(tlv_temp_buf, ht);
		total_tlvs_length += length;
		tlv_temp_buf += length;

	}

	/* One AP VHT Capabilities TLV for each radio it is operating */
	SLIST_FOREACH(vht, &(ctx->ap_cap_entry.ap_vht_cap_head), ap_vht_cap_entry)
	{
		debug(DEBUG_TRACE, "vht->identifier="MACSTR"\n", PRINT_MAC(vht->identifier));
		length = append_ap_vht_capability_tlv(tlv_temp_buf, vht);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}

	/* One AP HE Capabilities TLV for each radio it is operating */
	SLIST_FOREACH(he, &(ctx->ap_cap_entry.ap_he_cap_head), ap_he_cap_entry)
	{
		debug(DEBUG_TRACE, "he->identifier="MACSTR"\n",
			PRINT_MAC(he->identifier));
		length = append_ap_he_capability_tlv(tlv_temp_buf, he);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}

	SLIST_FOREACH(pdb_wf6, &(ctx->ap_cap_entry.ap_wf6_cap_head), ap_wf6_role_entry) {
		debug(DEBUG_ERROR, "pdb_wf6->identifier="MACSTR"\n",
			PRINT_MAC(pdb_wf6->identifier));
		/* One AP Wi-Fi 6 Capabilities TLV for each radio it is operating */
		length = append_ap_wf6_capability_tlv(tlv_temp_buf, pdb_wf6);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}

	/* One Wi-Fi 7 Agent Capabilities TLV */
	length = append_wifi7_cap_tlv(ctx, tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/* Zero or one EHT Operations TLV */
	length = append_eht_operations_tlv(ctx, tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/* Zero or one 1905 Layer Security Capability TLV */
	length = append_1905_layer_security_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/* Zero or one CAC Capabilities TLV */
	length = append_cac_capability_tlv(tlv_temp_buf, &(ctx->ap_cap_entry.radio_cac_cap));
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/* One Profile-2 AP Capability TLV */
	length = append_r2_cap_tlv(tlv_temp_buf, &(ctx->ap_cap_entry.ap_r2_cap));
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/* Zero or one Metric Collection Interval TLV */
	length = append_metric_collection_interval_tlv(tlv_temp_buf, ctx->metric_entry.metric_collection_interval);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/* Zero or one Device Inventory TLV */
	length = append_dev_inven_tlv(tlv_temp_buf, &(ctx->de));
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/* akm capability tlv */
	length = append_akm_suite_cap_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimun ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if (total_tlvs_length < MIN_TLVS_LENGTH) {
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	msg_hdr->message_version = 0x0;

	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(EARLY_AP_CAP_REPORT_MESSAGE);
	msg_hdr->relay_indicator = 0x0;
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}

unsigned short ap_mld_configuration_request_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx, unsigned char *almac)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;
	struct agent_list_db *agent = NULL;

	msg_hdr = (cmdu_message_header *)buf;

	find_agent_info(ctx, almac, &agent);
	if (!agent) {
		debug(DEBUG_ERROR, "error!agent not found"MACSTR"\n",
			PRINT_MAC(almac));
		return 0;
	}

	/* One Agent ap mld configuration tlv */
	if (agent->ra_info[0].ap_mlo_cap) {
		length = append_agent_ap_mld_config_tlv(tlv_temp_buf, ctx, almac);
		total_tlvs_length += length;
		tlv_temp_buf += length;
	}

	/* Zero or one EHT Operations TLV  */
	length = append_eht_operations_tlv(ctx, tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	if (total_tlvs_length < MIN_TLVS_LENGTH) {
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	msg_hdr->message_version = 0x0;

	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(AP_MLD_CONFIGURATION_REQUEST_MESSAGE);
	msg_hdr->relay_indicator = 0x0;
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}

unsigned short ap_mld_configuration_response_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx, unsigned char *almac)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;

	msg_hdr = (cmdu_message_header *)buf;

	/* One Agent ap mld configuration tlv */
	length = append_own_ap_mld_config_tlv(tlv_temp_buf, ctx);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/* one EHT Operations TLV  */
	length = append_eht_operations_tlv(ctx, tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	if (total_tlvs_length < MIN_TLVS_LENGTH) {
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	msg_hdr->message_version = 0x0;

	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(AP_MLD_CONFIGURATION_RESPONSE_MESSAGE);
	msg_hdr->relay_indicator = 0x0;
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}

unsigned short bsta_mld_configuration_request_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx, unsigned char *almac)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;

	msg_hdr = (cmdu_message_header *)buf;

	/* One bsta mld configuration tlv */
	length = append_bsta_mld_config_tlv(tlv_temp_buf, ctx, almac);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	if (total_tlvs_length < MIN_TLVS_LENGTH) {
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	msg_hdr->message_version = 0x0;

	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(BSTA_MLD_CONFIGURATION_REQUEST_MESSAGE);
	msg_hdr->relay_indicator = 0x0;
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}

unsigned short bsta_mld_configuration_response_message(unsigned char *buf,
	struct p1905_managerd_ctx *ctx, unsigned char *almac)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;

	msg_hdr = (cmdu_message_header *)buf;

	/* One bsta mld configuration tlv */
	length = append_bsta_mld_config_tlv(tlv_temp_buf, ctx, almac);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	if (total_tlvs_length < MIN_TLVS_LENGTH) {
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	msg_hdr->message_version = 0x0;

	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(BSTA_MLD_CONFIGURATION_RESPONSE_MESSAGE);
	msg_hdr->relay_indicator = 0x0;
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}

unsigned short afc_spectrum_inquiry_message(unsigned char *buf, struct p1905_managerd_ctx *ctx)
{
	unsigned char *tlv_temp_buf = ctx->tlv_buf.buf;
	cmdu_message_header *msg_hdr;
	unsigned short length = 0;
	unsigned short total_tlvs_length = 0;

	msg_hdr = (cmdu_message_header *)buf;

	length = ctx->send_tlv_len;
	memcpy(tlv_temp_buf, ctx->send_tlv, ctx->send_tlv_len);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	length = append_end_of_tlv(tlv_temp_buf);
	total_tlvs_length += length;
	tlv_temp_buf += length;

	/*tlvs size is less than (46(minimum ethernet frame payload size)
	 *-8(cmdu header size)) ==>padding
	 */
	if (total_tlvs_length < MIN_TLVS_LENGTH) {
		memset(tlv_temp_buf, 0, (MIN_TLVS_LENGTH - total_tlvs_length));
		total_tlvs_length = MIN_TLVS_LENGTH;
	}

	/*0x00: for this version of the specification*/
	/*0x01~0xFF: Reserved Values*/
	msg_hdr->message_version = 0x0;

	/*set reserve field to 0*/
	msg_hdr->reserved_field_0 = 0x0;
	msg_hdr->message_type = host_to_be16(AFC_SPECTRUM_INQUIRY_MESSAGE);
	msg_hdr->relay_indicator = 0x0;
	/*set reserve field to 0*/
	msg_hdr->reserve_field_1 = 0x0;

	return total_tlvs_length;
}
#endif

