/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * Copyright  (C) 2019-2020  MediaTek Inc. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 */
#include <stdio.h>
#include <string.h>
#include <linux/if_ether.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include "debug.h"
#include "p1905_database.h"

#define MAP_SO_BASE 1905

int get_receive_port_addr(unsigned char *brname, unsigned char *inputmac,unsigned char *outputmac)
{
	int fd = 0, ret = 0;
	int size = ETH_ALEN;
	unsigned char mac[ETH_ALEN] = {0};

	fd = socket(PF_INET, SOCK_RAW, IPPROTO_RAW);
	if (fd < 0) {
		debug(DEBUG_ERROR, "socket create fail\n");
		return -1;
	}
	memcpy(mac, inputmac, ETH_ALEN);
	ret = getsockopt(fd, IPPROTO_IP, MAP_SO_BASE, mac, (socklen_t *)&size);
	close(fd);

	if (ret < 0) {
		debug(DEBUG_ERROR, "fail! ret(%d)\n", ret);
		return -1;
	}
	memcpy(outputmac, mac, ETH_ALEN);

	return 0;
}

int set_opt_not_forward_dest(unsigned char *inputmac)
{
	int fd = 0, ret = 0;
	int size = ETH_ALEN;
	unsigned char mac[ETH_ALEN] = {0};

	fd = socket(PF_INET, SOCK_RAW, IPPROTO_RAW);
	if (fd < 0) {
		debug(DEBUG_ERROR, "create socket error\n");
		return -1;
	}
	memcpy(mac, inputmac, ETH_ALEN);
	debug(DEBUG_TRACE, "not forward mac("MACSTR")\n",
		PRINT_MAC(mac));
	ret = setsockopt(fd, IPPROTO_IP, MAP_SO_BASE, mac, (socklen_t)size);
	close(fd);

	if (ret < 0) {
		debug(DEBUG_ERROR, "fail! ret(%d)\n", ret);
		return -1;
	}

	return 0;
}



